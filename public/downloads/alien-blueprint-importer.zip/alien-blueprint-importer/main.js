//#region src/blueprints/legacy-assets.js
var legacyAssets = {
	console: "commandBench",
	bed: "crewBed",
	cryo: "cryoPodPlan",
	table: "diningTable",
	crate: "reinforcedCrate",
	chair: "operatorSeat",
	medical: "examBed",
	locker: "wallLocker",
	tank: "horizontalTank",
	rack: "storageShelf",
	workbench: "serviceBench",
	kitchen: "industrialRange",
	sofa: "loungeSofa"
};
//#endregion
//#region src/blueprints/vehicle-assets.js
var vehicleAssets = {
	retroLocomotive: {
		name: "Locomotiva diesel-elétrica retro",
		w: 3.2,
		h: 18,
		category: "rail-vehicles",
		shapes: [
			{
				tag: "rect",
				x: 43,
				y: 0,
				width: 14,
				height: 5,
				rx: 0
			},
			{
				tag: "rect",
				x: 43,
				y: 95,
				width: 14,
				height: 5,
				rx: 0
			},
			{
				tag: "rect",
				x: 5,
				y: 15,
				width: 90,
				height: 12,
				rx: 0
			},
			{
				tag: "rect",
				x: 5,
				y: 73,
				width: 90,
				height: 12,
				rx: 0
			},
			{
				tag: "path",
				d: "M26 4H74L86 12V88L74 96H26L14 88V12Z"
			},
			{
				tag: "rect",
				x: 21,
				y: 10,
				width: 58,
				height: 16,
				rx: 3
			},
			{
				tag: "path",
				d: "M25 13H75M25 22H75M48 10V22"
			},
			{
				tag: "rect",
				x: 23,
				y: 31,
				width: 54,
				height: 55,
				rx: 2
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 43,
				rx: 17,
				ry: 5
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 60,
				rx: 17,
				ry: 5
			},
			{
				tag: "path",
				d: "M30 72H70"
			},
			{
				tag: "path",
				d: "M30 75H70"
			},
			{
				tag: "path",
				d: "M30 78H70"
			},
			{
				tag: "path",
				d: "M30 81H70"
			},
			{
				tag: "rect",
				x: 29,
				y: 88,
				width: 42,
				height: 5,
				rx: 0
			}
		]
	},
	passengerCar: {
		name: "Vagão de passageiros · exterior",
		w: 3,
		h: 22,
		category: "rail-vehicles",
		shapes: [
			{
				tag: "rect",
				x: 43,
				y: 0,
				width: 14,
				height: 5,
				rx: 0
			},
			{
				tag: "rect",
				x: 43,
				y: 95,
				width: 14,
				height: 5,
				rx: 0
			},
			{
				tag: "rect",
				x: 5,
				y: 15,
				width: 90,
				height: 12,
				rx: 0
			},
			{
				tag: "rect",
				x: 5,
				y: 73,
				width: 90,
				height: 12,
				rx: 0
			},
			{
				tag: "rect",
				x: 12,
				y: 5,
				width: 76,
				height: 90,
				rx: 2
			},
			{
				tag: "rect",
				x: 22,
				y: 12,
				width: 56,
				height: 76,
				rx: 4
			},
			{
				tag: "rect",
				x: 34,
				y: 32,
				width: 32,
				height: 12,
				rx: 2
			},
			{
				tag: "rect",
				x: 34,
				y: 59,
				width: 32,
				height: 12,
				rx: 2
			},
			{
				tag: "path",
				d: "M13 19H19M81 19H87"
			},
			{
				tag: "path",
				d: "M13 29H19M81 29H87"
			},
			{
				tag: "path",
				d: "M13 39H19M81 39H87"
			},
			{
				tag: "path",
				d: "M13 49H19M81 49H87"
			},
			{
				tag: "path",
				d: "M13 59H19M81 59H87"
			},
			{
				tag: "path",
				d: "M13 69H19M81 69H87"
			},
			{
				tag: "path",
				d: "M13 79H19M81 79H87"
			},
			{
				tag: "path",
				d: "M22 16H78M22 84H78M43 5V11M57 5V11M43 89V95M57 89V95"
			}
		]
	},
	boxFreightCar: {
		name: "Vagão de carga fechado",
		w: 3.2,
		h: 16,
		category: "rail-vehicles",
		shapes: [
			{
				tag: "rect",
				x: 43,
				y: 0,
				width: 14,
				height: 5,
				rx: 0
			},
			{
				tag: "rect",
				x: 43,
				y: 95,
				width: 14,
				height: 5,
				rx: 0
			},
			{
				tag: "rect",
				x: 5,
				y: 15,
				width: 90,
				height: 12,
				rx: 0
			},
			{
				tag: "rect",
				x: 5,
				y: 73,
				width: 90,
				height: 12,
				rx: 0
			},
			{
				tag: "rect",
				x: 12,
				y: 5,
				width: 76,
				height: 90,
				rx: 2
			},
			{
				tag: "rect",
				x: 20,
				y: 9,
				width: 60,
				height: 82,
				rx: 0
			},
			{
				tag: "path",
				d: "M20 17H80"
			},
			{
				tag: "path",
				d: "M20 25H80"
			},
			{
				tag: "path",
				d: "M20 33H80"
			},
			{
				tag: "path",
				d: "M20 41H80"
			},
			{
				tag: "path",
				d: "M20 49H80"
			},
			{
				tag: "path",
				d: "M20 57H80"
			},
			{
				tag: "path",
				d: "M20 65H80"
			},
			{
				tag: "path",
				d: "M20 73H80"
			},
			{
				tag: "path",
				d: "M20 81H80"
			},
			{
				tag: "path",
				d: "M20 89H80"
			},
			{
				tag: "path",
				d: "M13 38H19V62H13M81 38H87V62H81"
			}
		]
	},
	flatFreightCar: {
		name: "Vagão plataforma vazio",
		w: 3,
		h: 18,
		category: "rail-vehicles",
		shapes: [
			{
				tag: "rect",
				x: 43,
				y: 0,
				width: 14,
				height: 5,
				rx: 0
			},
			{
				tag: "rect",
				x: 43,
				y: 95,
				width: 14,
				height: 5,
				rx: 0
			},
			{
				tag: "rect",
				x: 5,
				y: 15,
				width: 90,
				height: 12,
				rx: 0
			},
			{
				tag: "rect",
				x: 5,
				y: 73,
				width: 90,
				height: 12,
				rx: 0
			},
			{
				tag: "rect",
				x: 12,
				y: 5,
				width: 76,
				height: 90,
				rx: 2
			},
			{
				tag: "rect",
				x: 20,
				y: 10,
				width: 60,
				height: 80,
				rx: 0
			},
			{
				tag: "path",
				d: "M20 18H80"
			},
			{
				tag: "path",
				d: "M20 30H80"
			},
			{
				tag: "path",
				d: "M20 42H80"
			},
			{
				tag: "path",
				d: "M20 54H80"
			},
			{
				tag: "path",
				d: "M20 66H80"
			},
			{
				tag: "path",
				d: "M20 78H80"
			},
			{
				tag: "path",
				d: "M15 10V90M85 10V90"
			}
		]
	},
	tankFreightCar: {
		name: "Vagão-tanque",
		w: 3.2,
		h: 15,
		category: "rail-vehicles",
		shapes: [
			{
				tag: "rect",
				x: 43,
				y: 0,
				width: 14,
				height: 5,
				rx: 0
			},
			{
				tag: "rect",
				x: 43,
				y: 95,
				width: 14,
				height: 5,
				rx: 0
			},
			{
				tag: "rect",
				x: 5,
				y: 15,
				width: 90,
				height: 12,
				rx: 0
			},
			{
				tag: "rect",
				x: 5,
				y: 73,
				width: 90,
				height: 12,
				rx: 0
			},
			{
				tag: "rect",
				x: 12,
				y: 5,
				width: 76,
				height: 90,
				rx: 2
			},
			{
				tag: "rect",
				x: 20,
				y: 9,
				width: 60,
				height: 82,
				rx: 20
			},
			{
				tag: "path",
				d: "M20 26H80M20 74H80"
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 49,
				rx: 11,
				ry: 4
			},
			{
				tag: "path",
				d: "M47 15V85M53 15V85M47 31H53M47 65H53"
			}
		]
	},
	hopperFreightCar: {
		name: "Vagão de minério aberto",
		w: 3.3,
		h: 14,
		category: "rail-vehicles",
		shapes: [
			{
				tag: "rect",
				x: 43,
				y: 0,
				width: 14,
				height: 5,
				rx: 0
			},
			{
				tag: "rect",
				x: 43,
				y: 95,
				width: 14,
				height: 5,
				rx: 0
			},
			{
				tag: "rect",
				x: 5,
				y: 15,
				width: 90,
				height: 12,
				rx: 0
			},
			{
				tag: "rect",
				x: 5,
				y: 73,
				width: 90,
				height: 12,
				rx: 0
			},
			{
				tag: "rect",
				x: 12,
				y: 5,
				width: 76,
				height: 90,
				rx: 2
			},
			{
				tag: "rect",
				x: 18,
				y: 9,
				width: 64,
				height: 82,
				rx: 0
			},
			{
				tag: "path",
				d: "M18 9L28 18H72L82 9M18 91L28 82H72L82 91M28 18V82M72 18V82M18 37H82M18 63H82M28 18L72 37M72 37L28 63M28 63L72 82"
			}
		]
	},
	containerFreightCar: {
		name: "Vagão porta-contêineres",
		w: 3.2,
		h: 20,
		category: "rail-vehicles",
		shapes: [
			{
				tag: "rect",
				x: 43,
				y: 0,
				width: 14,
				height: 5,
				rx: 0
			},
			{
				tag: "rect",
				x: 43,
				y: 95,
				width: 14,
				height: 5,
				rx: 0
			},
			{
				tag: "rect",
				x: 5,
				y: 15,
				width: 90,
				height: 12,
				rx: 0
			},
			{
				tag: "rect",
				x: 5,
				y: 73,
				width: 90,
				height: 12,
				rx: 0
			},
			{
				tag: "rect",
				x: 12,
				y: 5,
				width: 76,
				height: 90,
				rx: 2
			},
			{
				tag: "rect",
				x: 17,
				y: 9,
				width: 66,
				height: 39,
				rx: 0
			},
			{
				tag: "rect",
				x: 17,
				y: 52,
				width: 66,
				height: 39,
				rx: 0
			},
			{
				tag: "path",
				d: "M23 15H77"
			},
			{
				tag: "path",
				d: "M23 21H77"
			},
			{
				tag: "path",
				d: "M23 27H77"
			},
			{
				tag: "path",
				d: "M23 33H77"
			},
			{
				tag: "path",
				d: "M23 39H77"
			},
			{
				tag: "path",
				d: "M23 58H77"
			},
			{
				tag: "path",
				d: "M23 64H77"
			},
			{
				tag: "path",
				d: "M23 70H77"
			},
			{
				tag: "path",
				d: "M23 76H77"
			},
			{
				tag: "path",
				d: "M23 82H77"
			},
			{
				tag: "path",
				d: "M17 45H83M17 88H83"
			}
		]
	},
	refrigeratedCar: {
		name: "Vagão refrigerado",
		w: 3.2,
		h: 17,
		category: "rail-vehicles",
		shapes: [
			{
				tag: "rect",
				x: 43,
				y: 0,
				width: 14,
				height: 5,
				rx: 0
			},
			{
				tag: "rect",
				x: 43,
				y: 95,
				width: 14,
				height: 5,
				rx: 0
			},
			{
				tag: "rect",
				x: 5,
				y: 15,
				width: 90,
				height: 12,
				rx: 0
			},
			{
				tag: "rect",
				x: 5,
				y: 73,
				width: 90,
				height: 12,
				rx: 0
			},
			{
				tag: "rect",
				x: 12,
				y: 5,
				width: 76,
				height: 90,
				rx: 2
			},
			{
				tag: "rect",
				x: 20,
				y: 9,
				width: 60,
				height: 67,
				rx: 3
			},
			{
				tag: "rect",
				x: 20,
				y: 80,
				width: 60,
				height: 11,
				rx: 0
			},
			{
				tag: "ellipse",
				cx: 38,
				cy: 85,
				rx: 10,
				ry: 3
			},
			{
				tag: "ellipse",
				cx: 62,
				cy: 85,
				rx: 10,
				ry: 3
			},
			{
				tag: "path",
				d: "M25 15H75M25 70H75M13 35H20V55H13M80 35H87V55H80"
			}
		]
	},
	crawlerTractor: {
		name: "Trator de esteiras",
		w: 3.2,
		h: 5,
		category: "industrial-vehicles",
		shapes: [
			{
				tag: "rect",
				x: 3,
				y: 18,
				width: 23,
				height: 70,
				rx: 5
			},
			{
				tag: "rect",
				x: 74,
				y: 18,
				width: 23,
				height: 70,
				rx: 5
			},
			{
				tag: "path",
				d: "M7 25H22M78 25H93"
			},
			{
				tag: "path",
				d: "M7 35H22M78 35H93"
			},
			{
				tag: "path",
				d: "M7 45H22M78 45H93"
			},
			{
				tag: "path",
				d: "M7 55H22M78 55H93"
			},
			{
				tag: "path",
				d: "M7 65H22M78 65H93"
			},
			{
				tag: "path",
				d: "M7 75H22M78 75H93"
			},
			{
				tag: "path",
				d: "M7 83H22M78 83H93"
			},
			{
				tag: "rect",
				x: 28,
				y: 15,
				width: 44,
				height: 72,
				rx: 4
			},
			{
				tag: "rect",
				x: 32,
				y: 54,
				width: 36,
				height: 28,
				rx: 4
			},
			{
				tag: "path",
				d: "M36 59H64M36 75H64"
			},
			{
				tag: "rect",
				x: 32,
				y: 22,
				width: 36,
				height: 22,
				rx: 0
			},
			{
				tag: "path",
				d: "M37 27H63"
			},
			{
				tag: "path",
				d: "M37 32H63"
			},
			{
				tag: "path",
				d: "M37 37H63"
			},
			{
				tag: "path",
				d: "M25 24L12 10M75 24L88 10"
			},
			{
				tag: "rect",
				x: 3,
				y: 2,
				width: 94,
				height: 12,
				rx: 3
			}
		]
	},
	mobileCrane: {
		name: "Guindaste móvel · lança recolhida",
		w: 3.2,
		h: 10,
		category: "industrial-vehicles",
		shapes: [
			{
				tag: "rect",
				x: 2,
				y: 15,
				width: 14,
				height: 17,
				rx: 3
			},
			{
				tag: "rect",
				x: 84,
				y: 15,
				width: 14,
				height: 17,
				rx: 3
			},
			{
				tag: "rect",
				x: 2,
				y: 68,
				width: 14,
				height: 20,
				rx: 3
			},
			{
				tag: "rect",
				x: 84,
				y: 68,
				width: 14,
				height: 20,
				rx: 3
			},
			{
				tag: "rect",
				x: 15,
				y: 4,
				width: 70,
				height: 92,
				rx: 3
			},
			{
				tag: "rect",
				x: 19,
				y: 7,
				width: 25,
				height: 18,
				rx: 3
			},
			{
				tag: "path",
				d: "M22 12H40"
			},
			{
				tag: "ellipse",
				cx: 52,
				cy: 67,
				rx: 23,
				ry: 12
			},
			{
				tag: "rect",
				x: 43,
				y: 10,
				width: 18,
				height: 59,
				rx: 3
			},
			{
				tag: "rect",
				x: 47,
				y: 3,
				width: 10,
				height: 59,
				rx: 0
			},
			{
				tag: "path",
				d: "M47 18H57M47 32H57M47 46H57"
			},
			{
				tag: "rect",
				x: 4,
				y: 39,
				width: 92,
				height: 5,
				rx: 0
			},
			{
				tag: "rect",
				x: 4,
				y: 82,
				width: 92,
				height: 5,
				rx: 0
			}
		]
	},
	heavyForklift: {
		name: "Empilhadeira industrial",
		w: 1.6,
		h: 3.8,
		category: "industrial-vehicles",
		shapes: [
			{
				tag: "rect",
				x: 2,
				y: 15,
				width: 14,
				height: 17,
				rx: 3
			},
			{
				tag: "rect",
				x: 84,
				y: 15,
				width: 14,
				height: 17,
				rx: 3
			},
			{
				tag: "rect",
				x: 2,
				y: 68,
				width: 14,
				height: 20,
				rx: 3
			},
			{
				tag: "rect",
				x: 84,
				y: 68,
				width: 14,
				height: 20,
				rx: 3
			},
			{
				tag: "rect",
				x: 20,
				y: 40,
				width: 60,
				height: 55,
				rx: 6
			},
			{
				tag: "rect",
				x: 26,
				y: 47,
				width: 48,
				height: 24,
				rx: 3
			},
			{
				tag: "path",
				d: "M30 53H70M35 80H65"
			},
			{
				tag: "rect",
				x: 19,
				y: 30,
				width: 62,
				height: 10,
				rx: 0
			},
			{
				tag: "rect",
				x: 25,
				y: 3,
				width: 10,
				height: 27,
				rx: 0
			},
			{
				tag: "rect",
				x: 65,
				y: 3,
				width: 10,
				height: 27,
				rx: 0
			},
			{
				tag: "path",
				d: "M15 38H85"
			}
		]
	},
	wheelLoader: {
		name: "Pá carregadeira",
		w: 3,
		h: 7,
		category: "industrial-vehicles",
		shapes: [
			{
				tag: "rect",
				x: 2,
				y: 15,
				width: 14,
				height: 17,
				rx: 3
			},
			{
				tag: "rect",
				x: 84,
				y: 15,
				width: 14,
				height: 17,
				rx: 3
			},
			{
				tag: "rect",
				x: 2,
				y: 68,
				width: 14,
				height: 20,
				rx: 3
			},
			{
				tag: "rect",
				x: 84,
				y: 68,
				width: 14,
				height: 20,
				rx: 3
			},
			{
				tag: "rect",
				x: 22,
				y: 44,
				width: 56,
				height: 50,
				rx: 6
			},
			{
				tag: "rect",
				x: 29,
				y: 49,
				width: 42,
				height: 25,
				rx: 4
			},
			{
				tag: "rect",
				x: 32,
				y: 78,
				width: 36,
				height: 10,
				rx: 0
			},
			{
				tag: "path",
				d: "M30 44L20 23M70 44L80 23M40 44L30 23M60 44L70 23"
			},
			{
				tag: "path",
				d: "M5 5H95V25L82 33H18L5 25ZM10 12H90"
			}
		]
	},
	trackedExcavator: {
		name: "Escavadeira de esteiras · braço recolhido",
		w: 3.2,
		h: 8,
		category: "industrial-vehicles",
		shapes: [
			{
				tag: "rect",
				x: 3,
				y: 18,
				width: 23,
				height: 70,
				rx: 5
			},
			{
				tag: "rect",
				x: 74,
				y: 18,
				width: 23,
				height: 70,
				rx: 5
			},
			{
				tag: "path",
				d: "M7 25H22M78 25H93"
			},
			{
				tag: "path",
				d: "M7 35H22M78 35H93"
			},
			{
				tag: "path",
				d: "M7 45H22M78 45H93"
			},
			{
				tag: "path",
				d: "M7 55H22M78 55H93"
			},
			{
				tag: "path",
				d: "M7 65H22M78 65H93"
			},
			{
				tag: "path",
				d: "M7 75H22M78 75H93"
			},
			{
				tag: "path",
				d: "M7 83H22M78 83H93"
			},
			{
				tag: "rect",
				x: 25,
				y: 43,
				width: 50,
				height: 43,
				rx: 8
			},
			{
				tag: "rect",
				x: 28,
				y: 48,
				width: 22,
				height: 25,
				rx: 3
			},
			{
				tag: "ellipse",
				cx: 57,
				cy: 65,
				rx: 12,
				ry: 10
			},
			{
				tag: "path",
				d: "M54 65L46 15H57L65 65ZM47 15L66 3H78L57 22Z"
			},
			{
				tag: "rect",
				x: 65,
				y: 2,
				width: 28,
				height: 13,
				rx: 3
			},
			{
				tag: "path",
				d: "M69 5V12M76 5V12M83 5V12"
			}
		]
	},
	miningHauler: {
		name: "Caminhão de mineração",
		w: 5.5,
		h: 10,
		category: "industrial-vehicles",
		shapes: [
			{
				tag: "rect",
				x: 2,
				y: 15,
				width: 14,
				height: 17,
				rx: 3
			},
			{
				tag: "rect",
				x: 84,
				y: 15,
				width: 14,
				height: 17,
				rx: 3
			},
			{
				tag: "rect",
				x: 2,
				y: 68,
				width: 14,
				height: 20,
				rx: 3
			},
			{
				tag: "rect",
				x: 84,
				y: 68,
				width: 14,
				height: 20,
				rx: 3
			},
			{
				tag: "rect",
				x: 16,
				y: 6,
				width: 68,
				height: 88,
				rx: 4
			},
			{
				tag: "rect",
				x: 20,
				y: 10,
				width: 27,
				height: 16,
				rx: 3
			},
			{
				tag: "rect",
				x: 53,
				y: 10,
				width: 27,
				height: 16,
				rx: 0
			},
			{
				tag: "rect",
				x: 20,
				y: 32,
				width: 60,
				height: 57,
				rx: 0
			},
			{
				tag: "path",
				d: "M20 32L29 41H71L80 32M29 41V82H71V41M20 89L29 82M80 89L71 82"
			},
			{
				tag: "path",
				d: "M5 40H16M84 40H95"
			}
		]
	},
	retroCargoTruck: {
		name: "Caminhão de carga fechado retro",
		w: 2.6,
		h: 8,
		category: "road-vehicles",
		shapes: [
			{
				tag: "rect",
				x: 2,
				y: 15,
				width: 14,
				height: 17,
				rx: 3
			},
			{
				tag: "rect",
				x: 84,
				y: 15,
				width: 14,
				height: 17,
				rx: 3
			},
			{
				tag: "rect",
				x: 2,
				y: 68,
				width: 14,
				height: 20,
				rx: 3
			},
			{
				tag: "rect",
				x: 84,
				y: 68,
				width: 14,
				height: 20,
				rx: 3
			},
			{
				tag: "rect",
				x: 16,
				y: 6,
				width: 68,
				height: 30,
				rx: 5
			},
			{
				tag: "path",
				d: "M23 11H77L73 18H27ZM22 28H78M22 31H78"
			},
			{
				tag: "rect",
				x: 6,
				y: 10,
				width: 9,
				height: 5,
				rx: 0
			},
			{
				tag: "rect",
				x: 85,
				y: 10,
				width: 9,
				height: 5,
				rx: 0
			},
			{
				tag: "rect",
				x: 15,
				y: 41,
				width: 70,
				height: 54,
				rx: 2
			},
			{
				tag: "path",
				d: "M22 49H78"
			},
			{
				tag: "path",
				d: "M22 59H78"
			},
			{
				tag: "path",
				d: "M22 69H78"
			},
			{
				tag: "path",
				d: "M22 79H78"
			},
			{
				tag: "path",
				d: "M22 89H78"
			},
			{
				tag: "path",
				d: "M50 89V95"
			}
		]
	},
	retroBus: {
		name: "Ônibus de colônia · exterior",
		w: 2.7,
		h: 12,
		category: "road-vehicles",
		shapes: [
			{
				tag: "rect",
				x: 2,
				y: 15,
				width: 14,
				height: 17,
				rx: 3
			},
			{
				tag: "rect",
				x: 84,
				y: 15,
				width: 14,
				height: 17,
				rx: 3
			},
			{
				tag: "rect",
				x: 2,
				y: 68,
				width: 14,
				height: 20,
				rx: 3
			},
			{
				tag: "rect",
				x: 84,
				y: 68,
				width: 14,
				height: 20,
				rx: 3
			},
			{
				tag: "rect",
				x: 14,
				y: 3,
				width: 72,
				height: 94,
				rx: 8
			},
			{
				tag: "path",
				d: "M21 10H79L75 16H25ZM24 90H76"
			},
			{
				tag: "rect",
				x: 29,
				y: 29,
				width: 42,
				height: 14,
				rx: 3
			},
			{
				tag: "rect",
				x: 29,
				y: 60,
				width: 42,
				height: 14,
				rx: 3
			},
			{
				tag: "path",
				d: "M15 22H21M79 22H85"
			},
			{
				tag: "path",
				d: "M15 34H21M79 34H85"
			},
			{
				tag: "path",
				d: "M15 46H21M79 46H85"
			},
			{
				tag: "path",
				d: "M15 58H21M79 58H85"
			},
			{
				tag: "path",
				d: "M15 70H21M79 70H85"
			},
			{
				tag: "path",
				d: "M15 82H21M79 82H85"
			}
		]
	},
	utilityRover: {
		name: "Jipe utilitário pressurizado",
		w: 2.2,
		h: 4.5,
		category: "road-vehicles",
		shapes: [
			{
				tag: "rect",
				x: 2,
				y: 15,
				width: 14,
				height: 17,
				rx: 3
			},
			{
				tag: "rect",
				x: 84,
				y: 15,
				width: 14,
				height: 17,
				rx: 3
			},
			{
				tag: "rect",
				x: 2,
				y: 68,
				width: 14,
				height: 20,
				rx: 3
			},
			{
				tag: "rect",
				x: 84,
				y: 68,
				width: 14,
				height: 20,
				rx: 3
			},
			{
				tag: "path",
				d: "M25 5H75L84 17V86L73 95H27L16 86V17Z"
			},
			{
				tag: "path",
				d: "M24 18H76L72 30H28ZM28 72H72L77 84H23Z"
			},
			{
				tag: "rect",
				x: 28,
				y: 36,
				width: 44,
				height: 29,
				rx: 4
			},
			{
				tag: "rect",
				x: 35,
				y: 42,
				width: 30,
				height: 16,
				rx: 0
			},
			{
				tag: "path",
				d: "M9 43H16M84 43H91"
			}
		]
	},
	serviceTanker: {
		name: "Caminhão-tanque de serviço",
		w: 2.6,
		h: 8,
		category: "road-vehicles",
		shapes: [
			{
				tag: "rect",
				x: 2,
				y: 15,
				width: 14,
				height: 17,
				rx: 3
			},
			{
				tag: "rect",
				x: 84,
				y: 15,
				width: 14,
				height: 17,
				rx: 3
			},
			{
				tag: "rect",
				x: 2,
				y: 68,
				width: 14,
				height: 20,
				rx: 3
			},
			{
				tag: "rect",
				x: 84,
				y: 68,
				width: 14,
				height: 20,
				rx: 3
			},
			{
				tag: "rect",
				x: 16,
				y: 6,
				width: 68,
				height: 30,
				rx: 5
			},
			{
				tag: "path",
				d: "M23 11H77L73 18H27ZM22 28H78M22 31H78"
			},
			{
				tag: "rect",
				x: 6,
				y: 10,
				width: 9,
				height: 5,
				rx: 0
			},
			{
				tag: "rect",
				x: 85,
				y: 10,
				width: 9,
				height: 5,
				rx: 0
			},
			{
				tag: "rect",
				x: 20,
				y: 41,
				width: 60,
				height: 54,
				rx: 17
			},
			{
				tag: "path",
				d: "M20 53H80M20 82H80"
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 67,
				rx: 10,
				ry: 5
			},
			{
				tag: "path",
				d: "M45 44V91M55 44V91"
			}
		]
	}
};
//#endregion
//#region src/blueprints/plan-shapes.js
var rect$2 = (x, y, width, height, rx = 0) => ({
	tag: "rect",
	x,
	y,
	width,
	height,
	rx
});
var line$1 = (d) => ({
	tag: "path",
	d,
	fill: "none"
});
var body = (d) => ({
	tag: "path",
	d,
	fill: "inherit"
});
var circle$2 = (cx, cy, r) => ({
	tag: "circle",
	cx,
	cy,
	r
});
//#endregion
//#region src/blueprints/outpost-machinery.js
var machine = (name, w, h, shapes) => ({
	name,
	w,
	h,
	category: "workshop",
	shapes
});
var outpostMachinery = {
	bandSaw: machine("Serra de fita horizontal", 1.85, .95, [
		rect$2(6, 31, 88, 55, 4),
		body("M4 18Q7 9 17 13L89 30Q99 34 93 48L84 57L13 36Q1 32 4 18Z"),
		circle$2(15, 24, 6),
		circle$2(86, 41, 6),
		line$1("M14 32l70 18M28 53v25m8-25v25"),
		rect$2(51, 48, 16, 13),
		rect$2(51, 69, 16, 7),
		circle$2(78, 70, 5)
	]),
	benchGrinder: machine("Esmeril de duas pedras", .92, .62, [
		rect$2(29, 25, 42, 54, 4),
		rect$2(17, 42, 66, 11),
		rect$2(6, 20, 17, 55, 5),
		rect$2(77, 20, 17, 55, 5),
		rect$2(3, 68, 23, 12),
		rect$2(74, 68, 23, 12),
		line$1("M10 24v37m8-37v37M81 25v35m8-35v35M38 31v36m8-36v36m8-36v36m8-36v36")
	]),
	rollingToolChest: machine("Carro de ferramentas aberto", 1.15, .7, [
		rect$2(4, 22, 87, 70, 3),
		rect$2(9, 5, 77, 18),
		rect$2(9, 28, 76, 45, 2),
		...[
			18,
			35,
			52,
			69
		].map((x) => line$1("M" + x + " 61v-20l-4-5 2-4 3 4 4-4 2 4-5 5")),
		rect$2(21, 80, 51, 5),
		rect$2(91, 33, 5, 35)
	]),
	tireChanger: machine("Desmontadora de pneus", 1.15, 1.35, [
		rect$2(8, 10, 79, 80, 5),
		circle$2(43, 54, 30),
		circle$2(43, 54, 18),
		circle$2(43, 54, 5),
		rect$2(73, 6, 18, 28, 2),
		body("M80 16L46 43L50 48L86 23Z"),
		line$1("M16 82h17m-13-5h13M24 40l5 5m31 18 4 4")
	]),
	partsWashTub: machine("Lavadora de peças com cesto", 1.4, .85, [
		rect$2(4, 6, 92, 87, 4),
		rect$2(9, 14, 63, 68, 5),
		rect$2(14, 20, 52, 54, 3),
		...[
			26,
			36,
			46,
			56,
			66
		].map((y) => line$1("M18 " + y + "h44")),
		line$1("M22 21v49m12-49v49m12-49v49m12-49v49M78 25q10 0 7 12l-16 7"),
		circle$2(82, 62, 6)
	]),
	pipeBender: machine("Curvadora de tubos", 1.65, 1, [
		rect$2(7, 16, 80, 69, 4),
		circle$2(42, 46, 18),
		circle$2(42, 46, 6),
		circle$2(20, 65, 7),
		circle$2(64, 53, 7),
		body("M39 42L91 12L95 19L45 51Z"),
		line$1("M9 73l26-9q18-3 19-25l1-24")
	]),
	drillBitRack: machine("Berço de brocas helicoidais", 2.3, .9, [
		rect$2(8, 10, 9, 80),
		rect$2(79, 10, 9, 80),
		...[
			22,
			48,
			73
		].flatMap((y) => [body("M4 " + y + "l9-6h75l8 6-8 5H13Z"), line$1("M22 " + (y - 5) + "l8 9m5-9 8 9m5-9 8 9m5-9 8 9")])
	]),
	wheelBalancer: machine("Balanceadora de rodas", 1.3, .9, [
		rect$2(5, 12, 58, 77, 5),
		rect$2(10, 19, 35, 27, 2),
		rect$2(14, 23, 27, 15),
		rect$2(60, 43, 32, 10),
		rect$2(68, 17, 18, 64, 6),
		line$1("M74 22v54m6-54v54M12 65h31m-31 7h31"),
		circle$2(52, 65, 4)
	]),
	cableCrimper: machine("Prensa de terminais de cabo", .95, .68, [
		rect$2(6, 12, 86, 78, 3),
		body("M17 24H57V36H32V61H57V74H17Z"),
		rect$2(39, 42, 24, 13, 1),
		rect$2(63, 33, 20, 31, 4),
		line$1("M45 47h12M70 33l9-19 4 2-6 20"),
		circle$2(20, 79, 3)
	]),
	creeperTrolley: machine("Esteira de mecânico com encosto", .55, 1.1, [
		...[
			17,
			48,
			77
		].flatMap((y) => [rect$2(5, y, 11, 12, 3), rect$2(84, y, 11, 12, 3)]),
		rect$2(13, 4, 74, 91, 12),
		rect$2(24, 10, 52, 20, 6),
		body("M24 38Q50 45 76 38L73 77Q50 89 27 77Z"),
		line$1("M32 54q18 6 36 0")
	])
};
//#endregion
//#region src/blueprints/outpost-clinic.js
var med = (name, w, h, shapes) => ({
	name,
	w,
	h,
	category: "medical",
	shapes
});
var lab$1 = (name, w, h, shapes) => ({
	name,
	w,
	h,
	category: "laboratory",
	shapes
});
var outpostClinic = {
	dentalChair: med("Cadeira odontológica articulada", 1.65, 1.85, [
		rect$2(18, 20, 45, 63, 12),
		rect$2(23, 6, 34, 18, 7),
		rect$2(24, 64, 32, 28, 6),
		rect$2(12, 40, 8, 24, 3),
		rect$2(61, 40, 8, 24, 3),
		circle$2(82, 26, 10),
		line$1("M82 36v23L65 70M17 27L9 19l8-10"),
		rect$2(12, 6, 12, 6, 2)
	]),
	dialysisCart: med("Unidade de diálise", .88, .74, [
		rect$2(5, 6, 61, 88, 5),
		rect$2(11, 13, 47, 24, 3),
		rect$2(15, 17, 37, 12),
		circle$2(24, 54, 10),
		circle$2(48, 57, 7),
		line$1("M24 45Q75 26 80 53T65 82M48 64q40 24 42-14"),
		rect$2(12, 75, 44, 10, 2)
	]),
	hyperbaricTube: med("Câmara hiperbárica horizontal", 2.8, 1.25, [
		rect$2(9, 14, 81, 72, 29),
		rect$2(17, 23, 60, 54, 19),
		circle$2(34, 50, 10),
		circle$2(59, 50, 10),
		rect$2(80, 18, 7, 63, 2),
		rect$2(88, 34, 9, 31, 2),
		line$1("M15 74l-5 11m61-9 5 9M24 20h43")
	]),
	instrumentTray: med("Mesa de instrumentação cirúrgica", 1.2, .65, [
		rect$2(3, 10, 94, 79, 5),
		rect$2(8, 16, 84, 67, 3),
		circle$2(20, 34, 7),
		circle$2(31, 34, 7),
		line$1("M22 39l15 32m-8-32-10 32M48 24v33l-4 15m4-15 5 15M65 24v48m14-48v48"),
		rect$2(60, 24, 10, 10, 2)
	]),
	infusionTree: med("Suporte múltiplo de infusão", .68, .68, [
		...[
			0,
			72,
			144,
			216,
			288
		].map((a) => ({
			...body("M47 51L47 87L52 92L54 50Z"),
			transform: "rotate(" + a + " 50 50)"
		})),
		rect$2(15, 18, 24, 35, 5),
		rect$2(61, 22, 22, 31, 5),
		line$1("M28 19v-7h45v10M50 13v36M27 53q-6 21 12 21"),
		circle$2(50, 50, 6)
	]),
	autoclave: lab$1("Autoclave de bancada", .95, .85, [
		rect$2(4, 6, 92, 87, 6),
		circle$2(42, 49, 31),
		circle$2(42, 49, 25),
		rect$2(20, 45, 44, 7, 2),
		rect$2(77, 15, 12, 19, 2),
		circle$2(83, 49, 5),
		line$1("M76 67h14m-14 7h14")
	]),
	slideArchive: lab$1("Arquivo de lâminas histológicas", 1.05, .62, [
		rect$2(3, 5, 94, 89, 2),
		rect$2(8, 13, 39, 74),
		...[
			19,
			29,
			39,
			49,
			59,
			69
		].map((y) => line$1("M13 " + y + "h29")),
		rect$2(53, 9, 38, 40),
		rect$2(59, 18, 26, 9),
		rect$2(53, 53, 38, 33),
		rect$2(60, 64, 24, 6)
	]),
	orbitalShaker: lab$1("Agitador orbital de frascos", .85, .7, [
		rect$2(5, 9, 90, 82, 5),
		rect$2(10, 14, 70, 62, 4),
		...[
			[25, 33],
			[47, 35],
			[66, 56],
			[31, 59]
		].flatMap(([x, y]) => [circle$2(x, y, 9), circle$2(x, y, 4)]),
		line$1("M20 84h41"),
		circle$2(85, 80, 5)
	]),
	spectrometer: lab$1("Espectrômetro de bancada óptica", 1.7, .8, [
		rect$2(3, 9, 94, 83, 3),
		rect$2(8, 17, 55, 53, 2),
		circle$2(20, 43, 7),
		body("M37 30L48 55H30Z"),
		line$1("M27 43h8m10 0 14-11M11 80h44"),
		rect$2(69, 17, 21, 25, 2),
		circle$2(79, 61, 7)
	]),
	anaerobicDrum: lab$1("Jarra anaeróbica com regulador", .82, .64, [
		circle$2(35, 52, 29),
		circle$2(35, 52, 23),
		rect$2(12, 47, 47, 8, 2),
		circle$2(34, 36, 5),
		rect$2(68, 18, 22, 65, 9),
		circle$2(79, 18, 7),
		line$1("M40 33Q52 6 69 19M74 48h10m-10 7h10")
	])
};
//#endregion
//#region src/blueprints/outpost-hospitality.js
var piece$1 = (category, name, w, h, shapes) => ({
	category,
	name,
	w,
	h,
	shapes
});
var outpostHospitality = {
	coffeeBrewer: piece$1("bar", "Bateria de café percolado", 1.15, .56, [rect$2(3, 10, 94, 79, 3), ...[24, 72].flatMap((x) => [
		circle$2(x, 43, 16),
		circle$2(x, 43, 11),
		rect$2(x - 3, 58, 6, 14),
		line$1("M" + (x - 13) + " 78h26")
	])]),
	crushedIceBin: piece$1("bar", "Poço de gelo com escotilha corrida", .9, .68, [
		rect$2(4, 9, 92, 82, 3),
		rect$2(10, 16, 80, 65, 3),
		rect$2(48, 16, 42, 65, 2),
		rect$2(50, 35, 5, 23, 1),
		line$1("M15 37l9-8 8 11-9 8ZM26 60l9-12 7 6-6 13Z")
	]),
	arcadeRide: piece$1("entertainment", "Simulador de corrida com cabine", 1.05, 1.85, [
		body("M14 5H86L91 32L76 45V89L64 96H32L20 85V44L9 31Z"),
		rect$2(20, 11, 60, 19, 4),
		circle$2(48, 39, 10),
		line$1("M39 39h18m-9 0v8"),
		rect$2(29, 61, 40, 21, 7),
		rect$2(27, 80, 44, 9, 3),
		rect$2(73, 51, 6, 12)
	]),
	reelProjector: piece$1("entertainment", "Projetor de cinema de bobinas", 1.28, .84, [
		rect$2(17, 36, 67, 45, 4),
		circle$2(27, 27, 18),
		circle$2(70, 25, 19),
		...[27, 70].map((x) => circle$2(x, 26, 5)),
		body("M80 52l15-5v27l-15-5Z"),
		line$1("M28 45l13 11 15-15M22 68h43")
	]),
	cardShuffler: piece$1("casino", "Distribuidor mecânico de cartas", .6, .42, [
		body("M8 12H73L94 53V85H17L6 59Z"),
		rect$2(14, 19, 44, 34, 2),
		line$1("M18 25h33m-33 5h33m-33 5h33"),
		body("M34 56H82L86 71H39Z"),
		rect$2(44, 73, 30, 8, 2)
	]),
	chipSorter: piece$1("casino", "Separadora de fichas", 1.24, .8, [
		rect$2(3, 9, 94, 82, 4),
		circle$2(27, 40, 18),
		circle$2(27, 40, 7),
		...[
			49,
			63,
			77
		].flatMap((x) => [rect$2(x, 22, 10, 53, 4), circle$2(x + 5, 69, 4)]),
		line$1("M12 74h26")
	]),
	dumplingSteamer: piece$1("galley", "Estação de cocção a vapor", 1.05, .75, [
		rect$2(3, 8, 94, 84, 4),
		...[27, 71].flatMap((x) => [
			circle$2(x, 43, 20),
			circle$2(x, 43, 16),
			line$1("M" + (x - 8) + " 43h16m-8-9v18")
		]),
		rect$2(13, 73, 52, 8, 2),
		circle$2(80, 76, 5)
	]),
	spiralMixer: piece$1("galley", "Amassadeira de cuba espiral", .85, 1.1, [
		rect$2(12, 5, 69, 88, 10),
		circle$2(47, 57, 29),
		circle$2(47, 57, 23),
		body("M26 15H64L54 51H40Z"),
		line$1("M47 49q16 1 8 15t-17-3"),
		circle$2(70, 19, 4)
	]),
	rotisserie: piece$1("galley", "Assador de espetos rotativos", 1.68, .84, [
		rect$2(3, 9, 94, 83, 3),
		rect$2(9, 17, 70, 64, 2),
		...[
			29,
			49,
			69
		].map((y) => line$1("M12 " + y + "h63m-58-4 6 8m11-8 6 8m11-8 6 8")),
		circle$2(88, 30, 4),
		circle$2(88, 48, 4)
	]),
	canPress: piece$1("galley", "Compactador de latas", .75, .8, [
		rect$2(8, 6, 83, 88, 4),
		rect$2(16, 18, 52, 58, 2),
		rect$2(19, 22, 46, 21),
		line$1("M22 61l10-11 7 9 10-9 12 13M74 20v43"),
		rect$2(70, 10, 11, 15, 2),
		rect$2(30, 80, 27, 5)
	])
};
//#endregion
//#region src/blueprints/outpost-engineering.js
var part$3 = (name, w, h, shapes) => ({
	name,
	w,
	h,
	category: "engineering",
	shapes
});
var outpostEngineering = {
	flywheelBank: part$3("Banco de volantes de inércia", 3, 1.25, [
		rect$2(5, 36, 90, 25, 3),
		rect$2(2, 42, 96, 12),
		...[
			22,
			41,
			60,
			79
		].flatMap((x) => [rect$2(x - 5, 7, 10, 85, 5), line$1("M" + x + " 13v74")])
	]),
	airScrubber: part$3("Depurador de ar com cartuchos", 1.8, 1.25, [
		rect$2(7, 6, 85, 88, 5),
		...[
			25,
			48,
			71
		].flatMap((x) => [rect$2(x - 7, 20, 15, 55, 6), line$1("M" + (x - 4) + " 26v41m5-41v41")]),
		rect$2(2, 34, 8, 29),
		rect$2(90, 34, 8, 29),
		line$1("M16 82h66")
	]),
	centrifugalSeparator: part$3("Separador ciclônico", 1.9, 1.42, [
		circle$2(48, 50, 33),
		circle$2(48, 50, 22),
		circle$2(48, 50, 9),
		body("M5 9H48Q73 11 80 32L63 29Q54 21 39 22H5Z"),
		rect$2(65, 67, 25, 13, 2),
		line$1("M29 60q5 14 23 12")
	]),
	batterySled: part$3("Trenó de baterias de emergência", 1.85, 1.04, [
		rect$2(3, 7, 94, 86, 4),
		...[
			10,
			37,
			64
		].flatMap((x) => [
			rect$2(x, 16, 24, 58, 2),
			circle$2(x + 5, 24, 2),
			circle$2(x + 18, 24, 2),
			line$1("M" + (x + 4) + " 61h15")
		]),
		line$1("M15 81h65M15 24h12m15 0h12m15 0h12")
	]),
	busbarCabinet: part$3("Armário de barramentos elétricos", 1.6, .78, [
		rect$2(3, 8, 94, 85, 2),
		...[
			24,
			48,
			72
		].flatMap((y) => [rect$2(11, y, 77, 6, 1), ...[
			20,
			48,
			78
		].map((x) => circle$2(x, y + 3, 2))]),
		line$1("M6 14v68M94 14v68")
	]),
	expansionBellows: part$3("Compensador de dilatação axial", 1.65, .8, [
		rect$2(2, 30, 96, 42, 4),
		rect$2(6, 17, 7, 67),
		rect$2(87, 17, 7, 67),
		...[
			23,
			32,
			41,
			50,
			59,
			68,
			77
		].map((x) => body("M" + x + " 19l4 6v51l-4 6-3-6V25Z"))
	]),
	hoseReel: part$3("Carretel de mangueira de incêndio", .92, .72, [
		rect$2(7, 13, 80, 72, 5),
		circle$2(45, 47, 30),
		circle$2(45, 47, 23),
		circle$2(45, 47, 16),
		circle$2(45, 47, 7),
		line$1("M21 66q8 22 38 15t29-15"),
		body("M82 68l5-12 7 3-6 12Z")
	]),
	lubeSkid: part$3("Unidade de lubrificação central", 1.45, .95, [
		rect$2(3, 7, 94, 85, 3),
		circle$2(29, 43, 19),
		circle$2(29, 43, 6),
		rect$2(56, 22, 28, 32, 5),
		line$1("M48 42h7M70 55v16H24"),
		...[
			29,
			44,
			59,
			74
		].map((x) => rect$2(x, 68, 5, 14))
	]),
	furnaceCrucible: part$3("Cadinho de indução", 1.65, 1.45, [
		rect$2(4, 18, 18, 61, 4),
		circle$2(55, 50, 37),
		circle$2(55, 50, 29),
		circle$2(55, 50, 20),
		body("M74 24l12-12-3 20Z"),
		line$1("M8 31h10m-10 9h10m-10 9h10M21 66q12 13 19 8")
	]),
	umbilicalDock: part$3("Tomada de umbilical de serviço", 1.1, .75, [
		rect$2(3, 7, 94, 84, 6),
		circle$2(32, 48, 21),
		...[
			[25, 45],
			[39, 45],
			[32, 55]
		].map(([x, y]) => circle$2(x, y, 3)),
		rect$2(61, 19, 25, 56, 4),
		line$1("M65 28h17m-17 10h17m-17 10h17m-17 10h17")
	])
};
//#endregion
//#region src/blueprints/outpost-crew.js
var part$2 = (category, name, w, h, shapes) => ({
	category,
	name,
	w,
	h,
	shapes
});
var outpostCrew = {
	teleprinter: part$2("command", "Teletipo com rolo contínuo", .87, .75, [
		rect$2(5, 11, 89, 79, 4),
		rect$2(13, 7, 72, 15, 5),
		body("M20 21h59l-3 29H23Z"),
		line$1("M28 28h39m-39 7h32"),
		rect$2(14, 56, 71, 23, 3),
		line$1("M20 62h56m-56 8h48")
	]),
	tapeReader: part$2("command", "Leitor de fita perfurada", .85, .65, [
		rect$2(3, 12, 94, 76, 4),
		circle$2(23, 38, 15),
		circle$2(23, 38, 5),
		rect$2(46, 23, 29, 32, 3),
		body("M21 50L52 42L64 49L28 59Z"),
		line$1("M29 53l19-6m21 7 18 10-7 8-16-10"),
		circle$2(85, 32, 4)
	]),
	patchBay: part$2("command", "Mesa de comutação telefônica", 1.65, .88, [
		rect$2(3, 8, 94, 83, 4),
		...[
			18,
			35,
			52,
			69,
			83
		].flatMap((x) => [circle$2(x, 31, 4), circle$2(x, 51, 4)]),
		line$1("M18 31q0 46 34 20M35 51q8 39 34-20M17 73h65"),
		rect$2(9, 14, 82, 6)
	]),
	chartLightTable: part$2("command", "Mesa luminosa de cartas estelares", 1.8, 1.15, [
		rect$2(4, 7, 92, 86, 4),
		rect$2(10, 14, 72, 64, 2),
		line$1("M15 61l15-26 18 13 27-19M18 72l43-48"),
		...[
			[30, 35],
			[48, 48],
			[75, 29]
		].map(([x, y]) => circle$2(x, y, 2.4)),
		circle$2(89, 35, 3),
		circle$2(89, 50, 3),
		rect$2(22, 82, 47, 4)
	]),
	deadmanStation: part$2("command", "Pedestal de autorização de lançamento", .8, .68, [
		body("M6 23L16 10H84L95 25V84H6Z"),
		rect$2(19, 22, 61, 24, 4),
		rect$2(25, 28, 48, 10),
		...[23, 76].flatMap((x) => [circle$2(x, 64, 8), line$1("M" + x + " 60v8")]),
		rect$2(40, 56, 20, 14, 2)
	]),
	foldScreen: part$2("quarters", "Divisória acústica dobrável", 1.95, .55, [
		body("M3 58L28 18L51 55L74 18L97 56L93 65L74 34L51 72L28 35L7 69Z"),
		...[
			28,
			51,
			74
		].map((x, i) => circle$2(x, i === 1 ? 63 : 26, 3)),
		rect$2(3, 62, 7, 15, 2),
		rect$2(90, 60, 7, 16, 2)
	]),
	hammock: part$2("quarters", "Rede de descanso entre suportes", 2.5, .88, [
		rect$2(3, 15, 6, 71, 2),
		rect$2(91, 15, 6, 71, 2),
		body("M7 50Q28 39 34 23Q50 12 69 25Q79 42 93 50Q79 56 68 76Q49 91 32 74Q20 55 7 50Z"),
		line$1("M12 50q36-28 75 0M15 51q35 23 70 0M33 30l-7 24m42-25 7 25")
	]),
	footlockerBench: part$2("quarters", "Baú aberto de pertences", 1.15, .95, [
		rect$2(6, 5, 88, 35, 4),
		rect$2(6, 44, 88, 50, 4),
		rect$2(12, 50, 38, 36, 3),
		body("M57 57l20-5 9 21-20 6Z"),
		line$1("M11 12h78m-78 7h78M16 88h66"),
		rect$2(41, 84, 18, 6, 1)
	]),
	bookCarousel: part$2("quarters", "Biblioteca giratória de bordo", .95, .95, [
		circle$2(50, 50, 44),
		circle$2(50, 50, 12),
		...[
			0,
			90,
			180,
			270
		].flatMap((a) => [
			rect$2(44, 10, 7, 24, 1),
			rect$2(53, 12, 6, 20, 1),
			rect$2(35, 14, 6, 17, 1)
		].map((s) => ({
			...s,
			transform: "rotate(" + a + " 50 50)"
		})))
	]),
	chessPedestal: part$2("quarters", "Mesa de xadrez magnético", .85, .85, [
		rect$2(4, 5, 92, 90, 6),
		rect$2(15, 15, 70, 70),
		...Array.from({ length: 8 }, (_, i) => Array.from({ length: 4 }, (_, j) => ({
			...rect$2(15 + (2 * j + i % 2) * 8.75, 15 + i * 8.75, 8.75, 8.75),
			fill: "currentColor",
			stroke: "none",
			opacity: .33
		}))).flat(),
		circle$2(37, 45, 3),
		circle$2(62, 62, 3)
	])
};
//#endregion
//#region src/blueprints/outpost-transit.js
var piece = (category, name, w, h, shapes) => ({
	category,
	name,
	w,
	h,
	shapes
});
var outpostTransit = {
	parcelChute: piece("transit", "Rampa de triagem de encomendas", 2.6, 1.3, [
		body("M2 10H96L86 90H32Z"),
		line$1("M8 16l28 68h45l9-68M16 27h71m-66 13h64m-58 15h56"),
		rect$2(37, 63, 26, 14, 2)
	]),
	platformClock: piece("transit", "Relógio duplo de plataforma", 1.4, .45, [
		rect$2(43, 9, 14, 82, 2),
		rect$2(4, 22, 39, 54, 6),
		rect$2(57, 22, 39, 54, 6),
		line$1("M10 28v41m79-41v41M46 16h8m-8 67h8")
	]),
	boardingBridge: piece("transit", "Passadiço telescópico de embarque", 4.4, 1.6, [
		rect$2(1, 10, 39, 80, 2),
		rect$2(40, 16, 35, 68),
		rect$2(75, 22, 24, 56),
		...[
			8,
			17,
			26,
			35
		].map((x) => line$1("M" + x + " 14v72")),
		line$1("M44 23h27m-27 54h27M80 31h14m-14 37h14")
	]),
	lockerWall: piece("transit", "Bateria de guarda-volumes", 2.45, .74, [rect$2(2, 9, 96, 81, 2), ...[
		6,
		28,
		50,
		72
	].flatMap((x) => [
		rect$2(x, 15, 20, 65),
		rect$2(x + 11, 65, 5, 8, 1),
		line$1("M" + (x + 3) + " 23h13")
	])]),
	railSignal: piece("transit", "Sinaleiro ferroviário de três focos", 1.05, .55, [
		rect$2(42, 49, 16, 44, 2),
		rect$2(7, 13, 86, 44, 11),
		...[
			24,
			50,
			76
		].flatMap((x) => [circle$2(x, 35, 10), line$1("M" + (x - 9) + " 29q9-16 18 0")]),
		rect$2(30, 85, 40, 9)
	]),
	cablePallet: piece("cargo", "Palete de condutores enrolados", 1.4, 1.1, [
		rect$2(4, 6, 92, 88, 2),
		...[29, 68].flatMap((x) => [
			circle$2(x, 48, 17),
			circle$2(x, 48, 12),
			circle$2(x, 48, 7),
			rect$2(x - 2, 23, 4, 50)
		]),
		line$1("M9 83h82")
	]),
	glassCarrier: piece("cargo", "Cavalete de painéis de vidro", 2, .85, [
		rect$2(3, 10, 94, 78, 2),
		...[
			22,
			30,
			38,
			46,
			54,
			62
		].map((y) => line$1("M9 " + y + "h81")),
		rect$2(16, 13, 6, 70),
		rect$2(77, 13, 6, 70),
		line$1("M12 78l34-13m16 9 12-5")
	]),
	drumClamp: piece("cargo", "Garra de içamento de tambores", 1.15, 1.15, [
		body("M6 40Q10 11 44 8L41 17Q17 22 16 44Z"),
		body("M94 40Q90 11 56 8L59 17Q83 22 84 44Z"),
		body("M12 58L42 79H58L87 56L92 65L60 91H39L5 65Z"),
		line$1("M13 35l36 14 36-14M49 49v32"),
		circle$2(49, 48, 7)
	]),
	toolTransitCase: piece("cargo", "Maleta aberta de instrumentos", .85, .72, [
		rect$2(6, 5, 88, 38, 4),
		rect$2(6, 46, 88, 49, 4),
		line$1("M12 11h76m-76 8h76m-76 8h76"),
		rect$2(12, 52, 26, 35, 4),
		circle$2(25, 65, 7),
		rect$2(44, 54, 39, 11, 3),
		rect$2(44, 72, 32, 8, 2)
	]),
	gasBottleNest: piece("cargo", "Gaiola de cilindros de gás", 1.55, 1.05, [
		rect$2(2, 4, 96, 92, 2),
		...[
			20,
			49,
			78
		].flatMap((x) => [23, 66].flatMap((y) => [
			circle$2(x, y, 12),
			circle$2(x, y, 5),
			line$1("M" + (x - 3) + " " + y + "h6")
		])),
		line$1("M5 47h90M7 88h84")
	])
};
//#endregion
//#region src/blueprints/outpost-services.js
var part$1 = (category, name, w, h, shapes) => ({
	category,
	name,
	w,
	h,
	shapes
});
var outpostServices = {
	ballisticScreen: part$1("security", "Biombo balístico sobre rodízios", 1.5, .68, [
		rect$2(5, 28, 90, 16, 3),
		rect$2(22, 23, 56, 7, 1),
		rect$2(12, 17, 7, 61, 1),
		rect$2(81, 17, 7, 61, 1),
		...[12, 81].flatMap((x) => [circle$2(x + 3, 16, 4), circle$2(x + 3, 80, 4)]),
		line$1("M30 36h40")
	]),
	keyCabinet: part$1("security", "Claviculário de custódia", .78, .58, [
		rect$2(5, 8, 60, 84, 3),
		body("M66 10l29 13v69L66 80Z"),
		...[
			17,
			34,
			51
		].flatMap((x) => [24, 54].flatMap((y) => [circle$2(x, y, 3), line$1("M" + x + " " + (y + 3) + "v12h5v-4")])),
		line$1("M73 27l15 6m-15 4 15 6")
	]),
	shieldBarrier: part$1("security", "Bloqueador veicular retrátil", 3.1, 1.2, [
		rect$2(2, 9, 96, 82, 2),
		body("M8 20H92L83 69H17Z"),
		...[
			16,
			32,
			48,
			64,
			80
		].map((x) => line$1("M" + x + " 26l-4 26")),
		line$1("M10 78h80"),
		circle$2(8, 84, 2),
		circle$2(91, 84, 2)
	]),
	restraintChair: part$1("detention", "Cadeira de contenção com travas", .95, 1.1, [
		rect$2(20, 10, 60, 77, 8),
		rect$2(26, 6, 47, 17, 5),
		rect$2(28, 36, 44, 38, 5),
		...[12, 75].flatMap((x) => [rect$2(x, 33, 13, 37, 4), rect$2(x - 1, 42, 15, 7, 2)]),
		rect$2(26, 66, 49, 7, 1),
		rect$2(27, 82, 18, 11, 2),
		rect$2(55, 82, 18, 11, 2)
	]),
	passThrough: part$1("detention", "Guichê de transferência de bandejas", 1.1, .55, [
		rect$2(3, 10, 94, 81, 3),
		rect$2(11, 18, 78, 62, 2),
		rect$2(19, 26, 59, 45, 4),
		line$1("M7 44h7m71 0h7M27 34h42"),
		rect$2(37, 77, 24, 6, 2)
	]),
	eyeWash: part$1("sanitary", "Lava-olhos de emergência", .65, .55, [
		body("M5 27Q50 5 95 27V53Q91 87 50 90Q8 87 5 53Z"),
		circle$2(29, 46, 9),
		circle$2(71, 46, 9),
		line$1("M29 55q21 24 42 0"),
		circle$2(50, 76, 4),
		rect$2(78, 15, 12, 10, 2)
	]),
	bootWasher: part$1("sanitary", "Passagem de lavagem de botas", 1.5, .85, [
		rect$2(3, 8, 94, 83, 2),
		...[
			18,
			40,
			62
		].flatMap((x) => [rect$2(x, 17, 13, 63, 4), ...[
			26,
			38,
			50,
			62,
			73
		].map((y) => line$1("M" + (x - 3) + " " + y + "h19"))]),
		line$1("M87 14v71M8 16v68")
	]),
	linenPress: part$1("sanitary", "Prensa de rouparia", 1.6, .85, [
		rect$2(5, 11, 90, 78, 3),
		rect$2(12, 19, 70, 43, 13),
		rect$2(14, 66, 66, 10, 3),
		line$1("M22 40h50M24 71h46"),
		rect$2(86, 25, 5, 24),
		circle$2(88, 65, 4)
	]),
	oarTrainer: part$1("fitness", "Remo ergométrico", 2.3, .65, [
		circle$2(17, 48, 14),
		rect$2(26, 43, 68, 11, 2),
		rect$2(54, 28, 19, 40, 5),
		rect$2(31, 16, 7, 22, 2),
		rect$2(31, 61, 7, 22, 2),
		line$1("M19 36l16-15m-5-5 12 11M89 26v46")
	]),
	boxingBag: part$1("fitness", "Saco de boxe com suporte", 1.05, 1.18, [
		body("M8 8H86V17H48L38 34L29 31L34 17H8Z"),
		circle$2(51, 60, 25),
		circle$2(51, 60, 19),
		line$1("M32 35l13 8m4-26 4 20M60 40l6-15M43 80q7 8 15-1")
	])
};
//#endregion
//#region src/blueprints/outpost-market.js
var part = (category, name, w, h, shapes) => ({
	category,
	name,
	w,
	h,
	shapes
});
var outpostMarket = {
	textileRolls: part("market", "Expositor de rolos de tecido", 1.3, .8, [
		rect$2(3, 9, 94, 82, 2),
		...[
			23,
			43,
			64
		].flatMap((y) => [
			rect$2(12, y, 75, 13, 5),
			circle$2(84, y + 6, 4),
			line$1("M17 " + (y + 4) + "h52")
		]),
		body("M19 69h37l8 19H26Z")
	]),
	weighScale: part("market", "Balança de balcão com pesos", .9, .5, [
		rect$2(4, 54, 92, 35, 4),
		circle$2(26, 42, 19),
		circle$2(72, 42, 16),
		line$1("M25 44l23-22 24 21M48 24v44"),
		...[
			52,
			65,
			80
		].map((x, i) => circle$2(x, 70, 3 + i))
	]),
	spiceBins: part("market", "Ilha de dispensadores a granel", 1.44, .68, [rect$2(3, 8, 94, 83, 3), ...[
		8,
		37,
		66
	].flatMap((x) => [
		body("M" + x + " 14h25v32l-8 15h-9l-8-15Z"),
		rect$2(x + 7, 61, 11, 8, 1),
		rect$2(x + 2, 76, 22, 6, 1)
	])]),
	fishIceBed: part("market", "Mostruário de pescado em gelo", 1.55, .78, [
		rect$2(2, 6, 96, 87, 5),
		rect$2(7, 12, 86, 73, 3),
		...[[14, 35], [46, 59]].map(([x, y]) => body("M" + x + " " + y + "q13-16 29 0-14 13-29 0l-7 6v-13Z")),
		line$1("M67 24l6-5 8 8-7 4ZM13 66l9-4 5 8-10 6Z")
	]),
	pressureKegs: part("market", "Expositor de refis de oxigênio", .98, .66, [rect$2(3, 9, 94, 82, 3), ...[
		18,
		40,
		62,
		82
	].flatMap((x) => [
		rect$2(x - 7, 24, 14, 50, 6),
		rect$2(x - 3, 16, 6, 10, 1),
		line$1("M" + (x - 5) + " 41h10m-10 6h10")
	])]),
	parcelWrap: part("market", "Estação de embrulho e lacre", 1.1, .65, [
		rect$2(3, 9, 94, 84, 3),
		rect$2(9, 16, 12, 65, 5),
		body("M20 20l46 8-4 48-42-7Z"),
		rect$2(65, 19, 25, 12, 3),
		circle$2(80, 60, 10),
		circle$2(80, 60, 4),
		line$1("M69 61l-9 7")
	]),
	musicStand: part("decor", "Estante de partituras", .68, .55, [
		line$1("M50 55L17 87M50 55l34 30M50 55V13"),
		body("M8 23Q30 16 49 23Q70 16 92 23V62Q71 57 49 64Q28 57 8 63Z"),
		line$1("M50 25v32M16 33h26m-26 7h26m16-7h25m-25 7h25")
	]),
	umbrellaRack: part("decor", "Porta-guarda-chuvas coletivo", .83, .44, [rect$2(5, 11, 90, 78, 6), ...[
		[22, 37],
		[43, 59],
		[66, 35],
		[80, 61]
	].flatMap(([x, y]) => [circle$2(x, y, 8), line$1("M" + x + " " + y + "q-3-14 4-14t5 8")])]),
	modelShipCase: part("decor", "Maquete de nave em redoma", 1.18, .65, [
		rect$2(3, 9, 94, 83, 8),
		rect$2(8, 15, 84, 69, 7),
		body("M14 52l14-12 29-4 23 6 9 8-17 7-25 3-16-2-11 6 3-11Z"),
		line$1("M34 45l31-3m-25 12 25-4M18 76h16")
	]),
	rugRollCart: part("decor", "Carrinho de cenografia com tapetes", 1.4, .8, [
		rect$2(3, 17, 94, 71, 3),
		...[
			24,
			44,
			65
		].flatMap((y) => [rect$2(10, y, 76, 15, 6), circle$2(82, y + 7, 4)]),
		rect$2(22, 15, 5, 72),
		rect$2(65, 15, 5, 72),
		line$1("M89 30l7-13V9H78")
	])
};
//#endregion
//#region src/blueprints/stage-assets.js
var stage = (name, w, h, shapes) => ({
	name,
	w,
	h,
	category: "entertainment",
	subgroup: "Palco e bastidores",
	shapes
});
var fabric = {
	...rect$2(0, 0, 100, 100),
	stroke: "none"
};
var deck = [fabric, line$1("M0 1h100M0 5h100M0 95h100M0 99h100")];
var stageAssets = {
	stageClothCenter: stage("Palco · piso sem borda", 2, 2, [fabric]),
	stageClothEdge: stage("Palco · uma lateral", 2, 2, [fabric, line$1("M0 1H100M0 5H100")]),
	stageClothCorner: stage("Palco · quina externa em L", 2, 2, [fabric, line$1("M1 100V1H100M5 100V5H100")]),
	stageClothReturn: stage("Palco · quina interna de recuo", 2, 2, [fabric, line$1("M100 99H99V100M100 95H95V100")]),
	stageDeckBay: stage("Tablado · módulo central", 2, 2, deck),
	stageWing: stage("Tablado · lateral reversível", 1, 2, [
		...deck,
		line$1("M1 0v100M7 1v94"),
		line$1("M2 14l4 7-4 7m0 42 4 7-4 7")
	]),
	stageAccessSteps: stage("Escada avulsa de palco", 2, 1, [
		rect$2(0, 0, 100, 100),
		line$1("M0 20h100M0 45h100M0 70h100M0 95h100"),
		line$1("M4 4v90M96 4v90")
	]),
	runwayBay: stage("Passarela · trecho reto", 2, 2, [fabric, line$1("M1 0v100M5 0v100M95 0v100M99 0v100")]),
	runwayHead: stage("Passarela · cabeceira", 2, 2, [{
		...body("M0 0H100V75L76 100H24L0 75Z"),
		stroke: "none"
	}, line$1("M1 0V75L24 99H76L99 75V0M5 0V73L26 95H74L95 73V0")]),
	poleStage: stage("Palco de pole dance", 2, 2, [
		body("M3 19Q3 8 16 8H84Q97 8 97 19V53C97 75 81 91 62 92H38C19 91 3 75 3 53Z"),
		line$1("M4 56Q10 84 38 87H62Q88 83 96 56"),
		{
			...body("M49 48Q50 47 52 49L67 69Q68 72 65 70Z"),
			fill: "currentColor",
			opacity: .24,
			stroke: "none"
		},
		circle$2(50, 48, 4.8),
		{
			...circle$2(50, 48, 2),
			fill: "currentColor"
		},
		...[
			19,
			32,
			68,
			81
		].map((x) => ({
			...circle$2(x, 14, 1.2),
			fill: "currentColor",
			stroke: "none"
		}))
	]),
	commandPitShell: {
		name: "Poço de comando · acesso rebaixado",
		category: "command",
		w: 5,
		h: 4,
		shapes: [
			rect$2(0, 0, 100, 100, 4),
			line$1("M34 98H3V3H97V98H66M34 94H7V7H93V94H66M34 89H11V11H89V89H66"),
			line$1("M34 99V76H66V99M34 81h32M34 87h32M34 93h32"),
			...[18, 75].map((x) => rect$2(x, 5, 7, 2, 1))
		]
	}
};
//#endregion
//#region src/blueprints/hive-assets.js
var infestation = (name, w, h, shapes) => ({
	name,
	w,
	h,
	category: "infestation",
	shapes
});
var place = (shapes, transform) => shapes.map((s) => ({
	...s,
	transform: transform + " " + (s.transform || "")
}));
var fine = (d) => ({
	...line$1(d),
	strokeWidth: .85
});
var rotate$1 = (shapes, angle) => place(shapes, "rotate(" + angle + " 50 50)");
var closedEgg = [
	body("M49 9C70 7 85 24 86 48C89 73 75 90 53 92C31 94 13 78 13 54C11 31 26 11 49 9Z"),
	line$1("M48 49C47 39 39 28 27 21M48 49C61 45 70 37 78 26M48 49C55 57 64 66 72 82M48 49C36 52 27 63 19 70"),
	fine("M29 17Q46 9 57 14M80 42Q87 64 72 77M35 83Q24 80 20 71M36 31Q42 36 44 43M55 53Q63 59 67 69")
];
var petal = body("M35 36C29 29 27 19 31 11Q37 2 48 4Q56 6 63 13C67 20 64 29 60 36Q48 30 35 36Z");
var openEgg = [
	body("M27 25Q49 9 73 25Q90 43 78 69Q62 89 35 78Q12 65 18 41Z"),
	...[
		1,
		94,
		181,
		271
	].flatMap((a) => rotate$1([petal, fine("M37 30Q33 19 39 11M44 25Q49 18 49 9M59 29Q62 22 58 16")], a)),
	body("M37 38Q49 31 60 38Q69 48 61 59Q49 68 37 58Q30 48 37 38Z"),
	fine("M37 48Q38 39 48 37M59 53Q57 61 48 62")
];
var foldedLegs = [
	body("M38 32Q30 27 27 22Q24 20 22 24L25 35L30 39L26 32L25 26Q30 34 37 37Z"),
	body("M36 40Q27 38 22 33Q18 32 18 36L22 45L28 48L23 41L21 37Q28 44 37 45Z"),
	body("M36 49Q25 51 19 46Q15 45 17 50L22 58L28 60L22 54L20 50Q27 55 37 54Z"),
	body("M39 58Q31 65 24 61L21 59Q18 60 21 65L27 70L33 69L27 66L24 64Q33 69 42 62Z")
];
var tether = [
	body("M2 8C26 6 24 33 42 37S69 29 79 42L96 56Q84 53 74 45C63 35 52 48 38 44S20 18 2 16Z"),
	body("M3 15C24 16 22 41 42 47S64 41 77 57Q84 66 95 68Q82 70 72 61C60 48 52 57 37 53S19 27 3 22Z"),
	line$1("M18 18l-3 4M22 23l-4 4M26 30l-4 4M44 48v5M49 48v6M54 47v6")
];
var hiveAssets = {
	wallResinWeb: infestation("Resina aderida à parede", 2.6, 1, [
		body("M0 2Q20 8 38 4T72 5L99 2L97 10Q79 11 74 16Q62 24 46 16Q23 8 13 21L1 18Z"),
		...place(tether, "translate(32 0) scale(.69 .68)"),
		...place(tether, "translate(12 2) scale(.88 1.02)"),
		...place(tether, "translate(0 7) scale(.81 1.26)"),
		fine("M35 72q3 9 12 12M63 78q6 0 13 8M76 44q8-3 15 1")
	]),
	closedHiveEgg: infestation("Ovo de facehugger fechado", .64, .72, closedEgg),
	openHiveEgg: infestation("Ovo de facehugger aberto", .87, .9, openEgg),
	ovomorphClutch: infestation("Ninho de ovos · eclosão", 2, 1.6, [
		...place(tether, "translate(0 29) scale(.95 .9)"),
		line$1("M8 30Q26 56 48 60T88 87M27 12Q42 28 67 28M13 85Q29 69 45 74"),
		...place(closedEgg, "translate(1 10) scale(.45 .5)"),
		...place(closedEgg, "translate(48 2) scale(.36 .4)"),
		...place(closedEgg, "translate(9 58) scale(.32 .37)"),
		...place(openEgg, "translate(43 41) scale(.55 .56)")
	]),
	splitCocoon: infestation("Casulo rompido", 1.05, 2, [...place(tether, "translate(2 21) scale(.91 .63)"), ...place([
		body("M5 18Q21 22 37 16T65 16L95 19Q80 28 86 45Q94 68 74 81L69 93L57 85Q34 95 19 73Q11 62 15 45Q20 29 5 18Z"),
		body("M26 35Q39 17 59 24Q77 29 78 49Q80 65 65 76Q44 88 28 70Q16 54 26 35Z"),
		body("M29 42Q37 26 53 29L48 36L59 32L66 36L62 42L72 41Q78 60 64 68L63 62L55 73L49 69L42 75Q27 73 25 58L32 58L26 50L33 49Z"),
		fine("M18 32Q31 17 44 20M21 60Q21 76 38 81M67 78Q84 64 82 47M35 37l7-4M31 65l6 4")
	], "translate(0 4) scale(1 .59)")]),
	spentFacehugger: infestation("Facehugger morto", .95, .8, [
		body("M47 63C49 83 69 91 82 81C95 70 93 48 83 45C77 43 75 49 80 52Q72 50 77 44C84 36 94 45 95 58C99 79 84 93 68 92Q45 90 40 65Z"),
		...foldedLegs,
		...place(foldedLegs, "translate(91 0) scale(-1 1)"),
		body("M44 20Q49 17 52 23L53 29Q62 33 59 47L56 59Q54 68 47 70Q37 68 35 58L31 43Q30 32 38 28Z"),
		line$1("M43 27Q37 34 36 44Q37 52 40 57M50 26Q56 35 54 43Q54 50 51 56M45 31Q42 40 45 51T46 64"),
		fine("M40 35l5 3 6-3M38 43l7 3 8-4M41 53l5 3 5-4M48 75l6-4M55 82l5-5M65 87l3-5M76 87l-1-4M87 79l-3-3")
	]),
	boundCrewCocoon: infestation("Tripulante preso à parede", 1.35, 2.05, [...place(tether, "translate(0 12) scale(.96 .68)"), ...place([
		body("M3 10Q26 17 48 9T97 13L87 23Q82 29 89 46Q95 65 78 79L85 90Q68 88 57 80Q42 87 23 82L11 91Q17 78 12 63Q3 48 14 32Q20 21 3 10Z"),
		body("M14 50Q15 37 32 35L44 37L61 34Q80 31 86 48L81 64Q70 62 64 55Q55 64 39 62Q31 56 24 63L17 64Z"),
		line$1("M23 43Q30 37 37 40M66 38Q77 36 80 45M27 49l4 7M71 48l-5 9"),
		body("M37 47Q37 32 50 32Q65 32 66 47Q66 57 60 64L54 69Q48 71 42 64Q36 57 37 47Z"),
		fine("M40 46Q41 36 51 36Q60 36 62 44M43 61Q52 66 60 59"),
		line$1("M10 18Q28 28 26 39M83 19Q70 28 74 37M13 54Q18 69 36 68T57 80M85 56Q82 68 66 71L60 77M23 78Q31 71 40 74")
	], "translate(0 3) scale(1 .59)")]),
	hiveRibSpan: infestation("Arco de costelas alienígenas", 3.7, 1.15, [
		body("M1 3L9 12Q17 24 19 44L17 75L9 94L7 74L2 84L5 51Z"),
		body("M99 5L94 46L98 76L93 70L92 96L81 78L79 49L82 29Z"),
		...[
			0,
			1,
			2,
			3,
			4
		].map((n) => place([body("M8 19C24 5 33 11 46 16S72 28 89 14L94 12L91 21C76 37 59 34 44 23S24 14 10 29Z"), fine("M13 19Q26 9 35 15M64 27Q77 30 88 20")], "translate(0 " + [
			0,
			13,
			24,
			39,
			53
		][n] + ") scale(1 " + [
			1,
			.8,
			1.13,
			.75,
			1
		][n] + ")")).flat(),
		fine("M4 13q9 14 8 25M9 58l-2 18M93 18l-6 20M88 67l4 11")
	])
};
//#endregion
//#region src/blueprints/market-detail-assets.js
var item = (category, name, w, h, shapes) => ({
	category,
	name,
	w,
	h,
	shapes
});
var crate = [
	rect$2(2, 4, 96, 92, 2),
	rect$2(7, 10, 86, 80, 1),
	line$1("M4 18h3m86 0h3M4 82h3m86 0h3")
];
var fruit = (x, y, r) => [circle$2(x, y, r), line$1("M" + x + " " + (y - 1) + "q-2-5 2-6")];
var tin = (x, y) => [
	circle$2(x, y, 11),
	circle$2(x, y, 8.7),
	rect$2(x - 2, y - 4, 4, 6, 2)
];
var page = (x, y, w, h) => [rect$2(x, y, w, h, 1), line$1("M" + (x + 4) + " " + (y + 8) + "h" + w * .57 + "m-" + w * .57 + " 6h" + w * .72)];
var rotate = (shapes, deg, x, y) => shapes.map((s) => ({
	...s,
	transform: "rotate(" + deg + " " + x + " " + y + ")"
}));
var marketDetailAssets = {
	cannedGoodsCase: item("market", "Caixa de conservas", .62, .42, [...crate, ...[
		20,
		49,
		78
	].flatMap((x) => [tin(x, 32), tin(x, 67)]).flat()]),
	orchardProduceCrate: item("market", "Engradado de frutas", .8, .6, [
		...crate,
		...[
			[
				21,
				33,
				11
			],
			[
				44,
				25,
				10
			],
			[
				67,
				33,
				12
			],
			[
				80,
				55,
				10
			],
			[
				54,
				58,
				12
			],
			[
				29,
				57,
				10
			],
			[
				17,
				74,
				8
			],
			[
				45,
				78,
				8
			],
			[
				68,
				79,
				9
			]
		].flatMap((a) => fruit(...a)),
		rect$2(2, 42, 6, 16, 2),
		rect$2(92, 42, 6, 16, 2)
	]),
	fieldRationLot: item("market", "Lote de rações seladas", .76, .5, [...[
		[5, 12],
		[37, 6],
		[66, 18]
	].flatMap(([x, y]) => [
		body("M" + x + " " + y + "h27l-2 8 2 54h-27l2-8Z"),
		line$1("M" + (x + 3) + " " + (y + 6) + "h21m-21 50h21"),
		rect$2(x + 5, y + 20, 16, 18, 1)
	])]),
	vacuumPackTray: item("market", "Bandeja de pacotes a vácuo", .7, .48, [
		rect$2(2, 6, 96, 88, 6),
		rect$2(6, 11, 88, 78, 4),
		...[10, 52].flatMap((x) => [
			rect$2(x, 17, 37, 64, 2),
			body("M" + (x + 6) + " 58q-2-13 9-26l11 3 4 17-12 14Z"),
			line$1("M" + (x + 3) + " 21h30m-30 55h30"),
			rect$2(x + 20, 62, 11, 8, 1)
		])
	]),
	stackedTravelCases: item("cargo", "Malas rígidas empilhadas", 1.05, .75, [
		rect$2(3, 32, 91, 62, 6),
		rect$2(8, 37, 80, 50, 4),
		rect$2(40, 88, 19, 9, 3),
		...rotate([
			rect$2(10, 9, 78, 57, 7),
			rect$2(15, 14, 68, 44, 4),
			rect$2(36, 4, 23, 7, 2),
			line$1("M23 20v32m7-32v32m38-32v32m7-32v32"),
			rect$2(21, 59, 9, 6),
			rect$2(67, 59, 9, 6)
		], -7, 48, 37)
	]),
	tiedMailSacks: item("cargo", "Malotes de despacho", .95, .72, [...[[4, 20], [48, 9]].flatMap(([x, y]) => [
		body("M" + (x + 12) + " " + (y + 10) + "l-4-9 19 1-4 9q18 13 16 44-2 16-19 18-20-2-20-17 0-31 12-46Z"),
		line$1("M" + (x + 10) + " " + (y + 10) + "h15m-13 4h10"),
		rect$2(x + 10, y + 33, 16, 13, 2)
	])]),
	towBaggageDolly: item("transit", "Carro rebocável de bagagem", 2.8, 1.25, [
		body("M2 49L20 27V34L8 50L20 66V73L2 52Z"),
		circle$2(3, 50, 2),
		...[24, 78].flatMap((x) => [rect$2(x, 4, 13, 9, 2), rect$2(x, 87, 13, 9, 2)]),
		rect$2(18, 11, 79, 78, 3),
		rect$2(22, 16, 71, 68, 1),
		...Array.from({ length: 6 }, (_, i) => line$1("M" + (28 + i * 11) + " 19v62")),
		rect$2(19, 12, 3, 75),
		rect$2(93, 12, 3, 75)
	]),
	utilityWasteBin: item("decor", "Lixeira interna com pedal", .44, .43, [
		rect$2(10, 6, 80, 80, 12),
		rect$2(16, 12, 68, 66, 9),
		rect$2(27, 6, 46, 7, 2),
		rect$2(33, 82, 34, 13, 4),
		line$1("M39 89h22M24 23h52")
	]),
	dispatchClipboard: item("decor", "Prancheta com formulários", .28, .36, [
		...rotate(page(7, 14, 73, 77), -6, 41, 51),
		rect$2(17, 5, 76, 89, 3),
		...page(22, 14, 65, 72),
		rect$2(37, 8, 32, 10, 3),
		...[
			44,
			56,
			68
		].flatMap((y) => [rect$2(28, y, 5, 5), line$1("M38 " + (y + 2) + "h36")])
	]),
	deskManuals: item("decor", "Manuais e caderno aberto", .63, .42, [
		...rotate([
			rect$2(5, 9, 40, 61, 2),
			line$1("M11 12v54"),
			rect$2(17, 22, 20, 12, 1)
		], -6, 24, 39),
		body("M26 36Q43 30 60 38Q77 31 96 36V91Q76 86 60 94Q42 87 26 91Z"),
		line$1("M60 39v51M31 46q12-3 23 1m-23 9q12-3 23 1M65 47q10-4 24-2m-24 10q10-4 24-2")
	]),
	loosePaperwork: item("decor", "Papéis soltos de expediente", .64, .46, [
		...rotate(page(8, 10, 31, 58), -10, 23, 38),
		...rotate(page(35, 32, 36, 59), 12, 52, 61),
		...rotate(page(60, 9, 32, 52), -5, 75, 33)
	])
};
//#endregion
//#region src/blueprints/containment-assets.js
var lab = (name, w, h, shapes) => ({
	name,
	w,
	h,
	category: "laboratory",
	shapes
});
var security = (name, w, h, shapes) => ({
	name,
	w,
	h,
	category: "security",
	shapes
});
var display = (x, y, angle) => [
	rect$2(x, y, 23, 29, 3),
	rect$2(x + 3, y + 4, 17, 15, 2),
	line$1("M" + (x + 4) + " " + (y + 24) + "h10"),
	circle$2(x + 19, y + 24, 1)
].map((shape) => ({
	...shape,
	transform: "rotate(" + angle + " " + (x + 11.5) + " " + (y + 14.5) + ")"
}));
var containmentAssets = {
	experimentIsland: lab("Ilha de experimentação", 2.8, 1.45, [
		rect$2(2, 5, 96, 90, 4),
		rect$2(5, 40, 90, 16, 2),
		line$1("M8 48h84"),
		...[
			15,
			43,
			71
		].flatMap((x) => [rect$2(x, 42, 9, 11, 1), circle$2(x + 4.5, 47, 2)]),
		rect$2(9, 12, 30, 22, 2),
		rect$2(12, 15, 24, 16, 1),
		...[
			60,
			69,
			78
		].map((x) => circle$2(x, 25, 3)),
		line$1("M8 84h26m-26-5h19M61 64h27v20H61Z")
	]),
	gloveIsolator: lab("Isolador de pequenas espécies", 1.8, .95, [
		rect$2(2, 7, 96, 84, 6),
		rect$2(7, 13, 70, 67, 5),
		rect$2(80, 20, 14, 48, 2),
		line$1("M83 28h8m-8 8h8m-8 8h8m-8 8h8"),
		rect$2(16, 20, 25, 12, 2),
		...[21, 53].flatMap((x) => [body("M" + x + " 74l-2-16 3-9 2 4 2-11 3 1 1 10 4-5 2 2-3 13-3 11Z"), rect$2(x - 2, 73, 15, 9, 2)])
	]),
	specimenHoldingChamber: lab("Câmara de contenção biológica", 3.5, 3.2, [
		body("M17 3H81L96 18V76L80 92H18L4 77V18Z"),
		body("M22 10H77L88 22V71L77 83H23L12 72V22Z"),
		rect$2(23, 20, 52, 50, 10),
		line$1("M29 55l8 7 16-6 12 4M30 28h10m-10 5h6"),
		rect$2(32, 78, 35, 19, 2),
		rect$2(36, 81, 27, 12, 1),
		line$1("M39 85h21m-21 4h21"),
		...[23, 62].flatMap((y) => [rect$2(5, y, 6, 10, 1), rect$2(89, y, 6, 10, 1)]),
		circle$2(80, 21, 3)
	]),
	specimenTransferCase: lab("Caixa de transferência selada", 1.05, .7, [
		rect$2(8, 14, 80, 72, 6),
		rect$2(14, 20, 66, 60, 4),
		rect$2(23, 28, 41, 27, 4),
		rect$2(3, 28, 9, 44, 2),
		rect$2(87, 25, 10, 50, 2),
		line$1("M91 31v38M18 66h24"),
		...[24, 66].flatMap((x) => [rect$2(x, 10, 9, 13, 2), rect$2(x, 77, 9, 13, 2)]),
		rect$2(36, 74, 24, 6, 2)
	]),
	dualCustodyVault: security("Cofre de dupla custódia", 1.35, 1.15, [
		rect$2(4, 4, 92, 92, 6),
		rect$2(11, 10, 77, 80, 4),
		rect$2(17, 16, 65, 66, 3),
		circle$2(49, 47, 13),
		circle$2(49, 47, 4),
		line$1("M49 34v9m-11 11 8-5m6 0 8 5"),
		...[22, 65].flatMap((x) => [rect$2(x, 66, 12, 10, 2), circle$2(x + 6, 71, 2)]),
		rect$2(81, 21, 10, 14, 2),
		rect$2(81, 65, 10, 14, 2)
	]),
	evidenceIntakeDesk: security("Mesa de custódia de evidências", 2.2, 1, [
		rect$2(2, 6, 96, 88, 3),
		rect$2(6, 11, 52, 63, 2),
		line$1("M10 16h43m-43 7h4m4 0h4m4 0h4m4 0h4"),
		body("M16 34l21-7 7 24-21 7Z"),
		line$1("M18 38l19-6"),
		rect$2(64, 13, 28, 33, 3),
		rect$2(68, 18, 20, 9, 1),
		line$1("M69 37h18"),
		rect$2(64, 54, 29, 22, 2),
		line$1("M69 60h19m-19 5h12M9 84h82"),
		rect$2(41, 80, 18, 7, 1)
	]),
	surveillanceConsole: security("Console de vigilância triplo", 2.65, 1.45, [
		body("M3 16L27 5H73L97 16V77L79 93H21L3 77Z"),
		...display(10, 19, -15),
		...display(38, 12, 0),
		...display(66, 19, 15),
		rect$2(30, 56, 39, 17, 2),
		line$1("M34 61h31m-31 5h28"),
		circle$2(81, 65, 6),
		circle$2(81, 64, 2),
		rect$2(10, 56, 13, 18, 1),
		line$1("M12 62h9m-9 6h9M23 83h54")
	]),
	bulkheadAccessReader: security("Terminal de acesso de parede", .62, .26, [
		rect$2(2, 5, 96, 13, 1),
		body("M7 18H93V75L85 94H15L7 75Z"),
		rect$2(14, 25, 35, 44, 4),
		rect$2(18, 30, 27, 32, 3),
		rect$2(56, 25, 28, 43, 2),
		...[
			32,
			42,
			52
		].map((y) => line$1("M59 " + y + "h4m3 0h4m3 0h6")),
		line$1("M19 80h29"),
		rect$2(58, 75, 25, 8, 2)
	])
};
//#endregion
//#region src/blueprints/ship-systems-assets.js
var galley = (name, w, h, shapes) => ({
	name,
	w,
	h,
	category: "galley",
	shapes
});
var engineering = (name, w, h, shapes) => ({
	name,
	w,
	h,
	category: "engineering",
	shapes
});
var shipSystemsAssets = {
	tiltKettle: galley("Caldeirão basculante", 1.5, 1.35, [
		rect$2(3, 13, 12, 74, 3),
		rect$2(85, 13, 12, 74, 3),
		rect$2(12, 45, 76, 10, 1),
		body("M20 43Q20 13 50 13Q80 13 80 45Q82 68 59 79L50 91L43 80Q20 75 20 43Z"),
		circle$2(50, 45, 25),
		line$1("M26 43H74M41 33v-5h18v5"),
		rect$2(6, 38, 6, 14, 2),
		circle$2(91, 51, 4),
		line$1("M91 56v13")
	]),
	trayReturnLine: galley("Retorno de bandejas", 2.6, .9, [
		rect$2(2, 8, 96, 84, 3),
		rect$2(6, 14, 51, 63, 1),
		...[
			11,
			18,
			25,
			32,
			39,
			46,
			53
		].map((x) => line$1("M" + x + " 18v55")),
		rect$2(15, 24, 22, 39, 3),
		rect$2(17, 27, 18, 32, 2),
		rect$2(62, 14, 30, 62, 5),
		rect$2(66, 20, 22, 50, 4),
		line$1("M8 84h82"),
		circle$2(95, 83, 2)
	]),
	compactShipGalley: galley("Cozinha compacta de bordo", 2.4, 1.05, [
		rect$2(2, 4, 96, 92, 3),
		rect$2(6, 13, 35, 53, 5),
		rect$2(10, 18, 27, 42, 5),
		circle$2(23, 48, 3),
		line$1("M24 20v-9h9"),
		rect$2(47, 13, 44, 54, 3),
		circle$2(60, 39, 9),
		circle$2(79, 39, 8),
		line$1("M50 24h38M50 53h38"),
		rect$2(6, 75, 85, 5, 2),
		...[
			9,
			46,
			86
		].map((x) => rect$2(x, 79, 3, 8)),
		circle$2(94, 71, 2)
	]),
	valveManifold: engineering("Coletor com válvulas", 2.3, 1.35, [
		rect$2(3, 54, 94, 18, 5),
		rect$2(3, 48, 5, 30, 1),
		rect$2(92, 48, 5, 30, 1),
		...[
			24,
			50,
			76
		].flatMap((x) => [
			rect$2(x - 4, 11, 8, 46, 2),
			rect$2(x - 7, 9, 14, 5, 1),
			circle$2(x, 34, 9),
			circle$2(x, 34, 2),
			line$1("M" + x + " 25v7m0 5v6m-8-9h6m4 0h6"),
			rect$2(x - 5, 72, 10, 14, 1)
		])
	]),
	supportedPipeBundle: engineering("Feixe de tubos com suportes", 3, .85, [
		...[
			13,
			42,
			73
		].map((y) => rect$2(1, y, 98, 12, 1)),
		...[20, 73].flatMap((x) => [
			rect$2(x, 5, 7, 90, 2),
			circle$2(x + 3.5, 9, 1.6),
			circle$2(x + 3.5, 91, 1.6)
		]),
		...[
			13,
			42,
			73
		].map((y) => rect$2(47, y - 2, 4, 16, 1))
	]),
	shipHeatExchanger: engineering("Trocador de calor de bordo", 2.5, 1.55, [
		rect$2(10, 20, 82, 65, 7),
		rect$2(14, 9, 9, 23, 2),
		rect$2(78, 73, 9, 19, 2),
		rect$2(17, 28, 66, 49, 3),
		...Array.from({ length: 10 }, (_, i) => line$1("M" + (21 + i * 6.4) + " 32v40")),
		rect$2(6, 35, 8, 35, 3),
		rect$2(88, 35, 8, 35, 3),
		line$1("M16 82h60"),
		circle$2(85, 23, 3)
	]),
	propulsionCoupling: engineering("Acoplamento de propulsão", 3.2, 1.75, [
		rect$2(7, 40, 86, 20, 3),
		rect$2(4, 27, 9, 46, 2),
		rect$2(87, 27, 9, 46, 2),
		body("M17 32L29 22H39V78H29L17 68Z"),
		body("M83 32L71 22H61V78H71L83 68Z"),
		...[
			39,
			44,
			49,
			54,
			59
		].map((x) => rect$2(x, 29, 3, 42, 1)),
		...[25, 68].flatMap((x) => [rect$2(x, 13, 7, 10, 1), rect$2(x, 77, 7, 10, 1)]),
		line$1("M20 41h12m-12 10h12m-12 10h12M68 41h12m-12 10h12m-12 10h12")
	])
};
//#endregion
//#region src/blueprints/crew-deck-assets.js
var command = (name, w, h, shapes) => ({
	name,
	w,
	h,
	category: "command",
	shapes
});
var quarters = (name, w, h, shapes) => ({
	name,
	w,
	h,
	category: "quarters",
	shapes
});
var pilotControls = (x) => [
	rect$2(x, 20, 23, 20, 3),
	rect$2(x + 3, 23, 17, 11, 2),
	line$1("M" + (x + 4) + " 30h5l3-3 3 3h4"),
	rect$2(x + 8, 52, 7, 15, 2),
	body("M" + (x + 1) + " 49h4v7l6 3 7-3v-7h4v11l-11 5-10-5Z")
];
var crewDeckAssets = {
	twinFlightDeck: command("Posto duplo de pilotagem", 3.1, 1.35, [
		body("M2 23L11 8H89L98 23V85H89L81 72H62L58 88H42L38 72H19L11 85H2Z"),
		...pilotControls(13),
		...pilotControls(64),
		rect$2(44, 22, 12, 45, 2),
		line$1("M47 28v22m5-22v22"),
		rect$2(45, 36, 4, 7, 1),
		rect$2(50, 40, 4, 7, 1),
		line$1("M7 28v31M93 28v31")
	]),
	arcCommandDesk: command("Console de comando em arco", 3.4, 1.65, [
		body("M2 79Q6 12 50 8Q94 12 98 79L79 90Q75 42 50 39Q25 42 21 90Z"),
		body("M12 55Q16 36 29 26L33 37Q24 46 22 62Z"),
		body("M36 22Q50 15 64 22L61 34Q50 29 39 34Z"),
		body("M71 26Q84 36 88 55L78 62Q76 46 67 37Z"),
		line$1("M8 72l11 5M81 77l11-5M42 25q8-3 16 0"),
		circle$2(15, 66, 2),
		circle$2(85, 66, 2)
	]),
	damageControlBoard: command("Estação de controle de avarias", 1.9, .95, [
		rect$2(2, 5, 96, 90, 4),
		rect$2(7, 12, 59, 55, 3),
		rect$2(11, 16, 51, 47, 2),
		line$1("M15 36l7-9h28l8 9-8 13H22ZM25 28v20m11-20v20m11-20v20M16 37h40"),
		...[
			16,
			32,
			48
		].map((y) => rect$2(73, y, 16, 8, 1)),
		...[
			12,
			24,
			36,
			48,
			60
		].map((x) => rect$2(x, 76, 7, 9, 1)),
		circle$2(83, 78, 6)
	]),
	curtainBerth: quarters("Beliche de bordo com cortina", 2.25, 1.05, [
		rect$2(2, 4, 96, 92, 5),
		rect$2(7, 10, 86, 76, 7),
		rect$2(12, 17, 18, 55, 5),
		line$1("M37 14v66M87 16v61"),
		rect$2(4, 85, 92, 7, 2),
		body("M58 82Q64 73 68 81Q72 72 77 80Q82 72 86 81L94 77V93H58Z"),
		line$1("M65 84v6m8-7v7m9-7v7M9 7v6m83-6v6")
	]),
	foldingCabinDesk: quarters("Escrivaninha rebatível de cabine", 1.25, 1.15, [
		rect$2(5, 6, 90, 9, 1),
		rect$2(8, 15, 84, 40, 3),
		rect$2(17, 16, 11, 5, 1),
		rect$2(72, 16, 11, 5, 1),
		body("M20 29l23-3 2 14-23 3Z"),
		line$1("M53 44h23M15 50h70"),
		rect$2(28, 60, 44, 33, 6),
		rect$2(30, 84, 40, 10, 3),
		line$1("M23 60v23m54-23v23M35 55v6m30-6v6")
	]),
	lockerSeatBank: quarters("Banco com gavetões de tripulação", 2.1, .7, [
		rect$2(2, 8, 96, 83, 4),
		rect$2(5, 13, 90, 10, 2),
		...[
			5,
			36,
			67
		].flatMap((x) => [
			rect$2(x, 27, 28, 40, 4),
			rect$2(x, 72, 28, 14, 1),
			rect$2(x + 8, 75, 12, 4, 1)
		])
	])
};
//#endregion
//#region src/blueprints/service-deck-assets.js
var workshop = (name, w, h, shapes) => ({
	name,
	w,
	h,
	category: "workshop",
	shapes
});
var medical = (name, w, h, shapes) => ({
	name,
	w,
	h,
	category: "medical",
	shapes
});
var pod = (x) => [
	rect$2(x, 12, 24, 73, 10),
	rect$2(x + 3, 16, 18, 64, 8),
	rect$2(x + 6, 21, 12, 10, 3),
	line$1("M" + (x + 4) + " 40q8-6 16 0m-15 26q7 5 14 0"),
	rect$2(x + 1, 49, 3, 9, 1),
	rect$2(x + 20, 49, 3, 9, 1)
];
var serviceDeckAssets = {
	strippedEngineStand: workshop("Cavalete com motor desmontado", 2.1, 1.45, [
		rect$2(4, 14, 8, 73, 2),
		rect$2(88, 14, 8, 73, 2),
		rect$2(9, 43, 82, 12, 2),
		body("M19 29L28 18H68L81 30V64L70 76H29L19 65Z"),
		rect$2(25, 26, 50, 40, 4),
		...[
			35,
			50,
			65
		].flatMap((x) => [circle$2(x, 45, 6), circle$2(x, 45, 3.3)]),
		line$1("M29 68h37M16 39v20M84 39v20"),
		...[5, 89].flatMap((x) => [rect$2(x, 8, 6, 9, 2), rect$2(x, 83, 6, 9, 2)])
	]),
	viseToolBench: workshop("Bancada de ferramentas com morsa", 2.2, .95, [
		rect$2(2, 8, 96, 80, 3),
		rect$2(5, 12, 90, 9, 1),
		rect$2(58, 28, 34, 43, 2),
		...[
			64,
			73,
			82
		].flatMap((x) => [line$1("M" + x + " 36v20"), rect$2(x - 2, 54, 4, 12, 1)]),
		rect$2(13, 51, 21, 23, 4),
		rect$2(9, 55, 29, 7, 1),
		rect$2(9, 72, 29, 7, 1),
		rect$2(20, 79, 6, 11, 1),
		line$1("M13 90h20"),
		circle$2(13, 90, 1.8),
		circle$2(33, 90, 1.8),
		line$1("M42 80h46")
	]),
	mobileGantryHoist: workshop("Talha móvel de pórtico", 3.4, 1.7, [
		...[8, 83].flatMap((x) => [
			rect$2(x, 6, 9, 88, 2),
			rect$2(x - 2, 2, 5, 10, 2),
			rect$2(x + 6, 88, 5, 10, 2),
			line$1("M" + x + " 12l8 30m0 16-8 30")
		]),
		rect$2(6, 43, 88, 11, 1),
		line$1("M10 46h80M10 51h80"),
		rect$2(45, 36, 16, 23, 3),
		circle$2(53, 47, 4),
		line$1("M51 59v13q0 7 5 7t4-8m-6-12v11")
	]),
	shipEvacLitter: medical("Maca de evacuação de bordo", .83, 2.15, [
		rect$2(14, 3, 72, 94, 13),
		rect$2(22, 8, 56, 84, 11),
		rect$2(30, 12, 40, 13, 5),
		...[
			35,
			59,
			78
		].flatMap((y) => [body("M19 " + y + "l62 3v4l-62-3Z"), rect$2(47, y, 9, 7, 1)]),
		...[22, 68].flatMap((y) => [rect$2(3, y, 10, 12, 3), rect$2(87, y, 10, 12, 3)])
	]),
	isolationCanopyBed: medical("Leito de isolamento", 1.35, 2.5, [
		rect$2(10, 3, 72, 94, 8),
		rect$2(16, 7, 60, 85, 9),
		rect$2(22, 13, 46, 68, 9),
		rect$2(29, 17, 32, 12, 4),
		line$1("M20 38Q45 33 72 38M20 72Q45 77 72 72M24 44v20"),
		...[44, 58].map((y) => circle$2(67, y, 4)),
		rect$2(83, 28, 15, 36, 2),
		circle$2(90, 40, 4),
		line$1("M86 51h8m-8 5h8M81 22q10 0 10 6M81 72q10 0 10-8")
	]),
	resuscitationBay: medical("Estação de reanimação", 2.1, 2.3, [
		rect$2(9, 9, 50, 82, 9),
		rect$2(14, 15, 40, 68, 8),
		rect$2(21, 18, 26, 13, 4),
		line$1("M17 53h34M18 65h32"),
		rect$2(63, 6, 31, 38, 3),
		rect$2(66, 10, 24, 17, 2),
		line$1("M68 20h5l3-7 3 10 2-4h6"),
		...[70, 85].map((x) => rect$2(x - 3, 30, 6, 9, 2)),
		rect$2(68, 53, 20, 34, 4),
		...[73, 83].map((x) => circle$2(x, 64, 4)),
		line$1("M68 74Q60 80 57 66M70 44q-8 9-13 3")
	]),
	linkedCryoBank: medical("Banco de criocápsulas", 4.4, 2.6, [
		rect$2(2, 4, 96, 6, 2),
		rect$2(2, 88, 96, 7, 2),
		...pod(3),
		...pod(30),
		...pod(57),
		...[
			15,
			42,
			69
		].map((x) => line$1("M" + x + " 9v5m0 70v5")),
		rect$2(84, 18, 14, 58, 3),
		rect$2(86, 23, 10, 17, 1),
		circle$2(91, 50, 3),
		line$1("M87 60h8m-8 5h8M90 10v8M91 76v13")
	])
};
//#endregion
//#region src/blueprints/freight-assets.js
var cargo = (name, w, h, shapes) => ({
	name,
	w,
	h,
	category: "cargo",
	shapes
});
var freightAssets = {
	sealedFreightPod: cargo("Cápsula de carga pressurizada", 2.6, 1.4, [
		rect$2(2, 36, 96, 28, 10),
		rect$2(7, 12, 86, 76, 32),
		line$1("M23 19Q9 50 23 81M77 19Q91 50 77 81"),
		rect$2(34, 26, 32, 48, 9),
		rect$2(37, 30, 26, 40, 7),
		circle$2(50, 50, 7),
		line$1("M43 50H57M50 43V57M32 40h4m-4 20h4M64 40h4m-4 20h4")
	]),
	armoredTankCradle: cargo("Tanque blindado em berço", 3.8, 2, [
		rect$2(3, 4, 94, 92, 2),
		line$1("M5 8l12 16M95 8L83 24M5 92l12-16M95 92L83 76"),
		rect$2(9, 17, 82, 66, 25),
		rect$2(22, 14, 7, 72, 2),
		rect$2(71, 14, 7, 72, 2),
		body("M34 24H66L70 34V66L64 76H36L30 66V34Z"),
		circle$2(50, 50, 10),
		circle$2(50, 50, 5),
		line$1("M12 48h6m64 0h6M35 32h7m16 36h7")
	]),
	coldFreightContainer: cargo("Contêiner refrigerado com condensador", 3.2, 1.8, [
		rect$2(2, 4, 96, 92, 3),
		rect$2(5, 9, 62, 82, 2),
		...Array.from({ length: 6 }, (_, i) => line$1("M" + (10 + i * 10) + " 16v68")),
		rect$2(71, 10, 23, 80, 2),
		circle$2(82, 34, 9),
		circle$2(82, 34, 3),
		line$1("M82 26v5m8 3h-5m-3 8v-5m-8-3h5M74 57h17m-17 7h17m-17 7h17m-17 7h17")
	]),
	liveFreightCage: cargo("Gaiola de transporte de carga viva", 2, 1.35, [
		rect$2(3, 5, 94, 90, 3),
		rect$2(8, 11, 84, 78, 2),
		line$1("M10 69Q25 61 40 68T72 71"),
		rect$2(68, 55, 19, 18, 3),
		...Array.from({ length: 7 }, (_, i) => line$1("M" + (16 + i * 11) + " 12v75")),
		line$1("M9 36h82M9 71h82"),
		rect$2(26, 80, 48, 11, 1),
		rect$2(65, 79, 6, 13, 1),
		line$1("M30 83v5m6-5v5")
	]),
	freightParcelRack: cargo("Rack de pequenos volumes cintados", 1.4, .95, [
		rect$2(2, 3, 96, 94, 2),
		rect$2(7, 9, 40, 36, 2),
		rect$2(50, 9, 42, 43, 2),
		rect$2(7, 49, 40, 40, 2),
		rect$2(51, 56, 41, 33, 2),
		line$1("M10 20h12v6H10ZM71 16h15v7H71ZM12 57h12v7H12Z"),
		rect$2(27, 5, 4, 89),
		rect$2(63, 5, 4, 89),
		rect$2(25, 40, 8, 9, 1),
		rect$2(61, 49, 8, 9, 1)
	]),
	longLiftContainer: cargo("Contêiner longo de içamento", 6, 2.3, [
		rect$2(2, 5, 96, 90, 2),
		rect$2(4, 10, 92, 80, 1),
		...Array.from({ length: 12 }, (_, i) => line$1("M" + (8 + i * 7.5) + " 17v66")),
		rect$2(17, 3, 4, 94),
		rect$2(79, 3, 4, 94),
		...[19, 81].flatMap((x) => [circle$2(x, 9, 2.4), circle$2(x, 91, 2.4)]),
		rect$2(87, 37, 7, 23, 1)
	])
};
//#endregion
//#region src/blueprints/mining-assets.js
var R$2 = (x, y, width, height, rx = 0, fill) => ({
	tag: "rect",
	x,
	y,
	width,
	height,
	rx,
	...fill ? { fill } : {}
});
var C$2 = (cx, cy, r, fill) => ({
	tag: "circle",
	cx,
	cy,
	r,
	...fill ? { fill } : {}
});
var P$2 = (d, fill = "none") => ({
	tag: "path",
	d,
	fill
});
var add$2 = (name, w, h, shapes) => ({
	name,
	w,
	h,
	category: "mining-production",
	shapes: shapes.flat(Infinity).map((s) => ({
		...s,
		transform: `scale(${100 / w} ${100 / h})`,
		strokeWidth: .035
	}))
});
var ribs$1 = (x, y, w, h, n) => Array.from({ length: n }, (_, i) => P$2(`M${x} ${y + i * h / (n - 1)}h${w}`));
var motor = (x, y, w = .5, h = .8) => [
	R$2(x, y, w, h, .08),
	...ribs$1(x + .08, y + .14, w - .16, h - .28, 5),
	R$2(x + w * .3, y - .1, w * .4, .1, .02)
];
var track = (x, y, w, h) => [
	R$2(x, y, w, h, .16),
	R$2(x + .1, y + .15, w - .2, h - .3, .1, "none"),
	...ribs$1(x + .03, y + .2, w - .06, h - .4, 12)
];
var wheel = (x, y) => [R$2(x, y, .18, .42, .05), P$2(`M${x + .04} ${y + .05}v.32`)];
var belt = (x, y, w, h) => [
	R$2(x, y, w, h),
	R$2(x + .12, y, w - .24, h),
	...ribs$1(x + .17, y + .12, w - .34, h - .24, Math.max(3, Math.round(h * 3))),
	P$2(`M${x + .06} ${y}v${h}M${x + w - .06} ${y}v${h}`)
];
var miningAssets = {
	mineCart: add$2("Vagoneta de mina · caçamba aberta", 1.25, 2.2, [
		R$2(.5, .01, .25, 2.18, .03),
		...[
			[.02, .35],
			[1.05, .35],
			[.02, 1.4],
			[1.05, 1.4]
		].map(([x, y]) => wheel(x, y)),
		R$2(.15, .22, .95, 1.76, .07),
		R$2(.23, .32, .79, 1.56, .04),
		R$2(.36, .51, .53, 1.18, .03),
		P$2("M.23 .32l.13 .19M1.02 .32l-.13 .19M.23 1.88l.13-.19M1.02 1.88l-.13-.19"),
		...[.6, 1.5].flatMap((y) => [R$2(.12, y, .1, .11, .01), R$2(1.03, y, .1, .11, .01)])
	]),
	mineLocomotive: add$2("Locomotiva de mina · bateria e cabine protegida", 1.5, 3.8, [
		R$2(.6, .02, .3, 3.76, .04),
		...[
			[.03, .55],
			[1.29, .55],
			[.03, 2.7],
			[1.29, 2.7]
		].map(([x, y]) => wheel(x, y)),
		R$2(.19, .3, 1.12, 3.2, .1),
		R$2(.27, .42, .96, 1.63, .05),
		...ribs$1(.35, .66, .8, 1.1, 7),
		R$2(.37, .48, .22, .08, .02),
		R$2(.91, .48, .22, .08, .02),
		R$2(.26, 2.18, .98, 1.12, .07),
		R$2(.34, 2.27, .82, .31, .03),
		P$2("M.75 2.27v.31"),
		R$2(.39, 2.73, .72, .42, .03),
		P$2("M.47 2.79h.56M.47 3.09h.56"),
		R$2(.22, .32, .18, .13, .03),
		R$2(1.1, .32, .18, .13, .03),
		P$2("M.3 3.42h.9")
	]),
	mineDrill: add$2("Perfuratriz de mina · broca sobre esteiras", 2.4, 6.2, [
		...track(.05, 2.4, .48, 3.1),
		...track(1.87, 2.4, .48, 3.1),
		R$2(.5, 2.72, 1.4, 2.9, .12),
		...motor(.65, 4.57, .95, .85),
		R$2(.57, 3.3, .62, 1.05, .08),
		R$2(.64, 3.38, .48, .36, .03),
		P$2("M.69 3.83h.37"),
		R$2(1.3, 2.9, .35, 2.1, .05),
		P$2("M1.73 3Q2.04 4.2 1.73 4.8M1.8 3Q2.12 4.2 1.8 4.8"),
		R$2(1.01, 1.4, .38, 2.1, .035),
		R$2(1.1, .6, .2, 2.7, .025),
		P$2("M1.02 .62L1.2 .03L1.38 .62Z", "inherit"),
		...Array.from({ length: 5 }, (_, i) => P$2(`M1.08 ${.67 + i * .15}l.24-.1`)),
		R$2(.81, 2.1, .78, .15, .025),
		C$2(1.2, 3.4, .19),
		C$2(1.2, 3.4, .09)
	]),
	mineLoader: add$2("Carregadeira subterrânea · perfil baixo articulado", 2.2, 5.1, [
		...[
			[.04, 1.5],
			[1.98, 1.5],
			[.04, 3.9],
			[1.98, 3.9]
		].map(([x, y]) => [R$2(x, y, .18, .65, .07), ...ribs$1(x + .02, y + .1, .14, .45, 5)]),
		R$2(.26, 3.03, 1.68, 1.87, .1),
		R$2(.37, 3.92, 1.46, .75, .05),
		...ribs$1(.48, 4.05, 1.24, .46, 5),
		R$2(.35, 3.15, .75, .62, .06),
		R$2(.42, 3.22, .61, .29, .02),
		C$2(1.1, 2.78, .24),
		P$2("M.57 2.62l.27 .25M1.63 2.62l-.27 .25"),
		R$2(.35, 1.34, 1.5, 1.25, .06),
		R$2(.53, .58, .18, 1.3, .025),
		R$2(1.49, .58, .18, 1.3, .025),
		P$2("M.08 .1H2.12L1.92 .91H.28Z", "inherit"),
		P$2("M.25 .24H1.95L1.82 .74H.38Z"),
		...Array.from({ length: 7 }, (_, i) => R$2(.22 + i * .27, .03, .12, .16, .01))
	]),
	oreCrusher: add$2("Britador de minério · mandíbulas e descarga", 3, 3.6, [
		R$2(.12, .18, 2.76, 3.24, .08),
		R$2(.3, .35, 1.8, 2.2, .08),
		R$2(.45, .51, 1.5, 1.86, .04),
		...Array.from({ length: 8 }, (_, i) => P$2(`M.48 ${.61 + i * .22}l.28 .09l.28-.09M1.92 ${.61 + i * .22}l-.28 .09l-.28-.09`)),
		C$2(2.46, 1.08, .32),
		C$2(2.46, 1.08, .13),
		P$2("M2.14 1.08H2.78M2.46 .76v.64"),
		...motor(2.18, 2, .55, 1),
		R$2(.48, 2.68, 1.45, .63, .03),
		...ribs$1(.57, 2.8, 1.27, .38, 4),
		...[
			[.22, .28],
			[2.78, .28],
			[.22, 3.3],
			[2.78, 3.3]
		].map(([x, y]) => C$2(x, y, .045))
	]),
	feedHopper: add$2("Moega de alimentação · funil e registro", 2.8, 2.8, [
		...[
			[.06, .06],
			[2.44, .06],
			[.06, 2.44],
			[2.44, 2.44]
		].map(([x, y]) => R$2(x, y, .3, .3, .025)),
		R$2(.18, .18, 2.44, 2.44, .06),
		R$2(.29, .29, 2.22, 2.22, .04),
		R$2(.99, .99, .82, .82, .035),
		P$2("M.29 .29l.7 .7M2.51 .29l-.7 .7M.29 2.51l.7-.7M2.51 2.51l-.7-.7"),
		R$2(1.07, 1.08, .66, .64, .02),
		P$2("M1.1 1.4h.6"),
		C$2(2.43, 1.4, .13),
		P$2("M2.3 1.4h-.35M2.43 1.27v.26")
	]),
	hydraulicPress: add$2("Prensa hidráulica · colunas e mesa", 2.4, 2.5, [
		R$2(.12, .14, 2.16, 2.2, .06),
		R$2(.45, .62, 1.5, 1.26, .03),
		...ribs$1(.57, .8, 1.26, .9, 5),
		...[
			[.26, .35],
			[1.94, .35],
			[.26, 1.95],
			[1.94, 1.95]
		].map(([x, y]) => [C$2(x, y, .13), C$2(x, y, .06)]),
		R$2(.27, 1.02, 1.86, .34, .035),
		C$2(1.2, 1.19, .25),
		C$2(1.2, 1.19, .13),
		R$2(.53, .2, 1.34, .25, .03),
		P$2("M.67 .27h.55"),
		C$2(1.58, .32, .055),
		P$2("M2.16 .56Q2.37 .8 2.18 1.08")
	]),
	weldingCell: add$2("Célula de soldagem · braço e mesa de fixação", 3.4, 2.8, [
		R$2(.07, .07, 3.26, 2.66, .06),
		R$2(1.65, .35, 1.37, 1.78, .04),
		...Array.from({ length: 5 }, (_, r) => Array.from({ length: 4 }, (_, c) => C$2(1.85 + c * .32, .55 + r * .34, .025))),
		R$2(.23, .3, .8, .75, .06),
		C$2(.63, .67, .29),
		C$2(.63, .67, .14),
		P$2("M.55 .82L.82 .68L1.43 1.48L1.17 1.66Z", "inherit"),
		C$2(1.29, 1.55, .17),
		P$2("M1.3 1.43L1.42 1.67L2.02 1.32L1.91 1.12Z", "inherit"),
		C$2(1.98, 1.2, .11),
		P$2("M2.07 1.18l.22-.12"),
		P$2("M.44 .8Q.26 1.6 1.1 1.8"),
		R$2(.23, 1.99, 1.02, .52, .05),
		R$2(.33, 2.08, .45, .24, .02),
		C$2(1.03, 2.19, .065)
	]),
	conveyorStraight: add$2("Esteira modular · trecho reto", 1.2, 3, [...belt(0, 0, 1.2, 3)]),
	conveyorCorner: add$2("Esteira modular · curva de 90 graus", 2.4, 2.4, [
		P$2("M0 0A2.4 2.4 0 0 1 2.4 2.4H1.2A1.2 1.2 0 0 0 0 1.2Z", "inherit"),
		P$2("M0 .12A2.28 2.28 0 0 1 2.28 2.4M0 1.08A1.32 1.32 0 0 1 1.32 2.4"),
		...Array.from({ length: 10 }, (_, i) => {
			const a = (i + .5) * Math.PI / 20;
			return P$2(`M${1.37 * Math.sin(a)} ${2.4 - 1.37 * Math.cos(a)}L${2.23 * Math.sin(a)} ${2.4 - 2.23 * Math.cos(a)}`);
		})
	]),
	conveyorTransfer: add$2("Esteira modular · mesa de transferência", 1.2, 1.2, [...belt(0, 0, 1.2, 1.2), ...Array.from({ length: 4 }, (_, r) => Array.from({ length: 3 }, (_, c) => C$2(.3 + c * .3, .16 + r * .29, .065)))]),
	conveyorDrive: add$2("Esteira modular · terminal motorizado", 1.9, 1.2, [
		...belt(0, 0, 1.2, 1.2),
		R$2(1.2, .53, .25, .14, .02),
		...motor(1.43, .22, .43, .84),
		R$2(.15, .82, .9, .23, .08),
		P$2("M.2 .89h.8")
	]),
	mineTipper: add$2("Vagoneta basculante · pivôs e trava lateral", 1.6, 2.5, [
		R$2(.67, .02, .26, 2.46, .025),
		R$2(.19, .27, 1.22, 1.96, .04),
		...[
			[.03, .45],
			[1.39, .45],
			[.03, 1.65],
			[1.39, 1.65]
		].map(([x, y]) => wheel(x, y)),
		P$2("M.26 .4H1.34L1.17 2.09H.43Z", "inherit"),
		P$2("M.38 .54H1.22L1.06 1.93H.54Z"),
		C$2(.25, 1.23, .12),
		C$2(1.35, 1.23, .12),
		C$2(.25, 1.23, .045),
		C$2(1.35, 1.23, .045),
		P$2("M1.35 1.35v.43h.12"),
		R$2(.47, .46, .66, .11, .02),
		P$2("M.49 2.03h.62")
	]),
	mineFlatbed: add$2("Plataforma de mina · carga pesada e amarração", 1.5, 2.8, [
		R$2(.62, .02, .26, 2.76, .03),
		...[
			[.03, .5],
			[1.29, .5],
			[.03, 1.9],
			[1.29, 1.9]
		].map(([x, y]) => wheel(x, y)),
		R$2(.2, .25, 1.1, 2.3, .04),
		R$2(.29, .34, .92, 2.12, .02),
		...ribs$1(.3, .55, .9, 1.7, 8),
		...[
			.43,
			1.4,
			2.37
		].flatMap((y) => [C$2(.25, y, .035), C$2(1.25, y, .035)])
	]),
	twinDrill: add$2("Perfuratriz jumbo · dois braços de avanço", 3.2, 6.4, [
		...track(.1, 3, .55, 2.95),
		...track(2.55, 3, .55, 2.95),
		R$2(.64, 3.3, 1.92, 2.76, .12),
		R$2(.78, 3.6, .8, 1.1, .07),
		R$2(.86, 3.69, .64, .34, .02),
		...motor(1.73, 4.75, .63, 1.05),
		...[.86, 2.34].flatMap((x) => [
			C$2(x, 3.52, .25),
			R$2(x - .13, 1.65, .26, 1.8, .03),
			R$2(x - .065, .4, .13, 2.3, .02),
			R$2(x - .3, 2.2, .6, .13, .02),
			P$2(`M${x - .13} .42L${x} .06L${x + .13} .42Z`, "inherit"),
			...Array.from({ length: 6 }, (_, i) => P$2(`M${x - .1} ${.5 + i * .14}l.2-.08`)),
			P$2(`M${x + .23} 2.8q.3 .4 .12 .9`)
		]),
		P$2("M1.06 5.76h.51")
	]),
	vibratingScreen: add$2("Peneira vibratória · malha e contrapesos", 2.6, 3.6, [
		R$2(.23, .18, 2.14, 3.24, .06),
		R$2(.4, .35, 1.8, 2.9, .04),
		...ribs$1(.48, .46, 1.64, 2.68, 14),
		...Array.from({ length: 8 }, (_, i) => P$2(`M${.5 + i * .23} .44v2.72`)),
		...[.61, 2.65].flatMap((y) => [
			R$2(.04, y, .24, .34, .03),
			R$2(2.32, y, .24, .34, .03),
			C$2(.16, y + .17, .07),
			C$2(2.44, y + .17, .07)
		]),
		R$2(.74, 1.51, 1.12, .5, .05),
		C$2(1.3, 1.76, .19),
		C$2(1.3, 1.76, .07)
	]),
	extractionWinch: add$2("Guincho de extração · tambor e freio", 2.8, 2, [
		R$2(.12, .12, 2.56, 1.76, .06),
		...motor(2.05, .5, .45, 1.1),
		R$2(.45, .59, 1.35, .85, .05),
		...Array.from({ length: 12 }, (_, i) => P$2(`M${.55 + i * .1} .62v.79`)),
		R$2(.35, .43, .13, 1.17, .04),
		R$2(1.79, .43, .13, 1.17, .04),
		R$2(.28, .86, .17, .34, .03),
		R$2(1.92, .86, .13, .34, .03),
		P$2("M1.13 .59V.03M1.2 .59V.03"),
		C$2(.6, 1.72, .08),
		P$2("M.6 1.64l.12-.17"),
		...[
			[.22, .22],
			[2.58, .22],
			[.22, 1.78],
			[2.58, 1.78]
		].map(([x, y]) => C$2(x, y, .035))
	]),
	rollerConveyor: add$2("Transportador de roletes · módulo aberto", 1.2, 3, [
		R$2(.03, 0, .1, 3, .02),
		R$2(1.07, 0, .1, 3, .02),
		...Array.from({ length: 12 }, (_, i) => [R$2(.13, .04 + i * .25, .94, .17, .065), P$2(`M.2 ${.09 + i * .25}h.8`)])
	]),
	coveredConveyor: add$2("Esteira coberta · carenagem de inspeção", 1.2, 3, [
		R$2(.03, 0, 1.14, 3, .03),
		P$2("M.16 0v3M1.04 0v3"),
		...Array.from({ length: 3 }, (_, i) => [
			R$2(.22, .08 + i, .76, .83, .06),
			R$2(.46, .22 + i, .28, .09, .025),
			P$2(`M.32 ${.77 + i}h.56`)
		])
	]),
	cargoTurntable: add$2("Mesa giratória · plataforma de roletes", 2.8, 2.8, [
		C$2(1.4, 1.4, 1.35),
		C$2(1.4, 1.4, 1.23),
		C$2(1.4, 1.4, 1.1),
		...Array.from({ length: 7 }, (_, i) => {
			const y = .54 + i * .26;
			const half = Math.sqrt(1.03 ** 2 - (y - 1.4) ** 2);
			return R$2(1.4 - half, y, half * 2, .13, .05);
		}),
		...[
			0,
			1,
			2,
			3
		].map((i) => C$2(1.4 + 1.29 * Math.cos(i * Math.PI / 2), 1.4 + 1.29 * Math.sin(i * Math.PI / 2), .035))
	]),
	freightLift: add$2("Elevador industrial · plataforma e guias", 3, 3.2, [
		R$2(.3, .22, 2.4, 2.75, .04),
		R$2(.47, .39, 2.06, 2.39, .03),
		...ribs$1(.55, .62, 1.9, 1.93, 9),
		R$2(.07, .15, .17, 2.9, .02),
		R$2(2.76, .15, .17, 2.9, .02),
		...[.45, 2.55].flatMap((y) => [R$2(.2, y, .28, .18, .02), R$2(2.52, y, .28, .18, .02)]),
		R$2(.64, .05, 1.72, .12, .02),
		P$2("M.8 .17v.2M2.2 .17v.2"),
		R$2(.47, 2.85, 2.06, .18, .02),
		P$2("M.62 2.92h1.76")
	]),
	metalGuillotine: add$2("Guilhotina industrial · corte de chapas", 3.2, 2.3, [
		R$2(.13, .13, 2.94, 2.04, .06),
		R$2(.35, .88, 2.5, 1.08, .025),
		...[
			.64,
			1.28,
			1.92,
			2.56
		].map((x) => P$2(`M${x} 1.06v.72`)),
		R$2(.27, .4, 2.66, .37, .035),
		P$2("M.34 .64H2.86M.4 .78h2.4"),
		...Array.from({ length: 7 }, (_, i) => R$2(.49 + i * .34, .75, .14, .13, .02)),
		R$2(.25, .17, .65, .17, .02),
		C$2(1.07, .25, .045),
		C$2(1.23, .25, .045),
		R$2(.19, 1.05, .1, .8, .02),
		R$2(2.91, 1.05, .1, .8, .02)
	]),
	plateRoller: add$2("Calandra de chapas · três rolos e transmissão", 3.4, 1.9, [
		R$2(.12, .2, 3.16, 1.5, .05),
		R$2(.3, .35, .27, 1.2, .04),
		R$2(2.58, .35, .27, 1.2, .04),
		...[
			.49,
			.86,
			1.23
		].flatMap((y) => [R$2(.57, y, 2.01, .24, .1), P$2(`M.7 ${y + .06}h1.75`)]),
		...motor(2.91, .51, .26, .9),
		C$2(.43, .94, .08),
		P$2("M.43 .86V.56")
	]),
	smeltingFurnace: add$2("Forno de fundição · cadinho e canal", 3.4, 3.4, [
		R$2(.1, .1, 3.2, 3.2, .12),
		C$2(1.57, 1.55, 1.17),
		C$2(1.57, 1.55, .98),
		C$2(1.57, 1.55, .74),
		...Array.from({ length: 12 }, (_, i) => {
			const a = i * Math.PI / 6;
			return P$2(`M${1.57 + .99 * Math.cos(a)} ${1.55 + .99 * Math.sin(a)}L${1.57 + 1.15 * Math.cos(a)} ${1.55 + 1.15 * Math.sin(a)}`);
		}),
		P$2("M2.18 2.05L3.16 2.8L2.83 3.14L1.97 2.23Z", "inherit"),
		P$2("M2.22 2.2L2.98 2.91"),
		R$2(.24, 2.84, .82, .25, .03),
		C$2(.43, 2.96, .06),
		P$2("M.59 2.94h.3")
	]),
	industrialMixer: add$2("Misturador industrial · cuba e agitador", 2.7, 2.8, [
		R$2(.15, .12, 2.4, 2.56, .07),
		C$2(1.35, 1.4, 1.04),
		C$2(1.35, 1.4, .9),
		R$2(.32, 1.29, 2.06, .22, .035),
		C$2(1.35, 1.4, .18),
		...[
			0,
			1,
			2
		].map((i) => {
			const a = i * Math.PI * 2 / 3;
			return P$2(`M${1.35 + .2 * Math.cos(a)} ${1.4 + .2 * Math.sin(a)}L${1.35 + .72 * Math.cos(a)} ${1.4 + .72 * Math.sin(a)}l.12 .12`);
		}),
		R$2(1.15, .15, .4, .32, .04),
		P$2("M1.25 .2v.19M1.35 .2v.19M1.45 .2v.19"),
		P$2("M2.32 1.92h.25v.52"),
		C$2(2.57, 2.46, .07)
	]),
	fillingCarousel: add$2("Máquina de envase · carrossel e bicos", 3.6, 2.8, [
		R$2(.07, .1, 3.46, 2.6, .06),
		C$2(1.44, 1.4, 1.05),
		C$2(1.44, 1.4, .77),
		C$2(1.44, 1.4, .35),
		...Array.from({ length: 8 }, (_, i) => {
			const a = i * Math.PI / 4;
			const x = 1.44 + .79 * Math.cos(a), y = 1.4 + .79 * Math.sin(a);
			return [
				C$2(x, y, .13),
				C$2(x, y, .075),
				P$2(`M${1.44 + .4 * Math.cos(a)} ${1.4 + .4 * Math.sin(a)}L${x} ${y}`)
			];
		}),
		...belt(2.64, .1, .7, 2.6),
		R$2(.2, .21, .5, .25, .02),
		P$2("M.3 .3h.29"),
		P$2("M2.46 .85h.22M2.46 1.95h.22")
	]),
	overheadCrane: add$2("Ponte rolante · vigas e carro de içamento", 5, 3.8, [
		R$2(.07, .05, .16, 3.7, .025),
		R$2(4.77, .05, .16, 3.7, .025),
		R$2(.13, 1.14, 4.74, .25, .04),
		R$2(.13, 2.35, 4.74, .25, .04),
		P$2("M.3 1.22h4.4M.3 2.52h4.4"),
		...[.38, 4.34].map((x) => R$2(x, 1.04, .28, 1.66, .04)),
		R$2(2.02, 1.12, 1.03, 1.49, .05),
		R$2(2.14, 1.55, .64, .58, .03),
		...ribs$1(2.22, 1.63, .48, .42, 6),
		...motor(2.18, 1.19, .42, .36),
		P$2("M2.38 2.15v.75q.3 .2 .3-.13M2.45 2.15v.65"),
		...[
			[.15, 1.04],
			[.15, 2.68],
			[4.85, 1.04],
			[4.85, 2.68]
		].map(([x, y]) => C$2(x, y, .05))
	])
};
//#endregion
//#region src/blueprints/hospitality-assets.js
var R$1 = (x, y, width, height, rx = 0, fill) => ({
	tag: "rect",
	x,
	y,
	width,
	height,
	rx,
	...fill ? { fill } : {}
});
var C$1 = (cx, cy, r, fill) => ({
	tag: "circle",
	cx,
	cy,
	r,
	...fill ? { fill } : {}
});
var P$1 = (d, fill = "none") => ({
	tag: "path",
	d,
	fill
});
var seat$1 = (x, y, w = .5, h = .55, facing = "down") => [
	R$1(x, y, w, h, .08),
	R$1(x + .03, facing === "up" ? y + h - .14 : y + .02, w - .06, .12, .04),
	P$1("M" + (x + .04) + " " + (facing === "up" ? y + .06 : y + h - .06) + "h" + (w - .08))
];
var table = (x, y, w, h) => [R$1(x, y, w, h, .08), R$1(x + .04, y + .04, w - .08, h - .08, .06, "none")];
var add$1 = (name, category, w, h, shapes) => ({
	name,
	category,
	w,
	h,
	shapes: shapes.flat(Infinity).map((s) => ({
		...s,
		transform: "scale(" + 100 / w + " " + 100 / h + ")",
		strokeWidth: s.strokeWidth ?? .025
	}))
});
var mattress = (w, h) => [
	R$1(.02, .02, w - .04, h - .04, .1),
	R$1(.06, .06, w - .12, h - .12, .08, "none"),
	...Array.from({ length: 4 }, (_, row) => Array.from({ length: w > 1 ? 3 : 2 }, (_, col) => {
		const x = .2 + col * (w - .4) / (w > 1 ? 2 : 1), y = .3 + row * (h - .6) / 3;
		return P$1("M" + (x - .055) + " " + y + "q.055-.08 .11 0q-.055 .08-.11 0");
	})).flat(),
	P$1("M.025 .7v.3M" + (w - .025) + " .7v.3")
];
var coats = (x, y, count, spacing) => Array.from({ length: count }, (_, i) => {
	const cx = x + i * spacing;
	return [
		P$1("M" + cx + " " + y + "v-.09"),
		P$1("M" + (cx - .12) + " " + (y + .07) + "l.075-.075 .045 .032 .045-.032 .075 .075-.023 .17h-.19Z", "inherit"),
		P$1("M" + cx + " " + (y + .034) + "v.15")
	];
});
var hospitalityAssets = {
	diningFour: add$1("Mesa de restaurante · quatro lugares", "restaurant", 2.2, 2, [
		...seat$1(.25, .02),
		...seat$1(1.45, .02),
		...seat$1(.25, 1.43, .5, .55, "up"),
		...seat$1(1.45, 1.43, .5, .55, "up"),
		...table(.14, .59, 1.92, .8)
	]),
	diningRound: add$1("Mesa redonda · seis lugares", "restaurant", 2.8, 2.8, [
		...Array.from({ length: 6 }, (_, i) => {
			const a = i * Math.PI / 3;
			const x = 1.4 + 1.12 * Math.cos(a);
			const y = 1.4 + 1.12 * Math.sin(a);
			return [C$1(x, y, .24), C$1(x, y, .19, "none")];
		}).flat(),
		C$1(1.4, 1.4, .7),
		C$1(1.4, 1.4, .65, "none")
	]),
	diningBooth: add$1("Cabine de restaurante · bancos frente a frente", "restaurant", 2.4, 2.2, [
		R$1(.03, .03, .53, 2.14, .1),
		R$1(.06, .08, .14, 2.04, .05),
		P$1("M.2 .74h.3M.2 1.46h.3"),
		R$1(1.84, .03, .53, 2.14, .1),
		R$1(2.2, .08, .14, 2.04, .05),
		P$1("M1.89 .74h.31M1.89 1.46h.31"),
		...table(.76, .25, .88, 1.7)
	]),
	diningBanquette: add$1("Banco estofado modular · restaurante", "restaurant", 2, .65, [
		R$1(.02, .02, 1.96, .61, .06),
		R$1(.05, .05, 1.9, .14, .04),
		P$1("M.67 .21v.35M1.33 .21v.35"),
		R$1(.05, .22, 1.9, .36, .03, "none")
	]),
	hostStand: add$1("Recepção de restaurante · púlpito", "restaurant", .85, .65, [
		R$1(.03, .03, .79, .59, .05),
		R$1(.08, .08, .69, .38, .03, "none"),
		P$1("M.12 .12h.61M.12 .18h.61"),
		R$1(.16, .49, .53, .08, .02)
	]),
	buffetIsland: add$1("Ilha de buffet · proteção de vidro", "restaurant", 3, 1.2, [
		R$1(.03, .03, 2.94, 1.14, .08),
		...Array.from({ length: 4 }, (_, i) => R$1(.18 + i * .68, .2, .58, .6, .06, "none")),
		P$1("M.12 .93H2.88M.12 .98H2.88"),
		...[
			[.12, .12],
			[2.88, .12],
			[.12, 1.06],
			[2.88, 1.06]
		].map(([x, y]) => C$1(x, y, .035))
	]),
	waiterStation: add$1("Estação de serviço · talheres e louça", "restaurant", 1.4, .7, [
		R$1(.03, .03, 1.34, .64, .04),
		R$1(.1, .12, .55, .45, .02, "none"),
		C$1(.38, .35, .18, "none"),
		C$1(.38, .35, .13, "none"),
		R$1(.77, .12, .53, .45, .02, "none"),
		P$1("M.94 .14v.41M1.11 .14v.41")
	]),
	servingTrolley: add$1("Carrinho de serviço", "restaurant", .9, .6, [
		R$1(.08, .06, .74, .48, .04),
		R$1(.14, .11, .62, .38, .03, "none"),
		P$1("M.03 .14v.32M.87 .14v.32"),
		...[
			[.16, .03],
			[.74, .03],
			[.16, .57],
			[.74, .57]
		].map(([x, y]) => R$1(x - .05, y - .02, .1, .04, .01))
	]),
	prisonBunk: add$1("Beliche de cela · metal", "detention", .9, 2.15, [
		R$1(.03, .03, .84, 2.09, .03),
		R$1(.1, .12, .7, 1.91, .04),
		R$1(.17, .2, .56, .35, .04),
		P$1("M.12 .69h.66M.12 1.86h.66"),
		...Array.from({ length: 5 }, (_, i) => P$1("M.68 " + (.85 + i * .21) + "h.18"))
	]),
	prisonBench: add$1("Banco fixo · contenção", "detention", 1.8, .45, [
		R$1(.04, .05, 1.72, .35, .02),
		P$1("M.1 .17h1.6M.1 .28h1.6"),
		...[
			[.12, .1],
			[1.68, .1],
			[.12, .35],
			[1.68, .35]
		].map(([x, y]) => C$1(x, y, .025))
	]),
	cellSanitary: add$1("Módulo sanitário de cela", "detention", .85, 1.1, [
		R$1(.03, .03, .79, 1.04, .04),
		R$1(.12, .1, .61, .3, .06, "none"),
		C$1(.425, .25, .025),
		P$1("M.425 .07v.14"),
		{
			tag: "ellipse",
			cx: .425,
			cy: .74,
			rx: .25,
			ry: .25
		},
		{
			tag: "ellipse",
			cx: .425,
			cy: .74,
			rx: .15,
			ry: .18,
			fill: "none"
		},
		R$1(.2, .43, .45, .11, .02)
	]),
	visitingDesk: add$1("Bancada de visita · divisória envidraçada", "detention", 1.8, 1.9, [
		...seat$1(.25, .05),
		...seat$1(1.05, 1.3, .5, .55, "up"),
		...table(.08, .66, 1.64, .55),
		P$1("M.13 .91h1.54M.13 .96h1.54"),
		R$1(.14, .72, .18, .12, .03),
		R$1(1.48, 1.03, .18, .12, .03)
	]),
	barredPartition: add$1("Grade de contenção · painel decorativo", "detention", 2, .3, [
		R$1(.03, .03, 1.94, .24, .01),
		P$1("M.08 .09h1.84M.08 .21h1.84"),
		...Array.from({ length: 12 }, (_, i) => P$1("M" + (.12 + i * .16) + " .04v.22"))
	]),
	restraintDesk: add$1("Mesa fixa de entrevista", "detention", 1.8, 2, [
		...seat$1(.65, .03),
		...seat$1(.65, 1.42, .5, .55, "up"),
		...table(.12, .68, 1.56, .64),
		...[
			[.22, .78],
			[1.58, .78],
			[.22, 1.22],
			[1.58, 1.22]
		].map(([x, y]) => C$1(x, y, .025))
	]),
	roundFountain: add$1("Fonte ornamental · bacia circular", "decor", 3, 3, [
		C$1(1.5, 1.5, 1.47),
		C$1(1.5, 1.5, 1.34),
		C$1(1.5, 1.5, .55),
		C$1(1.5, 1.5, .43),
		C$1(1.5, 1.5, .12),
		P$1("M.35 1.5a1.15 1.15 0 0 1 .6-1M2.65 1.5a1.15 1.15 0 0 1-.6 1"),
		...Array.from({ length: 6 }, (_, i) => {
			const a = i * Math.PI / 3;
			return C$1(1.5 + .79 * Math.cos(a), 1.5 + .79 * Math.sin(a), .04);
		})
	]),
	wallFountain: add$1("Fonte de parede · cascata", "decor", 2.4, .8, [
		R$1(.03, .03, 2.34, .74, .08),
		R$1(.13, .2, 2.14, .47, .06, "none"),
		R$1(.12, .07, 2.16, .11, .02),
		...Array.from({ length: 7 }, (_, i) => P$1("M" + (.4 + i * .26) + " .19v.22")),
		P$1("M.3 .54q.2-.08 .4 0t.4 0t.4 0t.4 0")
	]),
	standingStatue: add$1("Estátua em pedestal · vista superior", "decor", 1.2, 1.2, [
		R$1(.03, .03, 1.14, 1.14, .05),
		R$1(.12, .12, .96, .96, .03),
		R$1(.33, .82, .2, .2, .05),
		R$1(.67, .82, .2, .2, .05),
		{
			tag: "ellipse",
			cx: .6,
			cy: .6,
			rx: .38,
			ry: .22
		},
		C$1(.6, .5, .19),
		P$1("M.27 .66l-.07 .2M.93 .66l.07 .2")
	]),
	abstractSculpture: add$1("Escultura orbital · pedestal", "decor", 1.5, 1.5, [
		C$1(.75, .75, .7),
		C$1(.75, .75, .6, "none"),
		{
			tag: "ellipse",
			cx: .75,
			cy: .75,
			rx: .46,
			ry: .18,
			fill: "none"
		},
		{
			tag: "ellipse",
			cx: .75,
			cy: .75,
			rx: .18,
			ry: .46,
			fill: "none"
		},
		C$1(.75, .75, .12)
	]),
	wallArtwork: add$1("Quadro de parede · moldura dupla", "decor", 1.4, .25, [
		R$1(.02, .02, 1.36, .12, .01),
		R$1(.08, .045, 1.24, .07, 0, "none"),
		P$1("M.18 .06h1.04")
	]),
	artDisplay: add$1("Painel artístico autoportante", "decor", 1.6, .5, [
		R$1(.08, .04, .2, .42, .03),
		R$1(1.32, .04, .2, .42, .03),
		R$1(.03, .19, 1.54, .12, .02),
		R$1(.1, .22, 1.4, .06, 0, "none")
	]),
	vipSofa: add$1("Sofá VIP · bancos costas com costas", "casino", 2.4, 2.4, [
		R$1(.04, .3, 2.32, 1.8, .16),
		...[.31, 1.4].flatMap((y) => Array.from({ length: 3 }, (_, i) => [
			R$1(.25 + i * .64, y + .07, .6, .62, .09),
			R$1(.29 + i * .64, y + .11, .52, .54, .07, "none"),
			P$1("M" + (.39 + i * .64) + " " + (y + .2) + "h.32")
		])),
		R$1(.2, 1.03, 2, .34, .12),
		R$1(.28, 1.1, 1.84, .2, .07, "none"),
		P$1("M.87 1.07v.26M1.53 1.07v.26"),
		...[.07, 2.13].flatMap((x) => [R$1(x, .4, .2, .58, .07), R$1(x, 1.42, .2, .58, .07)])
	]),
	conciergeDesk: add$1("Balcão de concierge · cassino", "casino", 2.6, 1.3, [
		R$1(.03, .03, 2.54, 1.24, .18),
		R$1(.15, .16, 2.3, .62, .1, "none"),
		R$1(.28, .27, .55, .32, .03),
		R$1(.34, .31, .43, .15, .02, "none"),
		R$1(1.75, .27, .55, .32, .03),
		R$1(1.81, .31, .43, .15, .02, "none"),
		P$1("M.16 1.08H2.44")
	]),
	coatCheck: add$1("Chapelaria · atendimento e entrega", "casino", 2.8, 1.4, [
		P$1("M.05 .06H2.74V.49H.52V.86H.05Z", "inherit"),
		P$1("M.1 .13H2.67M.12 .78V.55"),
		R$1(1.96, .18, .32, .2, .025),
		P$1("M2 .23h.22"),
		R$1(.62, .95, 2.06, .32, .06),
		P$1("M.71 1.07h1.86"),
		...coats(.82, 1.05, 6, .3)
	]),
	neutralBarLink: add$1("Extensão de balcão · trecho neutro", "bar", 1.2, .8, [R$1(0, .03, 1.2, .74, 0, "inherit"), P$1("M0 .075H1.2M0 .67H1.2M.13 .72v.045M1.07 .72v.045")]),
	dinerSheetTable: add$1("Mesa de chapa com cadeiras tubulares", "restaurant", 1.55, 1.85, [
		seat$1(.46, .015, .62, .44),
		seat$1(.46, 1.395, .62, .44, "up"),
		...table(.18, .55, 1.18, .73),
		...[
			[.26, .63],
			[1.28, .63],
			[.26, 1.2],
			[1.28, 1.2]
		].map(([x, y]) => C$1(x, y, .018)),
		P$1("M.41 .12v.24q0 .06 .07 .06M1.12 .12v.24q0 .06-.07 .06M.41 1.72v-.23M1.12 1.72v-.23")
	]),
	dinerFoldingTable: add$1("Mesa dobrável com cadeiras de ripas", "restaurant", 1.7, 1.8, [
		...table(.2, .56, 1.3, .72),
		R$1(.24, .87, .1, .1, .015),
		R$1(1.37, .87, .1, .1, .015),
		P$1("M.85 .61v.61"),
		...[[.34, .03], [.84, 1.36]].flatMap(([x, y]) => [
			R$1(x, y, .51, .4, .035),
			P$1("M" + (x + .04) + " " + (y + .09) + "h.43m-.43 .09h.43m-.43 .09h.43"),
			C$1(x + .04, y + .2, .025),
			C$1(x + .47, y + .2, .025)
		])
	]),
	dinerWallLedge: add$1("Balcão de parede com bancos fixos", "restaurant", 2.4, 1.25, [
		...table(.02, .02, 2.36, .48),
		P$1("M.12 .11h2.16M.22 .47v.11m1.96-.11v.11"),
		...[
			.4,
			1.2,
			2
		].flatMap((x) => [
			R$1(x - .055, .51, .11, .53, .02),
			C$1(x, .98, .23),
			C$1(x, .98, .17, "none")
		])
	]),
	velvetBarrier: add$1("Balizadores com cordão · fila VIP", "casino", 1.8, .3, [
		C$1(.15, .15, .13),
		C$1(1.65, .15, .13),
		C$1(.15, .15, .045),
		C$1(1.65, .15, .045),
		P$1("M.18 .15Q.9 .29 1.62 .15")
	]),
	luggageCart: add$1("Carrinho de bagagens · hotel", "quarters", 1.2, .8, [
		R$1(.1, .05, 1, .7, .1),
		R$1(.17, .12, .86, .56, .06, "none"),
		P$1("M.07 .17v.46M1.13 .17v.46"),
		R$1(.25, .21, .4, .39, .04),
		R$1(.69, .21, .25, .39, .04),
		P$1("M.32 .18h.22M.75 .18h.13")
	]),
	laundryMachine: add$1("Lavadora industrial · vista superior", "sanitary", 1.2, 1, [
		R$1(.03, .03, 1.14, .94, .04),
		R$1(.09, .1, 1.02, .17, .03),
		C$1(.23, .18, .04),
		R$1(.38, .14, .35, .08, .01, "none"),
		R$1(.11, .33, .98, .56, .06, "none"),
		C$1(.6, .61, .21, "none"),
		P$1("M.15 .94h.9")
	]),
	baggageScanner: add$1("Inspeção de bagagens · esteira", "security", 2.4, 1.1, [
		R$1(.03, .17, 2.34, .76, .04),
		...Array.from({ length: 15 }, (_, i) => P$1("M" + (.14 + i * .15) + " .22v.66")),
		R$1(.77, .03, .86, 1.04, .09),
		R$1(.87, .12, .66, .86, .04, "none"),
		R$1(1.02, .24, .36, .26, .03),
		P$1("M1.08 .32h.24M1.08 .4h.24")
	]),
	gymTreadmill: add$1("Esteira ergométrica · painel analógico", "fitness", .9, 2.1, [
		R$1(.06, .09, .78, 1.96, .08),
		R$1(.18, .48, .54, 1.47, .03),
		P$1("M.22 .6h.46M.22 1.82h.46M.23 .65v1.1M.67 .65v1.1"),
		R$1(.09, .04, .72, .38, .06),
		R$1(.19, .11, .27, .17, .02),
		P$1("M.22 .2h.2M.27 .16v.06M.35 .14v.08"),
		C$1(.58, .19, .055),
		C$1(.71, .19, .035),
		R$1(.08, .43, .055, .83, .02),
		R$1(.765, .43, .055, .83, .02),
		P$1("M.13 .49h.06M.71 .49h.06")
	]),
	gymCycle: add$1("Bicicleta ergométrica · resistência mecânica", "fitness", .75, 1.3, [
		R$1(.06, .1, .63, .09, .03),
		R$1(.06, 1.1, .63, .09, .03),
		R$1(.31, .15, .13, .98, .03),
		R$1(.27, .22, .21, .5, .06),
		P$1("M.32 .26v.4M.38 .26v.4M.43 .26v.4"),
		R$1(.12, .74, .13, .18, .03),
		R$1(.5, .54, .13, .18, .03),
		P$1("M.25 .83h.12v-.2h.13"),
		P$1("M.14 .38V.12Q.375 -.02 .61 .12V.38"),
		R$1(.28, .08, .19, .14, .02),
		P$1("M.31 .14h.13"),
		P$1("M.26 1.06Q.19 .86 .375 .86Q.56 .86 .49 1.06Z", "currentColor")
	]),
	gymBenchPress: add$1("Banco de supino · barra e anilhas", "fitness", 1.8, 2, [
		R$1(.45, .2, .9, .09, .02),
		R$1(.45, .24, .09, 1.32, .02),
		R$1(1.26, .24, .09, 1.32, .02),
		R$1(.62, .48, .56, 1.05, .07),
		R$1(.64, 1.59, .52, .3, .06),
		R$1(.68, .54, .44, .92, .05, "none"),
		P$1("M.9 1.89v.07M.64 1.96h.52"),
		R$1(.03, .34, 1.74, .045, .01),
		...[
			.17,
			.27,
			1.48,
			1.58
		].map((x) => R$1(x, .16, .07, .4, .02)),
		R$1(.49, .27, .12, .18, .02),
		R$1(1.19, .27, .12, .18, .02)
	]),
	gymWeightStation: add$1("Estação de musculação · torre e polias", "fitness", 1.4, 2, [
		R$1(.08, .08, 1.24, .55, .05),
		R$1(.21, .15, .98, .35, .03),
		...Array.from({ length: 5 }, (_, i) => P$1("M.27 " + (.2 + i * .055) + "h.86")),
		R$1(.15, .63, .08, 1.25, .02),
		R$1(1.17, .63, .08, 1.25, .02),
		P$1("M.19 1.85h1.02M.31 .67H.09v.38M1.09 .67h.22v.38"),
		C$1(.46, .56, .09),
		C$1(.94, .56, .09),
		P$1("M.46 .65v.45M.94 .65v.45"),
		R$1(.48, .78, .44, .6, .06),
		R$1(.44, 1.43, .52, .4, .07),
		R$1(.53, .84, .34, .47, .04, "none"),
		P$1("M.7 1.87v.08M.43 1.95h.54")
	]),
	gymDumbbellRack: add$1("Suporte de halteres · pares organizados", "fitness", 1.8, .65, [
		R$1(.03, .04, .12, .57, .02),
		R$1(1.65, .04, .12, .57, .02),
		R$1(.15, .12, 1.5, .4, .03),
		P$1("M.16 .2h1.48M.16 .45h1.48"),
		...Array.from({ length: 5 }, (_, i) => {
			const x = .25 + i * .3;
			return [
				R$1(x, .2, .045, .25, .01),
				R$1(x + .12, .2, .045, .25, .01),
				R$1(x + .045, .3, .075, .045, .01)
			];
		})
	]),
	detentionDining: add$1("Mesa de refeitório · bancos ancorados", "detention", 2.4, 1.8, [
		...[.35, 1.92].map((x) => R$1(x, .12, .13, 1.56, .02)),
		R$1(.08, .06, 2.24, .33, .03),
		R$1(.08, 1.41, 2.24, .33, .03),
		...table(.05, .58, 2.3, .64),
		...[.22, 2.18].flatMap((x) => [C$1(x, .21, .035), C$1(x, 1.57, .035)]),
		P$1("M.17 .31h2.06M.17 1.49h2.06")
	]),
	detentionBed: add$1("Cama de cela · estrutura fixa", "detention", .95, 2.1, [
		...[.19, 1.75].map((y) => R$1(.01, y, .92, .12, .02)),
		R$1(.07, .03, .85, 2.04, .025),
		R$1(.13, .12, .72, 1.86, .07),
		R$1(.19, .2, .6, .36, .07),
		P$1("M.18 .69h.62M.18 1.81h.62"),
		...[.23, 1.79].flatMap((y) => [C$1(.04, y, .018), C$1(.88, y, .018)]),
		P$1("M.11 .75v.93M.87 .75v.93")
	]),
	cleaningCart: add$1("Carrinho de limpeza · saco e compartimentos", "quarters", .75, 1.25, [
		...[.12, .58].flatMap((x) => [R$1(x, .06, .07, .14, .02), R$1(x, 1.06, .07, .14, .02)]),
		R$1(.07, .14, .61, .97, .05),
		R$1(.12, .23, .51, .43, .03),
		R$1(.16, .27, .19, .34, .02),
		R$1(.4, .27, .19, .34, .02),
		P$1("M.17 .34h.17M.41 .34h.17M.12 .17v-.13h.51v.13"),
		P$1("M.13 .72Q.38 .65 .62 .72L.58 1.07Q.38 1.14 .16 1.07Z"),
		R$1(.11, .7, .53, .08, .025),
		P$1("M.2 .8l.04 .22M.53 .8l-.04 .22"),
		P$1("M.71 .24v.79M.69 .27h.04M.69 .98h.04")
	]),
	mattressSingle: add$1("Colchão avulso · solteiro", "quarters", .88, 1.88, mattress(.88, 1.88)),
	mattressDouble: add$1("Colchão avulso · casal", "quarters", 1.38, 1.88, mattress(1.38, 1.88))
};
//#endregion
//#region src/blueprints/utility-assets.js
var rect$1 = (x, y, width, height, rx = 1) => ({
	tag: "rect",
	x,
	y,
	width,
	height,
	rx
});
var path = (d) => ({
	tag: "path",
	d,
	fill: "none"
});
var circle$1 = (cx, cy, r) => ({
	tag: "circle",
	cx,
	cy,
	r
});
var asset$1 = (name, w, h, shapes) => ({
	name,
	w,
	h,
	category: "exterior",
	shapes
});
var utilityAssets = {
	distributionPole: asset$1("Poste elétrico · cruzetas e luminária", 2.4, 2.6, [
		circle$1(50, 50, 10),
		circle$1(50, 50, 6),
		rect$1(46, 14, 8, 70, 1),
		rect$1(12, 20, 76, 6, 1),
		rect$1(12, 42, 76, 6, 1),
		...[
			20,
			50,
			80
		].flatMap((x) => [
			circle$1(x, 20, 4),
			circle$1(x, 20, 2),
			circle$1(x, 42, 4),
			circle$1(x, 42, 2)
		]),
		path("M48 56L21 75M52 59L24 78"),
		rect$1(9, 73, 22, 11, 4),
		rect$1(12, 76, 16, 5, 2),
		path("M15 76v5M20 76v5M25 76v5"),
		rect$1(43, 70, 14, 15, 2),
		path("M47 74h6M47 78h6")
	]),
	plazaLantern: asset$1("Poste de praça · lanterna retrô", .75, .75, [
		circle$1(50, 50, 36),
		circle$1(50, 50, 31),
		{
			tag: "path",
			d: "M50 10L82 28V72L50 90L18 72V28Z"
		},
		{
			tag: "path",
			d: "M50 18L75 32V68L50 82L25 68V32Z",
			fill: "none"
		},
		path("M50 18V82M25 32L75 68M75 32L25 68"),
		circle$1(50, 50, 8),
		circle$1(50, 50, 4)
	]),
	streetLamp: asset$1("Poste de iluminação · braço duplo", 1.2, 3, [
		rect$1(39, 37, 22, 26, 3),
		circle$1(50, 50, 8),
		rect$1(47, 12, 6, 76),
		rect$1(25, 4, 50, 16, 4),
		rect$1(29, 7, 42, 10, 2),
		rect$1(25, 80, 50, 16, 4),
		rect$1(29, 83, 42, 10, 2),
		path("M36 7v10M50 7v10M64 7v10M36 83v10M50 83v10M64 83v10")
	]),
	distributionTransformer: asset$1("Transformador de distribuição", 2, 1.5, [
		rect$1(5, 8, 90, 84, 3),
		rect$1(14, 18, 50, 62, 3),
		...Array.from({ length: 7 }, (_, i) => path("M" + (18 + i * 7) + " 23v52")),
		...[
			28,
			50,
			72
		].flatMap((y) => [circle$1(80, y, 7), circle$1(80, y, 3)]),
		path("M18 86h64")
	]),
	roundManhole: asset$1("Tampa de bueiro circular", .9, .9, [
		circle$1(50, 50, 45),
		circle$1(50, 50, 39),
		...Array.from({ length: 7 }, (_, i) => path("M25 " + (27 + i * 8) + "h50")),
		rect$1(40, 16, 20, 5, 1),
		rect$1(40, 79, 20, 5, 1)
	]),
	serviceManhole: asset$1("Tampa de inspeção dupla", 1.6, .9, [
		rect$1(4, 6, 92, 88, 3),
		rect$1(10, 12, 38, 76, 1),
		rect$1(52, 12, 38, 76, 1),
		path("M15 20l28 60M57 20l28 60"),
		rect$1(35, 43, 7, 14, 1),
		rect$1(58, 43, 7, 14, 1)
	])
};
//#endregion
//#region src/blueprints/settlement-assets.js
var rect = (x, y, width, height, rx = 0) => ({
	tag: "rect",
	x,
	y,
	width,
	height,
	rx
});
var line = (d) => ({
	tag: "path",
	d,
	fill: "none"
});
var circle = (cx, cy, r) => ({
	tag: "circle",
	cx,
	cy,
	r
});
var ribs = (x, y, w, h, count) => Array.from({ length: count }, (_, i) => line("M" + (x + i * w / (count - 1)) + " " + y + "v" + h));
var stroke = (shape, width) => ({
	...shape,
	strokeWidth: width
});
var roof = (x, y, w, h) => [
	stroke(rect(x, y, w, h, 2), 1.5),
	rect(x + 2, y + 2, w - 4, h - 4, 1),
	line("M" + (x + 3) + " " + (y + h - 5) + "h" + (w - 6))
];
var skylight = (x, y, w, h) => [
	stroke(rect(x, y, w, h, 1), 1.1),
	rect(x + 2, y + 2, w - 4, h - 5),
	...Array.from({ length: 3 }, (_, i) => line("M" + (x + 2 + (i + 1) * (w - 4) / 4) + " " + (y + 2) + "v" + (h - 5))),
	line("M" + (x + 3) + " " + (y + 6) + "l3-3M" + (x + w - 7) + " " + (y + h - 5) + "l3-3")
];
var fan = (x, y) => [
	stroke(rect(x - 7, y - 7, 14, 14, 1), 1),
	rect(x - 5.5, y - 5.5, 11, 11, 1),
	circle(x, y, 4.5),
	...[
		0,
		120,
		240
	].map((a) => ({
		tag: "path",
		d: "M" + x + " " + y + "q-5-1-3-4q4-1 3 4Z",
		transform: "rotate(" + a + " " + x + " " + y + ")",
		fill: "currentColor",
		stroke: "none"
	})),
	circle(x, y, 1.1)
];
var pipe = (d) => [stroke(line(d), 3), stroke(line(d), 1.3)];
var tank = (x, y, r) => [
	stroke(circle(x, y, r), 1.4),
	circle(x, y, r - 2),
	line("M" + (x - r + 3) + " " + y + "Q" + x + " " + (y - r + 2) + " " + (x + r - 3) + " " + y),
	circle(x + 3, y - 2, 2.5),
	stroke(line("M" + (x - r - 2) + " " + (y - 7) + "v14"), 1.3),
	...[
		-5,
		-2,
		1,
		4
	].map((v) => line("M" + (x - r - 3) + " " + (y + v) + "h3"))
];
var asset = (name, w, h, shapes) => ({
	name,
	w,
	h,
	category: "settlement",
	exterior: true,
	shapes
});
var grille = (x, y, w, h) => [rect(x, y, w, h, 1), ...ribs(x + 2, y + 2, w - 4, h - 4, 6)];
var cross = (x, y, size = 10) => [stroke(line("M" + (x - size / 2) + " " + y + "h" + size + "M" + x + " " + (y - size / 2) + "v" + size), 2)];
var dome = (x, y, r) => [
	stroke(circle(x, y, r), 1.7),
	circle(x, y, r - 2),
	line("M" + (x - r + 3) + " " + y + "Q" + x + " " + (y - r + 1) + " " + (x + r - 3) + " " + y),
	line("M" + x + " " + (y - r + 3) + "Q" + (x - r / 2) + " " + y + " " + x + " " + (y + r - 3)),
	circle(x, y, 3)
];
var awning = (x, y, w, h) => [rect(x, y, w, h, 1), ...ribs(x + 2, y + 1, w - 4, h - 2, 5)];
var buildings = {
	colonyReactor: asset("Contenção de reator", 44, 44, [
		...pipe("M48 50H88V82"),
		...roof(8, 16, 72, 68),
		...dome(43, 48, 31),
		...roof(78, 58, 18, 32),
		...fan(87, 70),
		...[
			0,
			90,
			180,
			270
		].map((a) => ({
			...stroke(rect(39, 13, 8, 7, 1), 1.2),
			transform: "rotate(" + a + " 43 48)"
		})),
		...roof(24, 82, 38, 14),
		...grille(30, 86, 26, 6)
	]),
	colonyLaboratory: asset("Laboratório de pesquisa", 32, 26, [
		...roof(6, 14, 58, 70),
		...roof(64, 27, 30, 46),
		...skylight(15, 23, 39, 20),
		...roof(14, 51, 40, 24),
		...fan(25, 63),
		...fan(43, 63),
		...grille(70, 34, 18, 13),
		...grille(70, 53, 18, 13),
		...roof(28, 83, 22, 13),
		line("M33 87h12M33 91h12"),
		rect(77, 16, 10, 11, 1),
		circle(82, 21, 2)
	]),
	colonyAdministration: asset("Prédio administrativo", 36, 28, [
		...roof(8, 8, 84, 30),
		...roof(8, 38, 26, 49),
		...roof(66, 38, 26, 49),
		...skylight(20, 15, 60, 15),
		...roof(34, 38, 32, 22),
		...skylight(40, 42, 20, 14),
		...fan(21, 52),
		...fan(79, 52),
		...grille(15, 66, 12, 12),
		...grille(73, 66, 12, 12),
		...awning(37, 65, 26, 9),
		rect(37, 79, 26, 10, 1),
		line("M41 82h18M41 86h18")
	]),
	colonyClinic: asset("Posto médico", 20, 16, [
		...roof(8, 12, 84, 72),
		...roof(58, 23, 24, 46),
		...fan(70, 36),
		...grille(63, 49, 14, 14),
		...cross(32, 37, 19),
		...skylight(18, 57, 29, 15),
		...awning(25, 84, 48, 12)
	]),
	colonyHospital: asset("Hospital colonial", 52, 40, [
		...roof(6, 8, 28, 82),
		...roof(66, 8, 28, 82),
		...roof(34, 28, 32, 44),
		...skylight(12, 18, 16, 26),
		...skylight(72, 18, 16, 26),
		...fan(20, 60),
		...fan(80, 60),
		...grille(13, 72, 14, 11),
		...grille(73, 72, 14, 11),
		...roof(39, 34, 22, 31),
		...cross(50, 49, 15),
		...awning(37, 76, 26, 13),
		line("M42 92h16M42 95h16")
	]),
	colonySecurity: asset("Posto de segurança", 28, 24, [
		...roof(9, 13, 82, 72),
		...roof(3, 7, 21, 23),
		...roof(76, 7, 21, 23),
		...roof(3, 70, 21, 23),
		...roof(76, 70, 21, 23),
		...roof(31, 27, 38, 40),
		...fan(42, 40),
		...grille(52, 33, 10, 23),
		...awning(35, 77, 30, 13),
		stroke(line("M36 20h28"), 1.3),
		...[13, 86].map((x) => rect(x, 16, 4, 4)),
		...[13, 86].map((x) => rect(x, 79, 4, 4))
	]),
	colonySmallResidence: asset("Habitação compacta", 14, 10, [
		...roof(8, 14, 84, 68),
		...skylight(17, 25, 35, 24),
		...fan(72, 35),
		...grille(62, 54, 20, 16),
		...awning(27, 82, 46, 12),
		line("M18 61h34M18 66h34")
	]),
	colonyDenseResidence: asset("Habitação de alta densidade", 48, 36, [
		...roof(6, 8, 88, 84),
		...roof(12, 14, 76, 72),
		...roof(18, 20, 64, 60),
		...[
			26,
			48,
			70
		].flatMap((x) => [rect(x - 6, 27, 12, 43, 1), ...ribs(x - 4, 30, 8, 37, 4)]),
		...roof(35, 41, 30, 27),
		...fan(43, 54),
		...fan(57, 54),
		...awning(34, 87, 32, 10),
		line("M7 30h5M7 50h5M7 70h5M88 30h5M88 50h5M88 70h5")
	]),
	colonyWarehouse: asset("Armazém de cargas", 44, 30, [
		...roof(5, 8, 90, 72),
		...ribs(12, 14, 76, 60, 12),
		...skylight(18, 32, 64, 14),
		...[
			15,
			38,
			61
		].flatMap((x) => [...roof(x, 80, 18, 16), line("M" + (x + 3) + " 84h12M" + (x + 3) + " 89h12")])
	]),
	colonyColdStore: asset("Armazém refrigerado", 34, 26, [
		...roof(5, 10, 90, 70),
		...roof(11, 17, 25, 55),
		...fan(23, 31),
		...fan(23, 56),
		...[
			45,
			60,
			75
		].map((x) => rect(x, 20, 9, 49, 1)),
		...roof(40, 80, 43, 15),
		line("M45 85h33M45 90h33")
	]),
	colonyAtmosphere: asset("Processador atmosférico", 70, 48, [
		...roof(7, 9, 86, 82),
		...roof(14, 17, 72, 66),
		...roof(33, 10, 34, 80),
		...grille(39, 18, 22, 28),
		...grille(39, 54, 22, 28),
		...[22, 78].flatMap((x) => [
			...fan(x, 29),
			...fan(x, 50),
			...fan(x, 71)
		]),
		...[3, 89].flatMap((x) => [rect(x, 35, 8, 30, 1), ...ribs(x + 2, 38, 4, 24, 3)]),
		...awning(35, 91, 30, 7)
	]),
	colonyHydroponics: asset("Fazenda hidropônica", 54, 38, [
		...roof(5, 6, 90, 88),
		...[
			12,
			39,
			66
		].flatMap((x) => [...skylight(x, 13, 22, 59), ...[
			28,
			43,
			58
		].map((y) => line("M" + (x + 2) + " " + y + "h18"))]),
		...pipe("M16 80H84"),
		...tank(22, 82, 8),
		...tank(78, 82, 8),
		...roof(40, 75, 20, 16),
		...grille(44, 79, 12, 8)
	]),
	colonyWaterPlant: asset("Estação de tratamento de água", 42, 32, [
		...pipe("M22 25H76V73H22"),
		...[25, 73].flatMap((y) => [
			stroke(rect(7, y - 17, 43, 34, 8), 1.4),
			rect(10, y - 14, 37, 28, 7),
			line("M16 " + (y - 8) + "q6-4 12 0t12 0M16 " + (y + 6) + "q6-4 12 0t12 0")
		]),
		...roof(61, 11, 32, 78),
		...fan(77, 26),
		...grille(68, 42, 18, 32)
	]),
	colonySubstation: asset("Subestação elétrica", 30, 24, [
		...roof(5, 9, 90, 82),
		...[15, 55].flatMap((x) => [
			...roof(x, 20, 30, 54),
			...grille(x + 5, 26, 20, 26),
			...[
				x + 7,
				x + 15,
				x + 23
			].flatMap((cx) => [circle(cx, 62, 3), circle(cx, 62, 1)])
		]),
		...pipe("M10 81H90"),
		...awning(37, 89, 26, 8)
	]),
	colonyGarage: asset("Oficina e garagem de veículos", 40, 28, [
		...roof(6, 10, 88, 66),
		...skylight(15, 20, 48, 15),
		...fan(79, 28),
		...grille(15, 45, 70, 19),
		...[
			10,
			38,
			66
		].flatMap((x) => [...roof(x, 76, 24, 20), line("M" + (x + 3) + " 82h18M" + (x + 3) + " 88h18")])
	]),
	colonyComms: asset("Estação de comunicações", 30, 30, [
		...roof(10, 14, 80, 70),
		...roof(18, 22, 44, 54),
		rect(25, 29, 30, 37, 2),
		{
			tag: "ellipse",
			cx: 40,
			cy: 43,
			rx: 14,
			ry: 10
		},
		{
			tag: "ellipse",
			cx: 40,
			cy: 43,
			rx: 11,
			ry: 7,
			fill: "none"
		},
		stroke(line("M27 48L40 35L53 48M40 53v10M32 63h16"), 1.2),
		circle(40, 35, 2),
		...fan(76, 37),
		...fan(76, 63),
		...roof(37, 84, 26, 12),
		stroke(line("M22 14V4M16 8h12"), 1.3)
	]),
	colonyHabitat: asset("Bloco habitacional · cobertura", 28, 20, [
		...roof(5, 12, 90, 76),
		...skylight(14, 24, 40, 24),
		...roof(62, 23, 24, 45),
		...fan(74, 36),
		...fan(74, 54),
		rect(14, 59, 36, 17, 1),
		rect(17, 62, 30, 11),
		...ribs(22, 62, 20, 11, 5),
		line("M17 67h30"),
		...roof(1, 36, 10, 28),
		...roof(89, 36, 10, 28),
		line("M19 18h36M19 81h36")
	]),
	colonyHangar: asset("Hangar industrial · cobertura", 40, 28, [
		...roof(5, 8, 90, 78),
		...ribs(13, 14, 74, 65, 9).map((p) => stroke(p, .8)),
		...skylight(22, 35, 56, 16),
		rect(16, 86, 68, 9, 1),
		line("M20 89h60M20 92h60"),
		...roof(1, 23, 11, 16),
		...roof(88, 60, 11, 16)
	]),
	colonyFactory: asset("Usina de processamento · exterior", 42, 30, [
		...pipe("M56 29H82V72H56"),
		...roof(4, 12, 56, 76),
		...roof(10, 19, 19, 61),
		...fan(19.5, 31),
		...fan(19.5, 49),
		...fan(19.5, 67),
		rect(36, 21, 16, 52, 2),
		...ribs(39, 25, 10, 44, 4),
		line("M36 38h16M36 56h16"),
		...tank(81, 27, 15),
		...tank(81, 73, 15),
		...roof(10, 89, 44, 8)
	]),
	colonyGreenhouse: asset("Estufas de cultivo · conjunto", 30, 24, [
		...[
			5,
			37,
			69
		].flatMap((x) => [
			stroke(rect(x, 7, 25, 73, 6), 1.4),
			rect(x + 2, 9, 21, 69, 5),
			line("M" + (x + 12.5) + " 10v66"),
			...[
				22,
				36,
				50,
				64
			].map((y) => stroke(line("M" + (x + 2) + " " + y + "h21"), 1)),
			...[
				14,
				28,
				42,
				56,
				70
			].flatMap((y) => [line("M" + (x + 4) + " " + (y + 4) + "l4-4"), line("M" + (x + 16) + " " + (y + 4) + "l4-4")]),
			rect(x + 8, 80, 9, 6)
		]),
		...roof(10, 86, 80, 10),
		...roof(38, 87, 24, 12)
	]),
	colonyLandingPad: asset("Plataforma de pouso · espaço-porto", 48, 48, [
		stroke({
			tag: "path",
			d: "M25 5H75L95 25V75L75 95H25L5 75V25Z"
		}, 1.5),
		line("M26 8H74L92 26V74L74 92H26L8 74V26Z"),
		line("M28 12H72L88 28V72L72 88H28L12 72V28Z"),
		stroke(line("M13 73L28 87H72L87 73"), 1.1),
		stroke({
			...circle(50, 50, 30),
			fill: "none"
		}, 1.2),
		{
			...circle(50, 50, 27.5),
			fill: "none"
		},
		stroke(line("M43 38v24M57 38v24M43 50h14"), 1.8),
		...[
			[50, 18],
			[82, 50],
			[50, 82],
			[18, 50]
		].flatMap(([x, y]) => [stroke(rect(x - 3, y - 2, 6, 4, 1), 1), rect(x - 1.8, y - 1, 3.6, 2, .5)]),
		...[
			0,
			90,
			180,
			270
		].flatMap((angle) => [
			{
				...stroke(line("M20 20l5 5M23 17l5 5M17 23l5 5"), 1.2),
				transform: "rotate(" + angle + " 50 50)"
			},
			{
				...rect(36, 7.5, 8, 3, .5),
				transform: "rotate(" + angle + " 50 50)"
			},
			{
				...line("M38 8.5h4"),
				transform: "rotate(" + angle + " 50 50)"
			}
		])
	]),
	colonyMarket: asset("Mercado coberto · pavilhão", 32, 24, [
		...roof(6, 8, 88, 84),
		...[10, 59].flatMap((x) => [
			rect(x, 13, 31, 74, 1),
			stroke(line("M" + (x + 15.5) + " 13v74"), 1.1),
			...[
				27,
				42,
				57,
				72
			].map((y) => line("M" + x + " " + y + "l15.5-3L" + (x + 31) + " " + y))
		]),
		...skylight(43, 24, 14, 52),
		rect(43, 4, 14, 8, 1),
		rect(43, 88, 14, 8, 1)
	]),
	colonySilo: asset("Silos de armazenamento · conjunto", 24, 20, [
		rect(46, 13, 8, 74, 1),
		...[
			[25, 27],
			[75, 27],
			[25, 73],
			[75, 73]
		].flatMap(([x, y]) => [...tank(x, y, 20), ...[
			45,
			135,
			225,
			315
		].map((a) => line("M" + (x + 5 * Math.cos(a * Math.PI / 180)) + " " + (y + 5 * Math.sin(a * Math.PI / 180)) + "L" + (x + 17 * Math.cos(a * Math.PI / 180)) + " " + (y + 17 * Math.sin(a * Math.PI / 180))))]),
		line("M45 27h10M45 73h10")
	]),
	colonyControl: asset("Posto de controle · cobertura", 18, 16, [
		...roof(8, 14, 84, 72),
		...roof(18, 22, 48, 49),
		rect(27, 30, 29, 32, 3),
		{
			tag: "ellipse",
			cx: 41,
			cy: 43,
			rx: 13,
			ry: 9
		},
		{
			tag: "ellipse",
			cx: 41,
			cy: 43,
			rx: 10,
			ry: 6,
			fill: "none"
		},
		stroke(line("M29 48L41 36L53 48"), 1.2),
		circle(41, 36, 2),
		stroke(line("M41 51v8M34 59h14"), 1.8),
		...fan(78, 36),
		...fan(78, 60),
		...roof(40, 80, 20, 16),
		line("M44 85h12M44 90h12")
	])
};
var buildingCategories = {
	"settlement-living": [
		"colonyHabitat",
		"colonySmallResidence",
		"colonyDenseResidence",
		"colonyAdministration",
		"colonyMarket"
	],
	"settlement-care": [
		"colonyLaboratory",
		"colonyClinic",
		"colonyHospital",
		"colonySecurity",
		"colonyControl",
		"colonyComms"
	],
	"settlement-services": [
		"colonyGreenhouse",
		"colonyHydroponics",
		"colonyWaterPlant",
		"colonySubstation"
	]
};
var settlementAssets = Object.fromEntries(Object.entries(buildings).map(([id, asset]) => [id, {
	...asset,
	category: Object.entries(buildingCategories).find(([, ids]) => ids.includes(id))?.[0] || "settlement"
}]));
//#endregion
//#region src/blueprints/revised-assets.js
var R = (x, y, width, height, rx = 0, fill) => ({
	tag: "rect",
	x,
	y,
	width,
	height,
	rx,
	...fill ? { fill } : {}
});
var C = (cx, cy, r, fill) => ({
	tag: "circle",
	cx,
	cy,
	r,
	...fill ? { fill } : {}
});
var P = (d, fill = "none") => ({
	tag: "path",
	d,
	fill
});
var sink = (x, y, w = .5, h = .45) => [
	R(x, y, w, h, .05, "none"),
	R(x + .045, y + .045, w - .09, h - .09, .055, "none"),
	C(x + w / 2, y + h * .55, .025, "none"),
	P(`M${x + w / 2} ${y - .08}v.18m-.07 -.18h.14`)
];
var seat = (x, y, w = .5, h = .55) => [
	R(x, y, w, h, .08),
	R(x + .03, y + .02, w - .06, .12, .04),
	P(`M${x - .035} ${y + .2}v.22M${x + w + .035} ${y + .2}v.22`)
];
var panel = (x, y, w = .42, h = .3) => [
	R(x, y, w, h, .025),
	R(x + .04, y + .03, w - .08, h * .55, .02, "none"),
	P(`M${x + .05} ${y + h - .06}h${w - .1}`)
];
var base = (w, h) => [R(.03, .03, w - .06, h - .06, .04)];
var bulbs = (x, y, n, step) => Array.from({ length: n }, (_, i) => C(x + i * step, y, .025));
var add = (name, category, w, h, shapes, subgroup) => ({
	name,
	category,
	w,
	h,
	subgroup,
	shapes: shapes.map((s) => ({
		...s,
		transform: `scale(${100 / w} ${100 / h})`,
		strokeWidth: s.strokeWidth ?? .025
	}))
});
var vanity = (w) => [
	...base(w, .65),
	R(.12, .055, w - .24, .045, 0),
	...bulbs(.16, .16, Math.floor((w - .3) / .2) + 1, .2),
	P(`M.12 .52H${w - .12}`),
	...Array.from({ length: w > 2 ? 2 : 1 }, (_, i) => R(.22 + i * 1.2, .28, .45, .18, .02, "none"))
];
var revisedAssets = {
	barCounterStraight: add("Balcão de bar · cuba e escorredor", "bar", 2.4, .8, [
		...base(2.4, .8),
		P("M.03 .68H2.37"),
		...sink(.2, .19, .5, .4),
		R(.83, .18, .48, .43, .02, "none"),
		...Array.from({ length: 5 }, (_, i) => P(`M${.88 + i * .08} .23v.33`))
	], "Balcões e serviço"),
	barCounterCorner: add("Balcão de bar em L · cuba e área de serviço", "bar", 2.4, 2.4, [
		P("M.03 .03H2.37V.77H.77V2.37H.03Z", "inherit"),
		P("M.03 .65H2.37M.65 .77V2.37"),
		...sink(1.1, .18, .55, .4),
		...Array.from({ length: 4 }, (_, i) => P(`M${1.85 + i * .1} .19v.35`))
	], "Balcões e serviço"),
	drinkDispenserBank: add("Torre de chope · bandeja e quatro torneiras", "bar", 1.5, .7, [
		...base(1.5, .7),
		R(.15, .08, 1.2, .16, .04),
		...Array.from({ length: 4 }, (_, i) => P(`M${.3 + i * .3} .22v.22m-.045 -.13h.09`)),
		R(.15, .45, 1.2, .16, .02, "none"),
		...Array.from({ length: 10 }, (_, i) => P(`M${.21 + i * .115} .48v.1`))
	], "Balcões e serviço"),
	casinoCashier: add("Caixa de cassino · guichê com bandejas e terminal", "casino", 2.6, 1.2, [
		...base(2.6, 1.2),
		R(.08, .65, 2.44, .09),
		R(.12, .83, .9, .25, .02, "none"),
		R(1.15, .83, .9, .25, .02, "none"),
		...panel(.25, .15),
		...panel(1.4, .15),
		P("M.8 .66V.74M1.8 .66V.74")
	], "Atendimento e controle"),
	performanceStage: add("Palco completo · tablado e degraus frontais", "entertainment", 4, 3, [
		R(.04, .04, 3.92, 2.5, .04),
		R(.15, .15, 3.7, 2.28, 0, "none"),
		P("M.16 2.36H3.84M.06 .39l.06 .07-.06 .07M3.94 .39l-.06 .07 .06 .07"),
		R(1, 2.54, 2, .42),
		P("M1 2.68H3M1 2.82H3")
	], "Palco e bastidores"),
	dressingStation: add("Penteadeira · espelho linear e iluminação", "entertainment", 1.4, .65, vanity(1.4), "Camarins e suítes"),
	dressingVanityDouble: add("Penteadeira dupla · dois postos de camarim", "entertainment", 2.4, .65, vanity(2.4), "Camarins e suítes"),
	marketStall: add("Barraca de feira · balcão, bancada e postes (sem cobertura)", "market", 3, 2.5, [
		R(.1, .1, 2.8, .55),
		R(.1, 1.85, 2.8, .55),
		...[
			[.12, .12],
			[2.88, .12],
			[.12, 2.38],
			[2.88, 2.38]
		].map(([x, y]) => R(x - .07, y - .07, .14, .14)),
		P("M.22 2.25H2.78")
	], "Bancas e atendimento"),
	marketCounter: add("Balcão de comércio · superfície livre", "market", 2, .8, [...base(2, .8), P("M.1 .65H1.9")], "Bancas e atendimento"),
	tradeKiosk: add("Quiosque · guichê, terminal e cadeira (sem cobertura)", "market", 2.5, 2.5, [
		P("M.06 2.44V.06H2.44V2.44H2.32V.18H.18V2.44Z", "inherit"),
		R(.18, .2, 2.1, .6),
		...panel(.45, .3),
		...seat(.8, 1.2),
		P("M.06 2.44H.7M1.5 2.44H2.44")
	], "Bancas e atendimento"),
	stationBenchRow: add("Banco de estação · quatro assentos com braços", "transit", 3, .75, [R(.08, .34, 2.84, .12), ...Array.from({ length: 4 }, (_, i) => seat(.2 + i * .7, .09, .5, .55)).flat()], "Espera e serviços"),
	washTrough: add("Lavatório coletivo · três cubas e torneiras", "sanitary", 2.4, .6, [...base(2.4, .6), ...Array.from({ length: 3 }, (_, i) => sink(.15 + i * .78, .13, .5, .39)).flat()], "Higiene"),
	changingIsland: add("Ilha de vestiário · armários centrais e bancos laterais", "sanitary", 2.4, 1.2, [
		R(.06, .39, 2.28, .42),
		...Array.from({ length: 6 }, (_, i) => P(`M${.12 + i * .37} .4v.4`)),
		R(.06, .06, 2.28, .23, .025),
		R(.06, .91, 2.28, .23, .025),
		P("M.18 .17H2.22M.18 1.03H2.22")
	], "Vestiário e lavanderia"),
	servingCounter: add("Balcão de refeições · cubas aquecidas e trilho de bandejas", "galley", 3, .9, [
		...base(3, .9),
		...Array.from({ length: 4 }, (_, i) => [R(.16 + i * .68, .12, .54, .42, .06, "none"), P(`M${.25 + i * .68} .2h.36`)]).flat(),
		P("M.1 .68H2.9M.1 .78H2.9")
	], "Distribuição e preparo"),
	waterFilterSkid: add("Tratamento de água · membranas, bomba e coletores", "engineering", 2.6, 1.5, [
		...base(2.6, 1.5),
		...Array.from({ length: 3 }, (_, i) => [R(.45, .2 + i * .32, 1.7, .24, .12), P(`M.7 ${.2 + i * .32}v.24M1.9 ${.2 + i * .32}v.24`)]).flat(),
		P("M.3 .32V.96M2.3 .32V.96M.3 .32H.45M2.15 .32H2.3M.3 .64H.45M2.15 .64H2.3M.3 .96H.45M2.15 .96H2.3"),
		R(.5, 1.1, .65, .27, .06),
		P("M.3 .96V1.23H.5M1.15 1.23H2.3V.96"),
		...panel(1.5, 1.08, .4, .27)
	], "Fluidos e energia"),
	reactor: add("Reator · núcleo, anel de contenção e conexões", "engineering", 3.6, 3.6, [
		...base(3.6, 3.6),
		C(1.8, 1.8, 1.35),
		C(1.8, 1.8, 1.04, "none"),
		C(1.8, 1.8, .6),
		C(1.8, 1.8, .3, "none"),
		P("M1.8 .05V.45M1.8 3.15V3.55M.05 1.8H.45M3.15 1.8H3.55"),
		...panel(.2, .18, .65, .3)
	], "Fluidos e energia"),
	engine: add("Motor industrial · bloco, transmissão e radiador", "engineering", 2, 3.4, [
		R(.15, .1, 1.7, 3.2, .08),
		R(.4, .5, 1.2, 1.4, .06),
		...Array.from({ length: 5 }, (_, i) => P(`M.48 ${.65 + i * .23}H1.52`)),
		R(.55, 2.05, .9, .45, .08),
		R(.25, 2.75, 1.5, .4),
		...Array.from({ length: 8 }, (_, i) => P(`M${.35 + i * .18} 2.8v.3`)),
		P("M.8 1.9V2.05M1.2 1.9V2.05")
	], "Máquinas e manutenção"),
	hatch: add("Escotilha de manutenção · aro e travas", "access", 1, 1, [
		C(.5, .5, .46),
		C(.5, .5, .35),
		C(.5, .5, .09, "none"),
		P("M.5 .18V.82M.18 .5H.82"),
		...[
			[.5, .08],
			[.92, .5],
			[.5, .92],
			[.08, .5]
		].map(([x, y]) => R(x - .04, y - .04, .08, .08))
	], "Acessos")
};
var expandedAssets = {
	barBeerCellar: add("Rack de barris pressurizados", "bar", 2.2, 1.2, [...base(2.2, 1.2), ...Array.from({ length: 3 }, (_, i) => [
		C(.4 + i * .7, .6, .28),
		C(.4 + i * .7, .6, .19, "none"),
		P(`M${.4 + i * .7} .32V.1`)
	]).flat()], "Balcões e serviço"),
	barGlassWasher: add("Estação de lavagem de copos · cuba e máquina", "bar", 1.6, .8, [
		...base(1.6, .8),
		...sink(.12, .22, .5, .45),
		R(.83, .12, .65, .54, .04),
		P("M.93 .22H1.38M.93 .32H1.38")
	], "Balcões e serviço"),
	barCornerSeat: add("Banco de bar em L · assentos estofados", "bar", 2, 2, [P("M.05 .05H1.95V.65H.65V1.95H.05Z", "inherit"), P("M.16 1.85V.16H1.85M.7 .16V.6M1.3 .16V.6M.16 .7H.6M.16 1.3H.6")], "Mesas e convivência"),
	shuffleboard: add("Mesa de shuffleboard", "bar", 3, .75, [
		R(.04, .04, 2.92, .67, .08),
		R(.16, .14, 2.68, .47, .04, "none"),
		P("M2.25 .14V.61M2.45 .14V.61M2.65 .14V.61")
	], "Jogos de salão"),
	casinoBaccarat: add("Mesa de bacará · lugares e área do crupiê", "casino", 3, 1.7, [
		R(.04, .04, 2.92, 1.62, .6),
		R(.22, .22, 2.56, 1.26, .45, "none"),
		...Array.from({ length: 5 }, (_, i) => R(.42 + i * .48, 1.05, .28, .22, .04, "none")),
		R(1.15, .15, .7, .25, .04)
	], "Mesas de jogo"),
	casinoTerminal: add("Terminal de apostas retro · painel inclinado", "casino", .85, 1.1, [
		...base(.85, 1.1),
		R(.12, .12, .61, .5, .04),
		R(.2, .2, .45, .32, .02, "none"),
		P("M.15 .8H.7M.2 .9H.65")
	], "Máquinas e controle"),
	casinoChipSafe: add("Cofre de fichas · gabinete e bandejas", "casino", 1.5, .8, [
		...base(1.5, .8),
		R(.1, .15, .65, .5, .025),
		C(.43, .4, .09, "none"),
		...Array.from({ length: 4 }, (_, i) => R(.9, .12 + i * .14, .45, .1, .02, "none"))
	], "Máquinas e controle"),
	casinoQueuePost: add("Separador de fila · dois postes e cordão", "casino", 1.8, .35, [
		C(.15, .175, .13),
		C(1.65, .175, .13),
		P("M.28 .175Q.9 .3 1.52 .175")
	], "Atendimento e controle"),
	costumeRail: add("Arara de figurinos · suportes e cabides", "entertainment", 2, .6, [
		R(.08, .1, .12, .4),
		R(1.8, .1, .12, .4),
		P("M.14 .3H1.86"),
		...Array.from({ length: 6 }, (_, i) => P(`M${.35 + i * .25} .3l-.08 .14h.16Z`))
	], "Palco e bastidores"),
	backstageTrunk: add("Baú de bastidores reforçado", "entertainment", 1.4, .75, [
		...base(1.4, .75),
		P("M.25 .03V.72M1.15 .03V.72M.6 .1H.8"),
		R(.58, .58, .24, .09, .02)
	], "Palco e bastidores"),
	marketShelfIsland: add("Gôndola comercial · ilha de prateleiras", "market", 2.4, 1, [...base(2.4, 1), P("M.1 .5H2.3M.8 .1V.9M1.6 .1V.9")], "Exposição e estoque"),
	marketCheckout: add("Caixa de comércio · esteira e terminal", "market", 2.2, .9, [
		...base(2.2, .9),
		R(.12, .15, 1.1, .6, .04),
		P("M.25 .18V.72M1.08 .18V.72"),
		...panel(1.45, .14, .5, .35),
		R(1.4, .6, .58, .2, .02, "none")
	], "Bancas e atendimento"),
	marketProduceBins: add("Expositor de feira · caixas inclinadas vazias", "market", 2.4, 1, [R(.04, .04, 2.32, .92), ...Array.from({ length: 3 }, (_, i) => [R(.12 + i * .76, .14, .65, .7, .03, "none"), P(`M${.18 + i * .76} .7h.53`)]).flat()], "Exposição e estoque"),
	marketShutter: add("Porta de enrolar comercial · módulo recolhido", "market", 3, .4, [
		...base(3, .4),
		P("M.12 .13H2.88M.12 .26H2.88"),
		R(.05, .03, .15, .34),
		R(2.8, .03, .15, .34)
	], "Bancas e atendimento"),
	transitLoudspeaker: add("Alto-falante de estação · corneta e suporte", "transit", .5, .75, [
		R(.17, .02, .16, .15),
		P("M.22 .17V.32H.28V.17"),
		P("M.15 .32H.35L.47 .7H.03Z", "inherit"),
		P("M.06 .62H.44")
	], "Espera e serviços"),
	vendingMachine: add("Máquina de venda automática retro", "transit", 1.2, .85, [
		...base(1.2, .85),
		R(.12, .12, .7, .42, .03, "none"),
		P("M.35 .12V.54M.58 .12V.54"),
		R(.92, .12, .16, .18, .015),
		R(.15, .64, .65, .12, .02, "none"),
		C(1, .47, .04, "none")
	], "Espera e serviços"),
	crowdBarrier: add("Grade de contenção · pés e travessas", "transit", 2, .55, [
		R(.1, .05, .12, .45),
		R(1.78, .05, .12, .45),
		P("M.16 .21H1.84M.16 .34H1.84"),
		...Array.from({ length: 8 }, (_, i) => P(`M${.35 + i * .18} .21v.13`))
	], "Controle e embarque"),
	luggageRack: add("Bagageiro de estação · estrutura tubular", "transit", 1.8, .8, [...base(1.8, .8), ...Array.from({ length: 6 }, (_, i) => P(`M${.2 + i * .28} .12v.56`))], "Espera e serviços"),
	trafficCone: add("Cone de segurança · base quadrada", "floor-signage", .45, .45, [
		R(.02, .02, .41, .41, .04),
		C(.225, .225, .16),
		C(.225, .225, .07, "none")
	], "Barreiras móveis"),
	foldingCaution: add("Cavalete de sinalização dobrável", "floor-signage", .6, .45, [
		R(.05, .03, .5, .1),
		R(.05, .32, .5, .1),
		P("M.05 .08L.55 .37M.55 .08L.05 .37")
	], "Barreiras móveis"),
	kitchenPrepIsland: add("Ilha de preparo · tampo livre e cuba", "galley", 2.4, 1.2, [
		...base(2.4, 1.2),
		...sink(.2, .3, .55, .6),
		P("M1 .1V1.1")
	], "Distribuição e preparo"),
	kitchenGriddle: add("Chapa industrial · grelha e controles", "galley", 1.2, .9, [
		...base(1.2, .9),
		R(.1, .1, 1, .55, .025, "none"),
		...Array.from({ length: 7 }, (_, i) => P(`M${.18 + i * .14} .15v.45`)),
		...Array.from({ length: 4 }, (_, i) => C(.22 + i * .25, .76, .045, "none"))
	], "Cocção e conservação"),
	bakeryOven: add("Forno de padaria · gabinete duplo", "galley", 1.6, 1.2, [
		...base(1.6, 1.2),
		R(.14, .14, 1.32, .72, .04),
		P("M.2 .5H1.4M.3 .97H1.3"),
		C(1.35, 1.06, .04, "none")
	], "Cocção e conservação"),
	kitchenColdPrep: add("Bancada refrigerada de preparo", "galley", 2, .8, [
		...base(2, .8),
		...Array.from({ length: 4 }, (_, i) => R(.12 + i * .47, .12, .35, .24, .035, "none")),
		P("M.12 .5H1.88")
	], "Distribuição e preparo"),
	processVessel: add("Tanque de processo · vaso vertical com bombas", "engineering", 2.4, 2.4, [
		C(1.2, 1.2, 1.05),
		C(1.2, 1.2, .86, "none"),
		C(1.2, 1.2, .24),
		P("M.15 1.2H.02M2.25 1.2H2.38M1.2 .15V.02"),
		R(.15, 1.9, .45, .35, .04),
		P("M.6 2.07H.8")
	], "Fluidos e energia"),
	heavyMaintenanceBench: add("Bancada pesada · torno de bancada e painel técnico", "engineering", 2.8, 1, [
		...base(2.8, 1),
		P("M.12 .16H2.68"),
		R(.25, .36, .55, .4, .035),
		R(.16, .44, .74, .14, .02),
		P("M.55 .76V.9M.4 .9H.7"),
		...panel(1.9, .3, .55, .4)
	], "Máquinas e manutenção")
};
//#endregion
//#region src/blueprints/colony-assets.js
var colonyAssets = {
	...outpostMachinery,
	...outpostClinic,
	...outpostHospitality,
	...outpostEngineering,
	...outpostCrew,
	...outpostTransit,
	...outpostServices,
	...outpostMarket,
	...stageAssets,
	...hiveAssets,
	...marketDetailAssets,
	...hospitalityAssets,
	...miningAssets,
	...freightAssets,
	...crewDeckAssets,
	...shipSystemsAssets,
	...serviceDeckAssets,
	...containmentAssets,
	...utilityAssets,
	...settlementAssets,
	industrialRange: {
		name: "Fogão industrial com forno",
		w: 1.5,
		h: 1,
		category: "galley",
		shapes: [
			{
				tag: "rect",
				x: 4,
				y: 5,
				width: 92,
				height: 90,
				rx: 3
			},
			{
				tag: "rect",
				x: 9,
				y: 10,
				width: 82,
				height: 65,
				rx: 0
			},
			{
				tag: "ellipse",
				cx: 25,
				cy: 28,
				rx: 8,
				ry: 8
			},
			{
				tag: "ellipse",
				cx: 25,
				cy: 56,
				rx: 8,
				ry: 8
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 28,
				rx: 8,
				ry: 8
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 56,
				rx: 8,
				ry: 8
			},
			{
				tag: "ellipse",
				cx: 75,
				cy: 28,
				rx: 8,
				ry: 8
			},
			{
				tag: "ellipse",
				cx: 75,
				cy: 56,
				rx: 8,
				ry: 8
			},
			{
				tag: "path",
				d: "M12 83H88M25 90H75"
			}
		]
	},
	galleyFridge: {
		name: "Refrigerador industrial duplo",
		w: 1.4,
		h: .85,
		category: "galley",
		shapes: [
			{
				tag: "rect",
				x: 4,
				y: 4,
				width: 92,
				height: 92,
				rx: 3
			},
			{
				tag: "path",
				d: "M50 4V96M43 55V80M57 55V80M12 15H42M58 15H88"
			},
			{
				tag: "rect",
				x: 10,
				y: 8,
				width: 80,
				height: 8,
				rx: 0
			}
		]
	},
	servingCounter: {
		name: "Balcão de distribuição de refeições",
		w: 3,
		h: .9,
		category: "galley",
		shapes: [
			{
				tag: "rect",
				x: 2,
				y: 5,
				width: 96,
				height: 90,
				rx: 3
			},
			{
				tag: "rect",
				x: 5,
				y: 10,
				width: 90,
				height: 12,
				rx: 0
			},
			{
				tag: "rect",
				x: 8,
				y: 35,
				width: 17,
				height: 40,
				rx: 3
			},
			{
				tag: "rect",
				x: 30,
				y: 35,
				width: 17,
				height: 40,
				rx: 3
			},
			{
				tag: "rect",
				x: 52,
				y: 35,
				width: 17,
				height: 40,
				rx: 3
			},
			{
				tag: "rect",
				x: 74,
				y: 35,
				width: 17,
				height: 40,
				rx: 3
			},
			{
				tag: "path",
				d: "M5 87H95"
			}
		]
	},
	dishwasherLine: {
		name: "Lavadora industrial de louça",
		w: 2.4,
		h: .85,
		category: "galley",
		shapes: [
			{
				tag: "rect",
				x: 3,
				y: 5,
				width: 94,
				height: 90,
				rx: 0
			},
			{
				tag: "rect",
				x: 5,
				y: 15,
				width: 24,
				height: 65,
				rx: 0
			},
			{
				tag: "rect",
				x: 35,
				y: 10,
				width: 30,
				height: 80,
				rx: 4
			},
			{
				tag: "rect",
				x: 71,
				y: 15,
				width: 24,
				height: 65,
				rx: 0
			},
			{
				tag: "path",
				d: "M9 25V70M15 25V70M21 25V70M77 25V70M83 25V70M89 25V70M42 22H58"
			}
		]
	},
	coldRoomUnit: {
		name: "Módulo de câmara frigorífica",
		w: 3,
		h: 2.5,
		category: "galley",
		shapes: [
			{
				tag: "rect",
				x: 3,
				y: 3,
				width: 94,
				height: 94,
				rx: 0
			},
			{
				tag: "rect",
				x: 8,
				y: 8,
				width: 84,
				height: 84,
				rx: 0
			},
			{
				tag: "rect",
				x: 12,
				y: 12,
				width: 18,
				height: 66,
				rx: 0
			},
			{
				tag: "rect",
				x: 70,
				y: 12,
				width: 18,
				height: 66,
				rx: 0
			},
			{
				tag: "path",
				d: "M37 97V86H63V97M50 86V97M12 32H30M12 54H30M70 32H88M70 54H88"
			}
		]
	},
	foodDispenser: {
		name: "Distribuidor automático de refeições",
		w: 1.2,
		h: .75,
		category: "galley",
		shapes: [
			{
				tag: "rect",
				x: 5,
				y: 5,
				width: 90,
				height: 90,
				rx: 4
			},
			{
				tag: "rect",
				x: 12,
				y: 12,
				width: 76,
				height: 42,
				rx: 0
			},
			{
				tag: "rect",
				x: 18,
				y: 66,
				width: 64,
				height: 20,
				rx: 3
			},
			{
				tag: "path",
				d: "M20 22H65M20 33H65M74 22V42M40 74H60"
			}
		]
	},
	marketStall: {
		name: "Barraca modular de feira",
		w: 3,
		h: 2.5,
		category: "market",
		shapes: [
			{
				tag: "path",
				d: "M3 65V3H97V65",
				fill: "none"
			},
			{
				tag: "rect",
				x: 8,
				y: 62,
				width: 84,
				height: 30,
				rx: 0
			},
			{
				tag: "rect",
				x: 10,
				y: 10,
				width: 26,
				height: 35,
				rx: 0
			},
			{
				tag: "rect",
				x: 64,
				y: 10,
				width: 26,
				height: 35,
				rx: 0
			},
			{
				tag: "rect",
				x: 8,
				y: 8,
				width: 4,
				height: 4,
				rx: 0
			},
			{
				tag: "rect",
				x: 8,
				y: 88,
				width: 4,
				height: 4,
				rx: 0
			},
			{
				tag: "rect",
				x: 88,
				y: 8,
				width: 4,
				height: 4,
				rx: 0
			},
			{
				tag: "rect",
				x: 88,
				y: 88,
				width: 4,
				height: 4,
				rx: 0
			},
			{
				tag: "path",
				d: "M8 67H92M14 75H32M40 75H58M66 75H84",
				fill: "none"
			}
		]
	},
	marketCounter: {
		name: "Balcão de comércio modular",
		w: 2,
		h: .8,
		category: "market",
		shapes: [
			{
				tag: "rect",
				x: 3,
				y: 6,
				width: 94,
				height: 88,
				rx: 3
			},
			{
				tag: "rect",
				x: 8,
				y: 12,
				width: 60,
				height: 72,
				rx: 0
			},
			{
				tag: "rect",
				x: 73,
				y: 15,
				width: 19,
				height: 28,
				rx: 0
			},
			{
				tag: "path",
				d: "M8 55H68M38 12V84M75 65H90M75 74H90"
			}
		]
	},
	refrigeratedDisplay: {
		name: "Expositor refrigerado de feira",
		w: 2.2,
		h: 1,
		category: "market",
		shapes: [
			{
				tag: "rect",
				x: 3,
				y: 5,
				width: 94,
				height: 90,
				rx: 5
			},
			{
				tag: "rect",
				x: 8,
				y: 10,
				width: 84,
				height: 65,
				rx: 4
			},
			{
				tag: "path",
				d: "M29 10V75M50 10V75M71 10V75M12 85H88M17 18L26 36M38 18L47 36M59 18L68 36M80 18L89 36"
			}
		]
	},
	tradeKiosk: {
		name: "Quiosque de atendimento",
		w: 2.5,
		h: 2.5,
		category: "market",
		shapes: [
			{
				tag: "path",
				d: "M5 5H95V95H65V60H35V95H5Z"
			},
			{
				tag: "rect",
				x: 12,
				y: 12,
				width: 76,
				height: 22,
				rx: 0
			},
			{
				tag: "rect",
				x: 12,
				y: 42,
				width: 16,
				height: 42,
				rx: 0
			},
			{
				tag: "rect",
				x: 72,
				y: 42,
				width: 16,
				height: 42,
				rx: 0
			},
			{
				tag: "rect",
				x: 39,
				y: 17,
				width: 23,
				height: 12,
				rx: 0
			}
		]
	},
	vehicleLift: {
		name: "Elevador automotivo de oficina",
		w: 3.5,
		h: 5,
		category: "workshop",
		shapes: [
			{
				tag: "rect",
				x: 5,
				y: 3,
				width: 16,
				height: 94,
				rx: 0
			},
			{
				tag: "rect",
				x: 79,
				y: 3,
				width: 16,
				height: 94,
				rx: 0
			},
			{
				tag: "rect",
				x: 3,
				y: 40,
				width: 20,
				height: 20,
				rx: 0
			},
			{
				tag: "rect",
				x: 77,
				y: 40,
				width: 20,
				height: 20,
				rx: 0
			},
			{
				tag: "path",
				d: "M21 25L43 39M21 75L43 61M79 25L57 39M79 75L57 61M8 12H18M82 12H92"
			}
		]
	},
	metalLathe: {
		name: "Torno mecânico industrial",
		w: 2.8,
		h: 1,
		category: "workshop",
		shapes: [
			{
				tag: "rect",
				x: 3,
				y: 6,
				width: 94,
				height: 88,
				rx: 0
			},
			{
				tag: "rect",
				x: 8,
				y: 15,
				width: 22,
				height: 70,
				rx: 0
			},
			{
				tag: "rect",
				x: 35,
				y: 28,
				width: 40,
				height: 44,
				rx: 0
			},
			{
				tag: "rect",
				x: 79,
				y: 20,
				width: 14,
				height: 60,
				rx: 0
			},
			{
				tag: "path",
				d: "M30 50H79M35 35H75M35 65H75M50 28V72"
			},
			{
				tag: "ellipse",
				cx: 19,
				cy: 50,
				rx: 7,
				ry: 7
			}
		]
	},
	drillPress: {
		name: "Furadeira de coluna",
		w: .9,
		h: 1.1,
		category: "workshop",
		shapes: [
			{
				tag: "rect",
				x: 12,
				y: 8,
				width: 76,
				height: 85,
				rx: 8
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 22,
				rx: 12,
				ry: 12
			},
			{
				tag: "rect",
				x: 22,
				y: 42,
				width: 56,
				height: 40,
				rx: 0
			},
			{
				tag: "path",
				d: "M50 22V60M30 51H70M30 63H70M70 22H90M90 16V28"
			}
		]
	},
	weldingStation: {
		name: "Estação de solda e bancada",
		w: 2.4,
		h: 1.2,
		category: "workshop",
		shapes: [
			{
				tag: "rect",
				x: 4,
				y: 6,
				width: 62,
				height: 88,
				rx: 0
			},
			{
				tag: "ellipse",
				cx: 20,
				cy: 24,
				rx: 2,
				ry: 2
			},
			{
				tag: "ellipse",
				cx: 20,
				cy: 48,
				rx: 2,
				ry: 2
			},
			{
				tag: "ellipse",
				cx: 20,
				cy: 72,
				rx: 2,
				ry: 2
			},
			{
				tag: "ellipse",
				cx: 38,
				cy: 24,
				rx: 2,
				ry: 2
			},
			{
				tag: "ellipse",
				cx: 38,
				cy: 48,
				rx: 2,
				ry: 2
			},
			{
				tag: "ellipse",
				cx: 38,
				cy: 72,
				rx: 2,
				ry: 2
			},
			{
				tag: "ellipse",
				cx: 56,
				cy: 24,
				rx: 2,
				ry: 2
			},
			{
				tag: "ellipse",
				cx: 56,
				cy: 48,
				rx: 2,
				ry: 2
			},
			{
				tag: "ellipse",
				cx: 56,
				cy: 72,
				rx: 2,
				ry: 2
			},
			{
				tag: "rect",
				x: 73,
				y: 8,
				width: 23,
				height: 48,
				rx: 3
			},
			{
				tag: "ellipse",
				cx: 84,
				cy: 77,
				rx: 10,
				ry: 17
			},
			{
				tag: "path",
				d: "M84 56C65 70 75 88 66 88"
			}
		]
	},
	stationBenchRow: {
		name: "Fileira de assentos de estação",
		w: 3,
		h: .75,
		category: "transit",
		shapes: [
			{
				tag: "path",
				d: "M3 15H97M8 85H92"
			},
			{
				tag: "rect",
				x: 5,
				y: 22,
				width: 18,
				height: 57,
				rx: 4
			},
			{
				tag: "rect",
				x: 29,
				y: 22,
				width: 18,
				height: 57,
				rx: 4
			},
			{
				tag: "rect",
				x: 53,
				y: 22,
				width: 18,
				height: 57,
				rx: 4
			},
			{
				tag: "rect",
				x: 77,
				y: 22,
				width: 18,
				height: 57,
				rx: 4
			},
			{
				tag: "path",
				d: "M14 79V94M86 79V94"
			}
		]
	},
	ticketMachine: {
		name: "Máquina de bilhetes CRT",
		w: .8,
		h: .7,
		category: "transit",
		shapes: [
			{
				tag: "rect",
				x: 5,
				y: 5,
				width: 90,
				height: 90,
				rx: 4
			},
			{
				tag: "rect",
				x: 15,
				y: 12,
				width: 70,
				height: 38,
				rx: 3
			},
			{
				tag: "rect",
				x: 20,
				y: 60,
				width: 45,
				height: 13,
				rx: 0
			},
			{
				tag: "path",
				d: "M20 84H80M75 60V75M26 18H74"
			}
		]
	},
	ticketBarrier: {
		name: "Catraca de estação",
		w: 1.2,
		h: 1.5,
		category: "transit",
		shapes: [
			{
				tag: "rect",
				x: 4,
				y: 6,
				width: 24,
				height: 88,
				rx: 4
			},
			{
				tag: "rect",
				x: 72,
				y: 6,
				width: 24,
				height: 88,
				rx: 4
			},
			{
				tag: "ellipse",
				cx: 16,
				cy: 20,
				rx: 4,
				ry: 4
			},
			{
				tag: "path",
				d: "M28 42H50L72 58M28 58L50 42H72"
			}
		]
	},
	railSegment: {
		name: "Trecho de trilho modular",
		w: 2,
		h: 4,
		category: "transit",
		shapes: [
			{
				tag: "rect",
				x: 4,
				y: 8,
				width: 92,
				height: 5,
				rx: 0
			},
			{
				tag: "rect",
				x: 4,
				y: 24,
				width: 92,
				height: 5,
				rx: 0
			},
			{
				tag: "rect",
				x: 4,
				y: 40,
				width: 92,
				height: 5,
				rx: 0
			},
			{
				tag: "rect",
				x: 4,
				y: 56,
				width: 92,
				height: 5,
				rx: 0
			},
			{
				tag: "rect",
				x: 4,
				y: 72,
				width: 92,
				height: 5,
				rx: 0
			},
			{
				tag: "rect",
				x: 4,
				y: 88,
				width: 92,
				height: 5,
				rx: 0
			},
			{
				tag: "path",
				d: "M25 0V100M30 0V100M70 0V100M75 0V100"
			}
		]
	},
	railStop: {
		name: "Batente de fim de linha",
		w: 2.2,
		h: 1.3,
		category: "transit",
		shapes: [
			{
				tag: "path",
				d: "M23 5V95M77 5V95M23 90L36 35M77 90L64 35"
			},
			{
				tag: "rect",
				x: 5,
				y: 15,
				width: 90,
				height: 22,
				rx: 0
			},
			{
				tag: "rect",
				x: 10,
				y: 18,
				width: 20,
				height: 16,
				rx: 0
			},
			{
				tag: "rect",
				x: 70,
				y: 18,
				width: 20,
				height: 16,
				rx: 0
			}
		]
	},
	billboardFrame: {
		name: "Outdoor com estrutura de apoio",
		w: 4,
		h: .9,
		category: "exterior",
		shapes: [
			{
				tag: "rect",
				x: 3,
				y: 8,
				width: 94,
				height: 28,
				rx: 0
			},
			{
				tag: "rect",
				x: 8,
				y: 12,
				width: 84,
				height: 20,
				rx: 0
			},
			{
				tag: "rect",
				x: 18,
				y: 36,
				width: 8,
				height: 55,
				rx: 0
			},
			{
				tag: "rect",
				x: 74,
				y: 36,
				width: 8,
				height: 55,
				rx: 0
			},
			{
				tag: "path",
				d: "M10 91H34M66 91H90M26 85L74 40M74 85L26 40"
			}
		]
	},
	neonSign: {
		name: "Letreiro de neon horizontal",
		w: 2,
		h: .4,
		category: "exterior",
		shapes: [{
			tag: "rect",
			x: 3,
			y: 10,
			width: 94,
			height: 80,
			rx: 6
		}, {
			tag: "path",
			d: "M12 62V30H25V62H38V30H51V62H64V30H77V62H88M12 72H88M12 22H88"
		}]
	},
	neonTotem: {
		name: "Totem de neon e publicidade",
		w: .9,
		h: .9,
		category: "exterior",
		shapes: [
			{
				tag: "rect",
				x: 10,
				y: 10,
				width: 80,
				height: 80,
				rx: 12
			},
			{
				tag: "rect",
				x: 20,
				y: 20,
				width: 60,
				height: 60,
				rx: 8
			},
			{
				tag: "path",
				d: "M30 60V34H43V60H56V34H70M30 70H70"
			},
			{
				tag: "rect",
				x: 3,
				y: 38,
				width: 7,
				height: 24,
				rx: 0
			},
			{
				tag: "rect",
				x: 90,
				y: 38,
				width: 7,
				height: 24,
				rx: 0
			}
		]
	},
	busShelter: {
		name: "Abrigo de parada",
		w: 4,
		h: 1.6,
		category: "exterior",
		shapes: [
			{
				tag: "rect",
				x: 3,
				y: 3,
				width: 94,
				height: 94,
				rx: 4
			},
			{
				tag: "path",
				d: "M8 8H92V92M8 8V92"
			},
			{
				tag: "rect",
				x: 14,
				y: 20,
				width: 72,
				height: 25,
				rx: 3
			},
			{
				tag: "rect",
				x: 12,
				y: 70,
				width: 5,
				height: 22,
				rx: 0
			},
			{
				tag: "rect",
				x: 83,
				y: 70,
				width: 5,
				height: 22,
				rx: 0
			}
		]
	},
	wasteStation: {
		name: "Estação de resíduos segregados",
		w: 2.4,
		h: 1,
		category: "exterior",
		shapes: [
			{
				tag: "rect",
				x: 3,
				y: 6,
				width: 94,
				height: 88,
				rx: 0
			},
			{
				tag: "rect",
				x: 7,
				y: 12,
				width: 26,
				height: 76,
				rx: 5
			},
			{
				tag: "rect",
				x: 37,
				y: 12,
				width: 26,
				height: 76,
				rx: 5
			},
			{
				tag: "rect",
				x: 67,
				y: 12,
				width: 26,
				height: 76,
				rx: 5
			},
			{
				tag: "rect",
				x: 13,
				y: 22,
				width: 14,
				height: 12,
				rx: 3
			},
			{
				tag: "rect",
				x: 43,
				y: 22,
				width: 14,
				height: 12,
				rx: 3
			},
			{
				tag: "rect",
				x: 73,
				y: 22,
				width: 14,
				height: 12,
				rx: 3
			},
			{
				tag: "path",
				d: "M7 70H33M37 70H63M67 70H93"
			}
		]
	},
	baggageXray: {
		name: "Raio X de bagagens com esteira",
		w: 3.5,
		h: 1.2,
		category: "security",
		shapes: [
			{
				tag: "rect",
				x: 3,
				y: 20,
				width: 94,
				height: 60,
				rx: 0
			},
			{
				tag: "rect",
				x: 32,
				y: 5,
				width: 36,
				height: 90,
				rx: 5
			},
			{
				tag: "rect",
				x: 38,
				y: 15,
				width: 24,
				height: 70,
				rx: 0
			},
			{
				tag: "path",
				d: "M8 24V76"
			},
			{
				tag: "path",
				d: "M14 24V76"
			},
			{
				tag: "path",
				d: "M20 24V76"
			},
			{
				tag: "path",
				d: "M26 24V76"
			},
			{
				tag: "path",
				d: "M74 24V76"
			},
			{
				tag: "path",
				d: "M80 24V76"
			},
			{
				tag: "path",
				d: "M86 24V76"
			},
			{
				tag: "path",
				d: "M92 24V76"
			},
			{
				tag: "rect",
				x: 70,
				y: 5,
				width: 15,
				height: 10,
				rx: 0
			}
		]
	},
	bodyScannerGate: {
		name: "Portal de inspeção corporal",
		w: 1.2,
		h: 1,
		category: "security",
		shapes: [
			{
				tag: "rect",
				x: 4,
				y: 5,
				width: 23,
				height: 90,
				rx: 4
			},
			{
				tag: "rect",
				x: 73,
				y: 5,
				width: 23,
				height: 90,
				rx: 4
			},
			{
				tag: "path",
				d: "M27 5H73M27 95H73M15 20V80M85 20V80"
			},
			{
				tag: "ellipse",
				cx: 15,
				cy: 15,
				rx: 3,
				ry: 3
			}
		]
	},
	securityBooth: {
		name: "Guarita de controle",
		w: 2.2,
		h: 2.2,
		category: "security",
		shapes: [
			{
				tag: "path",
				d: "M5 5H95V95H65M35 95H5Z"
			},
			{
				tag: "rect",
				x: 12,
				y: 12,
				width: 76,
				height: 20,
				rx: 0
			},
			{
				tag: "rect",
				x: 15,
				y: 45,
				width: 28,
				height: 20,
				rx: 0
			},
			{
				tag: "ellipse",
				cx: 30,
				cy: 76,
				rx: 10,
				ry: 10
			},
			{
				tag: "path",
				d: "M35 95V70M65 95H85"
			}
		]
	},
	medicalXray: {
		name: "Mesa de radiografia com braço",
		w: 2,
		h: 3,
		category: "medical",
		shapes: [
			{
				tag: "rect",
				x: 31,
				y: 20,
				width: 38,
				height: 74,
				rx: 8
			},
			{
				tag: "rect",
				x: 36,
				y: 25,
				width: 28,
				height: 18,
				rx: 5
			},
			{
				tag: "rect",
				x: 7,
				y: 5,
				width: 20,
				height: 30,
				rx: 0
			},
			{
				tag: "path",
				d: "M17 35V58H48M17 58V88"
			},
			{
				tag: "rect",
				x: 40,
				y: 48,
				width: 24,
				height: 15,
				rx: 3
			}
		]
	},
	diagnosticScanner: {
		name: "Scanner médico de túnel",
		w: 2.2,
		h: 3.2,
		category: "medical",
		shapes: [
			{
				tag: "rect",
				x: 8,
				y: 4,
				width: 84,
				height: 45,
				rx: 14
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 26,
				rx: 31,
				ry: 15
			},
			{
				tag: "rect",
				x: 34,
				y: 22,
				width: 32,
				height: 73,
				rx: 8
			},
			{
				tag: "rect",
				x: 39,
				y: 55,
				width: 22,
				height: 28,
				rx: 4
			},
			{
				tag: "path",
				d: "M14 13H23M77 13H86"
			}
		]
	},
	deconPod: {
		name: "Cabine de descontaminação",
		w: 1.5,
		h: 2,
		category: "medical",
		shapes: [
			{
				tag: "rect",
				x: 8,
				y: 4,
				width: 84,
				height: 92,
				rx: 10
			},
			{
				tag: "rect",
				x: 18,
				y: 12,
				width: 64,
				height: 76,
				rx: 8
			},
			{
				tag: "path",
				d: "M35 4H65M35 96H65M8 28H18M8 50H18M8 72H18M82 28H92M82 50H92M82 72H92"
			}
		]
	},
	fumeHood: {
		name: "Capela de exaustão de laboratório",
		w: 1.8,
		h: .9,
		category: "laboratory",
		shapes: [
			{
				tag: "rect",
				x: 3,
				y: 5,
				width: 94,
				height: 90,
				rx: 0
			},
			{
				tag: "rect",
				x: 10,
				y: 12,
				width: 80,
				height: 55,
				rx: 0
			},
			{
				tag: "rect",
				x: 10,
				y: 74,
				width: 80,
				height: 14,
				rx: 0
			},
			{
				tag: "path",
				d: "M20 20V58M30 20V58M40 20V58M50 20V58M60 20V58M70 20V58M80 20V58"
			}
		]
	},
	bioreactorBank: {
		name: "Banco de biorreatores",
		w: 2,
		h: 1.2,
		category: "laboratory",
		shapes: [
			{
				tag: "rect",
				x: 3,
				y: 5,
				width: 94,
				height: 90,
				rx: 0
			},
			{
				tag: "ellipse",
				cx: 23,
				cy: 48,
				rx: 18,
				ry: 32
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 48,
				rx: 18,
				ry: 32
			},
			{
				tag: "ellipse",
				cx: 77,
				cy: 48,
				rx: 18,
				ry: 32
			},
			{
				tag: "path",
				d: "M10 88H90M23 80V88M50 80V88M77 80V88"
			},
			{
				tag: "ellipse",
				cx: 23,
				cy: 48,
				rx: 7,
				ry: 12
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 48,
				rx: 7,
				ry: 12
			},
			{
				tag: "ellipse",
				cx: 77,
				cy: 48,
				rx: 7,
				ry: 12
			}
		]
	},
	bunkPod: {
		name: "Beliche com divisórias",
		w: 1.2,
		h: 2.4,
		category: "quarters",
		shapes: [
			{
				tag: "rect",
				x: 5,
				y: 3,
				width: 90,
				height: 94,
				rx: 0
			},
			{
				tag: "rect",
				x: 12,
				y: 8,
				width: 76,
				height: 80,
				rx: 5
			},
			{
				tag: "rect",
				x: 20,
				y: 14,
				width: 60,
				height: 19,
				rx: 4
			},
			{
				tag: "path",
				d: "M12 40H88M12 77H88M5 3L18 12M95 97L82 88M88 45H95M88 57H95M88 69H95"
			}
		]
	},
	recreationTable: {
		name: "Mesa de jogos recreativa",
		w: 2.2,
		h: 1.2,
		category: "quarters",
		shapes: [
			{
				tag: "rect",
				x: 4,
				y: 5,
				width: 92,
				height: 90,
				rx: 12
			},
			{
				tag: "rect",
				x: 12,
				y: 15,
				width: 76,
				height: 70,
				rx: 10
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 50,
				rx: 19,
				ry: 27
			},
			{
				tag: "path",
				d: "M50 23V77M31 50H69"
			},
			{
				tag: "ellipse",
				cx: 20,
				cy: 25,
				rx: 3,
				ry: 3
			},
			{
				tag: "ellipse",
				cx: 20,
				cy: 75,
				rx: 3,
				ry: 3
			},
			{
				tag: "ellipse",
				cx: 80,
				cy: 25,
				rx: 3,
				ry: 3
			},
			{
				tag: "ellipse",
				cx: 80,
				cy: 75,
				rx: 3,
				ry: 3
			}
		]
	},
	washTrough: {
		name: "Lavatório coletivo",
		w: 2.4,
		h: .6,
		category: "sanitary",
		shapes: [
			{
				tag: "rect",
				x: 3,
				y: 7,
				width: 94,
				height: 86,
				rx: 4
			},
			{
				tag: "rect",
				x: 9,
				y: 25,
				width: 82,
				height: 58,
				rx: 8
			},
			{
				tag: "path",
				d: "M23 12V40"
			},
			{
				tag: "path",
				d: "M50 12V40"
			},
			{
				tag: "path",
				d: "M77 12V40"
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 66,
				rx: 3,
				ry: 3
			}
		]
	},
	laundryBank: {
		name: "Conjunto de lavanderia",
		w: 2.2,
		h: .9,
		category: "sanitary",
		shapes: [
			{
				tag: "rect",
				x: 3,
				y: 5,
				width: 94,
				height: 90,
				rx: 0
			},
			{
				tag: "rect",
				x: 7,
				y: 10,
				width: 26,
				height: 80,
				rx: 3
			},
			{
				tag: "rect",
				x: 37,
				y: 10,
				width: 26,
				height: 80,
				rx: 3
			},
			{
				tag: "rect",
				x: 67,
				y: 10,
				width: 26,
				height: 80,
				rx: 3
			},
			{
				tag: "ellipse",
				cx: 20,
				cy: 52,
				rx: 10,
				ry: 25
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 52,
				rx: 10,
				ry: 25
			},
			{
				tag: "ellipse",
				cx: 80,
				cy: 52,
				rx: 10,
				ry: 25
			},
			{
				tag: "path",
				d: "M10 18H30M40 18H60M70 18H90"
			}
		]
	},
	palletJack: {
		name: "Transpaleteira manual",
		w: .7,
		h: 1.6,
		category: "cargo",
		shapes: [
			{
				tag: "path",
				d: "M12 94V35H88V94H72V50H28V94Z"
			},
			{
				tag: "rect",
				x: 30,
				y: 20,
				width: 40,
				height: 24,
				rx: 4
			},
			{
				tag: "path",
				d: "M50 20V5M32 5H68"
			},
			{
				tag: "ellipse",
				cx: 25,
				cy: 82,
				rx: 5,
				ry: 5
			},
			{
				tag: "ellipse",
				cx: 75,
				cy: 82,
				rx: 5,
				ry: 5
			}
		]
	},
	cargoScale: {
		name: "Balança de carga industrial",
		w: 2,
		h: 2,
		category: "cargo",
		shapes: [
			{
				tag: "rect",
				x: 5,
				y: 5,
				width: 90,
				height: 90,
				rx: 0
			},
			{
				tag: "rect",
				x: 12,
				y: 12,
				width: 76,
				height: 76,
				rx: 0
			},
			{
				tag: "path",
				d: "M12 12L88 88M88 12L12 88"
			},
			{
				tag: "rect",
				x: 38,
				y: 2,
				width: 24,
				height: 12,
				rx: 0
			}
		]
	},
	navigationTable: {
		name: "Mesa de navegação tática",
		w: 2.4,
		h: 1.6,
		category: "command",
		shapes: [
			{
				tag: "path",
				d: "M18 5H82L95 20V80L82 95H18L5 80V20Z"
			},
			{
				tag: "rect",
				x: 18,
				y: 18,
				width: 64,
				height: 64,
				rx: 4
			},
			{
				tag: "path",
				d: "M50 18V82M18 50H82"
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 50,
				rx: 22,
				ry: 22
			},
			{
				tag: "rect",
				x: 30,
				y: 87,
				width: 40,
				height: 5,
				rx: 0
			}
		]
	},
	commsRack: {
		name: "Rack de comunicações analógico",
		w: 1.5,
		h: .8,
		category: "command",
		shapes: [
			{
				tag: "rect",
				x: 4,
				y: 5,
				width: 92,
				height: 90,
				rx: 0
			},
			{
				tag: "rect",
				x: 10,
				y: 12,
				width: 80,
				height: 22,
				rx: 0
			},
			{
				tag: "rect",
				x: 10,
				y: 40,
				width: 80,
				height: 22,
				rx: 0
			},
			{
				tag: "rect",
				x: 10,
				y: 68,
				width: 80,
				height: 20,
				rx: 0
			},
			{
				tag: "ellipse",
				cx: 24,
				cy: 23,
				rx: 6,
				ry: 6
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 23,
				rx: 6,
				ry: 6
			},
			{
				tag: "ellipse",
				cx: 76,
				cy: 23,
				rx: 6,
				ry: 6
			},
			{
				tag: "path",
				d: "M18 47H62M18 55H62M18 77H82"
			},
			{
				tag: "ellipse",
				cx: 76,
				cy: 51,
				rx: 5,
				ry: 5
			}
		]
	},
	barCounterStraight: {
		name: "Balcão de bar modular",
		w: 2.4,
		h: .8,
		category: "bar",
		shapes: [
			{
				tag: "rect",
				x: 3,
				y: 5,
				width: 94,
				height: 90,
				rx: 4
			},
			{
				tag: "rect",
				x: 7,
				y: 10,
				width: 86,
				height: 18,
				rx: 0
			},
			{
				tag: "path",
				d: "M7 70H93M18 70V92M82 70V92"
			},
			{
				tag: "rect",
				x: 12,
				y: 37,
				width: 25,
				height: 24,
				rx: 0
			},
			{
				tag: "ellipse",
				cx: 70,
				cy: 48,
				rx: 12,
				ry: 18
			}
		]
	},
	barCounterCorner: {
		name: "Balcão de bar em L",
		w: 2.4,
		h: 2.4,
		category: "bar",
		shapes: [
			{
				tag: "path",
				d: "M5 5H95V35H35V95H5ZM10 10H90M10 10V90M30 30H90M30 30V90"
			},
			{
				tag: "rect",
				x: 48,
				y: 12,
				width: 25,
				height: 15,
				rx: 0
			},
			{
				tag: "ellipse",
				cx: 19,
				cy: 64,
				rx: 7,
				ry: 12
			}
		]
	},
	backBarCabinet: {
		name: "Móvel de retaguarda do bar",
		w: 2.4,
		h: .55,
		category: "bar",
		shapes: [
			{
				tag: "rect",
				x: 3,
				y: 6,
				width: 94,
				height: 88,
				rx: 0
			},
			{
				tag: "rect",
				x: 8,
				y: 13,
				width: 84,
				height: 65,
				rx: 0
			},
			{
				tag: "path",
				d: "M29 13V78M50 13V78M71 13V78M8 45H92M12 86H88"
			}
		]
	},
	barStool: {
		name: "Banqueta de bar",
		w: .5,
		h: .5,
		category: "bar",
		shapes: [
			{
				tag: "ellipse",
				cx: 50,
				cy: 50,
				rx: 42,
				ry: 42
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 50,
				rx: 34,
				ry: 34
			},
			{
				tag: "path",
				d: "M24 24L34 34M76 24L66 34M24 76L34 66M76 76L66 66"
			}
		]
	},
	drinkDispenserBank: {
		name: "Estação de bebidas de bar",
		w: 1.5,
		h: .7,
		category: "bar",
		shapes: [
			{
				tag: "rect",
				x: 4,
				y: 5,
				width: 92,
				height: 90,
				rx: 4
			},
			{
				tag: "rect",
				x: 10,
				y: 63,
				width: 80,
				height: 25,
				rx: 0
			},
			{
				tag: "ellipse",
				cx: 25,
				cy: 32,
				rx: 14,
				ry: 22
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 32,
				rx: 14,
				ry: 22
			},
			{
				tag: "ellipse",
				cx: 75,
				cy: 32,
				rx: 14,
				ry: 22
			},
			{
				tag: "path",
				d: "M25 54V72M50 54V72M75 54V72M15 80H85"
			}
		]
	},
	billiardTable: {
		name: "Mesa de bilhar",
		w: 2.6,
		h: 1.5,
		category: "bar",
		shapes: [
			{
				tag: "rect",
				x: 3,
				y: 5,
				width: 94,
				height: 90,
				rx: 7
			},
			{
				tag: "rect",
				x: 10,
				y: 14,
				width: 80,
				height: 72,
				rx: 4
			},
			{
				tag: "ellipse",
				cx: 12,
				cy: 16,
				rx: 3,
				ry: 3
			},
			{
				tag: "ellipse",
				cx: 12,
				cy: 50,
				rx: 3,
				ry: 3
			},
			{
				tag: "ellipse",
				cx: 12,
				cy: 84,
				rx: 3,
				ry: 3
			},
			{
				tag: "ellipse",
				cx: 88,
				cy: 16,
				rx: 3,
				ry: 3
			},
			{
				tag: "ellipse",
				cx: 88,
				cy: 50,
				rx: 3,
				ry: 3
			},
			{
				tag: "ellipse",
				cx: 88,
				cy: 84,
				rx: 3,
				ry: 3
			},
			{
				tag: "path",
				d: "M30 18V82M70 18V82"
			}
		]
	},
	rouletteTable: {
		name: "Mesa de roleta",
		w: 2.8,
		h: 1.5,
		category: "casino",
		shapes: [
			{
				tag: "rect",
				x: 3,
				y: 5,
				width: 94,
				height: 90,
				rx: 12
			},
			{
				tag: "ellipse",
				cx: 27,
				cy: 50,
				rx: 20,
				ry: 32
			},
			{
				tag: "ellipse",
				cx: 27,
				cy: 50,
				rx: 14,
				ry: 22
			},
			{
				tag: "ellipse",
				cx: 27,
				cy: 50,
				rx: 4,
				ry: 6
			},
			{
				tag: "rect",
				x: 54,
				y: 17,
				width: 35,
				height: 66,
				rx: 0
			},
			{
				tag: "path",
				d: "M54 39H89M54 61H89M66 17V83M78 17V83"
			}
		]
	},
	pokerTable: {
		name: "Mesa de pôquer",
		w: 2.4,
		h: 1.4,
		category: "casino",
		shapes: [
			{
				tag: "rect",
				x: 3,
				y: 6,
				width: 94,
				height: 88,
				rx: 30
			},
			{
				tag: "rect",
				x: 12,
				y: 18,
				width: 76,
				height: 64,
				rx: 24
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 50,
				rx: 10,
				ry: 16
			},
			{
				tag: "ellipse",
				cx: 24,
				cy: 14,
				rx: 3,
				ry: 3
			},
			{
				tag: "ellipse",
				cx: 24,
				cy: 86,
				rx: 3,
				ry: 3
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 14,
				rx: 3,
				ry: 3
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 86,
				rx: 3,
				ry: 3
			},
			{
				tag: "ellipse",
				cx: 76,
				cy: 14,
				rx: 3,
				ry: 3
			},
			{
				tag: "ellipse",
				cx: 76,
				cy: 86,
				rx: 3,
				ry: 3
			},
			{
				tag: "path",
				d: "M16 48H23M77 48H84"
			}
		]
	},
	blackjackTable: {
		name: "Mesa de blackjack",
		w: 2.2,
		h: 1.4,
		category: "casino",
		shapes: [
			{
				tag: "path",
				d: "M5 13H95V43Q95 95 50 95Q5 95 5 43ZM12 23H88V43Q88 84 50 84Q12 84 12 43Z"
			},
			{
				tag: "rect",
				x: 19,
				y: 40,
				width: 12,
				height: 16,
				rx: 2
			},
			{
				tag: "rect",
				x: 44,
				y: 40,
				width: 12,
				height: 16,
				rx: 2
			},
			{
				tag: "rect",
				x: 69,
				y: 40,
				width: 12,
				height: 16,
				rx: 2
			},
			{
				tag: "rect",
				x: 39,
				y: 20,
				width: 22,
				height: 10,
				rx: 0
			}
		]
	},
	slotMachineBank: {
		name: "Fileira de máquinas caça-níqueis",
		w: 2.4,
		h: .9,
		category: "casino",
		shapes: [
			{
				tag: "rect",
				x: 4,
				y: 5,
				width: 28,
				height: 90,
				rx: 4
			},
			{
				tag: "rect",
				x: 8,
				y: 12,
				width: 20,
				height: 40,
				rx: 2
			},
			{
				tag: "rect",
				x: 8,
				y: 63,
				width: 20,
				height: 18,
				rx: 0
			},
			{
				tag: "path",
				d: "M14 20V44M22 20V44"
			},
			{
				tag: "rect",
				x: 36,
				y: 5,
				width: 28,
				height: 90,
				rx: 4
			},
			{
				tag: "rect",
				x: 40,
				y: 12,
				width: 20,
				height: 40,
				rx: 2
			},
			{
				tag: "rect",
				x: 40,
				y: 63,
				width: 20,
				height: 18,
				rx: 0
			},
			{
				tag: "path",
				d: "M46 20V44M54 20V44"
			},
			{
				tag: "rect",
				x: 68,
				y: 5,
				width: 28,
				height: 90,
				rx: 4
			},
			{
				tag: "rect",
				x: 72,
				y: 12,
				width: 20,
				height: 40,
				rx: 2
			},
			{
				tag: "rect",
				x: 72,
				y: 63,
				width: 20,
				height: 18,
				rx: 0
			},
			{
				tag: "path",
				d: "M78 20V44M86 20V44"
			}
		]
	},
	performanceStage: {
		name: "Palco modular de apresentação",
		w: 4,
		h: 3,
		category: "entertainment",
		shapes: [
			{
				tag: "rect",
				x: 3,
				y: 3,
				width: 94,
				height: 94,
				rx: 0
			},
			{
				tag: "rect",
				x: 8,
				y: 8,
				width: 84,
				height: 84,
				rx: 0
			},
			{
				tag: "path",
				d: "M8 18H92M8 27H92M8 36H92M35 97V88H65V97"
			},
			{
				tag: "rect",
				x: 12,
				y: 70,
				width: 12,
				height: 16,
				rx: 0
			},
			{
				tag: "rect",
				x: 76,
				y: 70,
				width: 12,
				height: 16,
				rx: 0
			}
		]
	},
	dressingStation: {
		name: "Penteadeira de camarim",
		w: 1.4,
		h: .6,
		category: "entertainment",
		shapes: [
			{
				tag: "rect",
				x: 4,
				y: 5,
				width: 92,
				height: 90,
				rx: 3
			},
			{
				tag: "rect",
				x: 12,
				y: 10,
				width: 76,
				height: 18,
				rx: 0
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 64,
				rx: 22,
				ry: 25
			},
			{
				tag: "path",
				d: "M12 45H25M75 45H88M18 13V25M30 13V25M42 13V25M54 13V25M66 13V25M78 13V25"
			}
		]
	},
	privateBooth: {
		name: "Sofá reservado em U",
		w: 2.6,
		h: 2.4,
		category: "entertainment",
		shapes: [
			{
				tag: "path",
				d: "M5 5H95V95H73V30H27V95H5Z"
			},
			{
				tag: "path",
				d: "M12 12H88V88M12 12V88M27 30H73"
			},
			{
				tag: "rect",
				x: 37,
				y: 44,
				width: 26,
				height: 38,
				rx: 6
			}
		]
	},
	canopySuiteBed: {
		name: "Cama de suíte com dossel",
		w: 2.2,
		h: 2.5,
		category: "entertainment",
		shapes: [
			{
				tag: "rect",
				x: 5,
				y: 4,
				width: 90,
				height: 92,
				rx: 0
			},
			{
				tag: "rect",
				x: 14,
				y: 12,
				width: 72,
				height: 76,
				rx: 6
			},
			{
				tag: "rect",
				x: 19,
				y: 17,
				width: 28,
				height: 16,
				rx: 3
			},
			{
				tag: "rect",
				x: 53,
				y: 17,
				width: 28,
				height: 16,
				rx: 3
			},
			{
				tag: "path",
				d: "M14 41H86M14 77H86M5 4L14 12M95 4L86 12M5 96L14 88M95 96L86 88"
			}
		]
	},
	loungeChaise: {
		name: "Chaise longue de salão",
		w: .9,
		h: 2,
		category: "entertainment",
		shapes: [
			{
				tag: "rect",
				x: 7,
				y: 4,
				width: 86,
				height: 92,
				rx: 15
			},
			{
				tag: "rect",
				x: 15,
				y: 12,
				width: 70,
				height: 26,
				rx: 10
			},
			{
				tag: "rect",
				x: 15,
				y: 42,
				width: 70,
				height: 44,
				rx: 8
			},
			{
				tag: "path",
				d: "M7 38H15M85 38H93"
			}
		]
	},
	privacyScreen: {
		name: "Biombo articulado de privacidade",
		w: 2,
		h: .5,
		category: "entertainment",
		shapes: [
			{
				tag: "path",
				d: "M3 18L26 78L50 18L74 78L97 18M3 25L26 85L50 25L74 85L97 25"
			},
			{
				tag: "ellipse",
				cx: 3,
				cy: 21,
				rx: 2,
				ry: 5
			},
			{
				tag: "ellipse",
				cx: 26,
				cy: 81,
				rx: 2,
				ry: 5
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 21,
				rx: 2,
				ry: 5
			},
			{
				tag: "ellipse",
				cx: 74,
				cy: 81,
				rx: 2,
				ry: 5
			},
			{
				tag: "ellipse",
				cx: 97,
				cy: 21,
				rx: 2,
				ry: 5
			}
		]
	},
	retroJukebox: {
		name: "Jukebox analógica",
		w: 1,
		h: .65,
		category: "bar",
		shapes: [
			{
				tag: "rect",
				x: 5,
				y: 5,
				width: 90,
				height: 90,
				rx: 20
			},
			{
				tag: "rect",
				x: 14,
				y: 13,
				width: 72,
				height: 36,
				rx: 12
			},
			{
				tag: "rect",
				x: 18,
				y: 58,
				width: 64,
				height: 26,
				rx: 3
			},
			{
				tag: "path",
				d: "M23 63V79M33 63V79M43 63V79M53 63V79M63 63V79M73 63V79M25 25H75M25 35H75"
			}
		]
	},
	pinballMachine: {
		name: "Máquina de pinball",
		w: .8,
		h: 1.6,
		category: "entertainment",
		shapes: [
			{
				tag: "rect",
				x: 6,
				y: 4,
				width: 88,
				height: 92,
				rx: 3
			},
			{
				tag: "rect",
				x: 11,
				y: 9,
				width: 78,
				height: 16,
				rx: 0
			},
			{
				tag: "rect",
				x: 15,
				y: 30,
				width: 70,
				height: 59,
				rx: 0
			},
			{
				tag: "ellipse",
				cx: 35,
				cy: 47,
				rx: 7,
				ry: 7
			},
			{
				tag: "ellipse",
				cx: 65,
				cy: 47,
				rx: 7,
				ry: 7
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 63,
				rx: 7,
				ry: 7
			},
			{
				tag: "path",
				d: "M23 78L40 82M77 78L60 82M20 35V66M80 35V66"
			}
		]
	},
	arcadeTwin: {
		name: "Arcade duplo CRT",
		w: 1.6,
		h: .85,
		category: "entertainment",
		shapes: [
			{
				tag: "rect",
				x: 4,
				y: 5,
				width: 92,
				height: 90,
				rx: 4
			},
			{
				tag: "rect",
				x: 10,
				y: 12,
				width: 36,
				height: 43,
				rx: 4
			},
			{
				tag: "rect",
				x: 54,
				y: 12,
				width: 36,
				height: 43,
				rx: 4
			},
			{
				tag: "rect",
				x: 10,
				y: 64,
				width: 80,
				height: 23,
				rx: 0
			},
			{
				tag: "ellipse",
				cx: 22,
				cy: 74,
				rx: 4,
				ry: 4
			},
			{
				tag: "ellipse",
				cx: 62,
				cy: 74,
				rx: 4,
				ry: 4
			},
			{
				tag: "path",
				d: "M33 72H40M73 72H80M15 18H41M59 18H85"
			}
		]
	},
	foosballTable: {
		name: "Mesa de pebolim",
		w: 1.4,
		h: .85,
		category: "bar",
		shapes: [
			{
				tag: "rect",
				x: 8,
				y: 6,
				width: 84,
				height: 88,
				rx: 5
			},
			{
				tag: "rect",
				x: 17,
				y: 15,
				width: 66,
				height: 70,
				rx: 0
			},
			{
				tag: "path",
				d: "M17 50H83"
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 50,
				rx: 12,
				ry: 15
			},
			{
				tag: "path",
				d: "M2 26H98"
			},
			{
				tag: "path",
				d: "M2 42H98"
			},
			{
				tag: "path",
				d: "M2 58H98"
			},
			{
				tag: "path",
				d: "M2 74H98"
			},
			{
				tag: "rect",
				x: 28,
				y: 23,
				width: 4,
				height: 6,
				rx: 0
			},
			{
				tag: "rect",
				x: 48,
				y: 23,
				width: 4,
				height: 6,
				rx: 0
			},
			{
				tag: "rect",
				x: 68,
				y: 23,
				width: 4,
				height: 6,
				rx: 0
			},
			{
				tag: "rect",
				x: 28,
				y: 39,
				width: 4,
				height: 6,
				rx: 0
			},
			{
				tag: "rect",
				x: 48,
				y: 39,
				width: 4,
				height: 6,
				rx: 0
			},
			{
				tag: "rect",
				x: 68,
				y: 39,
				width: 4,
				height: 6,
				rx: 0
			},
			{
				tag: "rect",
				x: 28,
				y: 55,
				width: 4,
				height: 6,
				rx: 0
			},
			{
				tag: "rect",
				x: 48,
				y: 55,
				width: 4,
				height: 6,
				rx: 0
			},
			{
				tag: "rect",
				x: 68,
				y: 55,
				width: 4,
				height: 6,
				rx: 0
			},
			{
				tag: "rect",
				x: 28,
				y: 71,
				width: 4,
				height: 6,
				rx: 0
			},
			{
				tag: "rect",
				x: 48,
				y: 71,
				width: 4,
				height: 6,
				rx: 0
			},
			{
				tag: "rect",
				x: 68,
				y: 71,
				width: 4,
				height: 6,
				rx: 0
			}
		]
	},
	cocktailTableRound: {
		name: "Mesa alta de coquetel",
		w: .8,
		h: .8,
		category: "bar",
		shapes: [
			{
				tag: "ellipse",
				cx: 50,
				cy: 50,
				rx: 45,
				ry: 45
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 50,
				rx: 39,
				ry: 39
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 50,
				rx: 8,
				ry: 8
			},
			{
				tag: "path",
				d: "M22 22L40 40M78 22L60 40M22 78L40 60M78 78L60 60"
			}
		]
	},
	curvedLoungeSeat: {
		name: "Sofá curvo de salão",
		w: 2.8,
		h: 1.6,
		category: "entertainment",
		shapes: [
			{
				tag: "path",
				d: "M5 85V50Q5 5 50 5Q95 5 95 50V85H73V52Q73 28 50 28Q27 28 27 52V85Z",
				fill: "inherit"
			},
			{
				tag: "path",
				fill: "none",
				d: "M13 79V50Q13 14 50 14Q87 14 87 50V79M8 77V50Q8 9 50 9Q92 9 92 50V77",
				strokeWidth: .9
			},
			{
				tag: "path",
				fill: "none",
				d: "M15 80V53Q15 50 18 50H22Q25 50 25 53V80Q25 82 22 82H18Q15 82 15 80ZM85 80V53Q85 50 82 50H78Q75 50 75 53V80Q75 82 78 82H82Q85 82 85 80Z"
			},
			{
				tag: "path",
				fill: "none",
				d: "M14 46Q15 30 28 23L33 32Q27 36 25 47ZM30 22Q38 17 48 16V26Q40 26 35 31ZM52 16Q62 17 70 22L65 31Q60 26 52 26ZM72 23Q85 30 86 46L75 47Q73 36 67 32Z",
				strokeWidth: 1
			}
		]
	},
	casinoCashier: {
		name: "Balcão de caixa de cassino",
		w: 2.6,
		h: 1.2,
		category: "casino",
		shapes: [
			{
				tag: "rect",
				x: 4,
				y: 5,
				width: 92,
				height: 90,
				rx: 3
			},
			{
				tag: "rect",
				x: 10,
				y: 12,
				width: 80,
				height: 28,
				rx: 0
			},
			{
				tag: "rect",
				x: 12,
				y: 55,
				width: 28,
				height: 28,
				rx: 0
			},
			{
				tag: "rect",
				x: 60,
				y: 55,
				width: 28,
				height: 28,
				rx: 0
			},
			{
				tag: "path",
				d: "M10 23H90M30 12V40M70 12V40M42 95V73H58V95"
			}
		]
	},
	crapsTable: {
		name: "Mesa de dados de cassino",
		w: 3.2,
		h: 1.5,
		category: "casino",
		shapes: [
			{
				tag: "rect",
				x: 3,
				y: 5,
				width: 94,
				height: 90,
				rx: 14
			},
			{
				tag: "rect",
				x: 10,
				y: 15,
				width: 80,
				height: 70,
				rx: 10
			},
			{
				tag: "rect",
				x: 19,
				y: 28,
				width: 24,
				height: 44,
				rx: 0
			},
			{
				tag: "rect",
				x: 57,
				y: 28,
				width: 24,
				height: 44,
				rx: 0
			},
			{
				tag: "path",
				d: "M19 42H43M19 57H43M57 42H81M57 57H81M50 20V80M24 80H76"
			}
		]
	},
	djConsole: {
		name: "Cabine de DJ analógica",
		w: 2,
		h: .9,
		category: "entertainment",
		shapes: [
			{
				tag: "rect",
				x: 3,
				y: 5,
				width: 94,
				height: 90,
				rx: 4
			},
			{
				tag: "rect",
				x: 9,
				y: 12,
				width: 82,
				height: 75,
				rx: 0
			},
			{
				tag: "ellipse",
				cx: 27,
				cy: 43,
				rx: 15,
				ry: 23
			},
			{
				tag: "ellipse",
				cx: 73,
				cy: 43,
				rx: 15,
				ry: 23
			},
			{
				tag: "rect",
				x: 45,
				y: 20,
				width: 10,
				height: 52,
				rx: 0
			},
			{
				tag: "path",
				d: "M48 30H52M48 40H52M48 50H52M15 79H38M62 79H85"
			}
		]
	},
	speakerCabinetLarge: {
		name: "Caixa acústica de palco",
		w: .75,
		h: .6,
		category: "entertainment",
		shapes: [
			{
				tag: "path",
				d: "M12 5H88L96 95H4Z"
			},
			{
				tag: "rect",
				x: 19,
				y: 14,
				width: 62,
				height: 48,
				rx: 4
			},
			{
				tag: "path",
				d: "M15 76H85M15 84H85M24 18V56M35 18V56M46 18V56M57 18V56M68 18V56M79 18V56"
			},
			{
				tag: "rect",
				x: 34,
				y: 3,
				width: 32,
				height: 6,
				rx: 0
			}
		]
	},
	cloakroomCounter: {
		name: "Balcão de chapelaria",
		w: 2.8,
		h: .8,
		category: "entertainment",
		shapes: [
			{
				tag: "rect",
				x: 1,
				y: 3,
				width: 98,
				height: 94,
				rx: 2
			},
			{
				tag: "path",
				d: "M3 12H96M4 76H72M72 7V93M75 49H96M85 8V91"
			},
			...Array.from({ length: 7 }, (_, i) => {
				const x = 7 + i * 9;
				return {
					tag: "path",
					fill: "inherit",
					d: "M" + x + " 25l3-7 2 5 2-5 3 7-1 40h-8ZM" + (x + 5) + " 23v31"
				};
			}),
			...[14, 55].flatMap((y) => [76, 87].map((x) => ({
				tag: "rect",
				x,
				y,
				width: 7,
				height: 27,
				rx: 1
			})))
		]
	},
	dressingVanityDouble: {
		name: "Camarim duplo iluminado",
		w: 2.4,
		h: .65,
		category: "entertainment",
		shapes: [
			{
				tag: "rect",
				x: 3,
				y: 5,
				width: 94,
				height: 90,
				rx: 0
			},
			{
				tag: "rect",
				x: 8,
				y: 12,
				width: 38,
				height: 17,
				rx: 0
			},
			{
				tag: "rect",
				x: 54,
				y: 12,
				width: 38,
				height: 17,
				rx: 0
			},
			{
				tag: "ellipse",
				cx: 27,
				cy: 66,
				rx: 15,
				ry: 22
			},
			{
				tag: "ellipse",
				cx: 73,
				cy: 66,
				rx: 15,
				ry: 22
			},
			{
				tag: "ellipse",
				cx: 14,
				cy: 19,
				rx: 2,
				ry: 3
			},
			{
				tag: "ellipse",
				cx: 24,
				cy: 19,
				rx: 2,
				ry: 3
			},
			{
				tag: "ellipse",
				cx: 34,
				cy: 19,
				rx: 2,
				ry: 3
			},
			{
				tag: "ellipse",
				cx: 40,
				cy: 19,
				rx: 2,
				ry: 3
			},
			{
				tag: "ellipse",
				cx: 60,
				cy: 19,
				rx: 2,
				ry: 3
			},
			{
				tag: "ellipse",
				cx: 70,
				cy: 19,
				rx: 2,
				ry: 3
			},
			{
				tag: "ellipse",
				cx: 80,
				cy: 19,
				rx: 2,
				ry: 3
			},
			{
				tag: "ellipse",
				cx: 86,
				cy: 19,
				rx: 2,
				ry: 3
			},
			{
				tag: "path",
				d: "M50 5V95"
			}
		]
	},
	showerCubicle: {
		name: "Cabine de banho com antecâmara",
		w: 1.2,
		h: 1.8,
		category: "sanitary",
		shapes: [
			{
				tag: "path",
				d: "M5 5H95V95H65M35 95H5Z"
			},
			{
				tag: "rect",
				x: 12,
				y: 12,
				width: 76,
				height: 52,
				rx: 3
			},
			{
				tag: "path",
				d: "M12 64L88 12M12 12L88 64M40 5V18H60M35 95V73"
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 42,
				rx: 4,
				ry: 4
			},
			{
				tag: "rect",
				x: 12,
				y: 74,
				width: 18,
				height: 12,
				rx: 0
			}
		]
	},
	toiletCubicle: {
		name: "Cabine sanitária individual",
		w: 1.1,
		h: 1.6,
		category: "sanitary",
		shapes: [
			{
				tag: "path",
				d: "M5 5H95V95H65M35 95H5Z"
			},
			{
				tag: "rect",
				x: 32,
				y: 12,
				width: 36,
				height: 15,
				rx: 3
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 46,
				rx: 18,
				ry: 22
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 45,
				rx: 12,
				ry: 14
			},
			{
				tag: "path",
				d: "M35 95V72M65 95H89"
			}
		]
	},
	changingIsland: {
		name: "Ilha de vestiário com bancos",
		w: 2.4,
		h: 1.2,
		category: "sanitary",
		shapes: [
			{
				tag: "rect",
				x: 5,
				y: 8,
				width: 90,
				height: 84,
				rx: 0
			},
			{
				tag: "rect",
				x: 8,
				y: 35,
				width: 84,
				height: 30,
				rx: 0
			},
			{
				tag: "path",
				d: "M26 35V65M47 35V65M68 35V65M8 23H92M8 77H92M17 16V29M83 71V84"
			}
		]
	},
	dryingCabinet: {
		name: "Armário de secagem de trajes",
		w: 1.6,
		h: .8,
		category: "sanitary",
		shapes: [
			{
				tag: "rect",
				x: 4,
				y: 5,
				width: 92,
				height: 90,
				rx: 0
			},
			{
				tag: "rect",
				x: 10,
				y: 12,
				width: 80,
				height: 67,
				rx: 0
			},
			{
				tag: "path",
				d: "M50 12V79M43 46V66M57 46V66M14 85H86M16 20H43M57 20H84M16 27H43M57 27H84"
			}
		]
	},
	industrialWashTub: {
		name: "Tanque de higienização industrial",
		w: 1.8,
		h: .9,
		category: "sanitary",
		shapes: [
			{
				tag: "rect",
				x: 4,
				y: 5,
				width: 92,
				height: 90,
				rx: 3
			},
			{
				tag: "rect",
				x: 12,
				y: 22,
				width: 76,
				height: 63,
				rx: 8
			},
			{
				tag: "rect",
				x: 18,
				y: 29,
				width: 64,
				height: 48,
				rx: 6
			},
			{
				tag: "path",
				d: "M40 8V34M60 8V34M4 14H96"
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 64,
				rx: 4,
				ry: 4
			}
		]
	},
	hydrationStation: {
		name: "Estação de água e hidratação",
		w: 1,
		h: .7,
		category: "sanitary",
		shapes: [
			{
				tag: "rect",
				x: 5,
				y: 5,
				width: 90,
				height: 90,
				rx: 4
			},
			{
				tag: "rect",
				x: 12,
				y: 12,
				width: 76,
				height: 30,
				rx: 3
			},
			{
				tag: "rect",
				x: 15,
				y: 55,
				width: 70,
				height: 31,
				rx: 8
			},
			{
				tag: "path",
				d: "M30 42V64M70 42V64M22 20H78M22 30H78"
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 75,
				rx: 3,
				ry: 3
			}
		]
	},
	waterFilterSkid: {
		name: "Unidade de tratamento de água",
		w: 2.6,
		h: 1.5,
		category: "engineering",
		shapes: [
			{
				tag: "rect",
				x: 3,
				y: 5,
				width: 94,
				height: 90,
				rx: 0
			},
			{
				tag: "ellipse",
				cx: 23,
				cy: 43,
				rx: 16,
				ry: 30
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 43,
				rx: 16,
				ry: 30
			},
			{
				tag: "ellipse",
				cx: 77,
				cy: 43,
				rx: 16,
				ry: 30
			},
			{
				tag: "path",
				d: "M7 82H93M23 73V82M50 73V82M77 73V82M7 12H93"
			},
			{
				tag: "rect",
				x: 7,
				y: 78,
				width: 13,
				height: 12,
				rx: 0
			},
			{
				tag: "rect",
				x: 80,
				y: 78,
				width: 13,
				height: 12,
				rx: 0
			}
		]
	},
	powerTransformer: {
		name: "Transformador de subestação",
		w: 2.5,
		h: 1.8,
		category: "engineering",
		shapes: [
			{
				tag: "rect",
				x: 5,
				y: 5,
				width: 90,
				height: 90,
				rx: 0
			},
			{
				tag: "rect",
				x: 25,
				y: 16,
				width: 50,
				height: 68,
				rx: 4
			},
			{
				tag: "path",
				d: "M14 14V86"
			},
			{
				tag: "path",
				d: "M20 14V86"
			},
			{
				tag: "path",
				d: "M80 14V86"
			},
			{
				tag: "path",
				d: "M86 14V86"
			},
			{
				tag: "ellipse",
				cx: 35,
				cy: 28,
				rx: 5,
				ry: 7
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 28,
				rx: 5,
				ry: 7
			},
			{
				tag: "ellipse",
				cx: 65,
				cy: 28,
				rx: 5,
				ry: 7
			},
			{
				tag: "path",
				d: "M31 51H69M31 61H69M31 71H69"
			}
		]
	},
	airHandlingUnit: {
		name: "Central de climatização",
		w: 3,
		h: 1.5,
		category: "engineering",
		shapes: [
			{
				tag: "rect",
				x: 3,
				y: 5,
				width: 94,
				height: 90,
				rx: 0
			},
			{
				tag: "rect",
				x: 8,
				y: 12,
				width: 38,
				height: 76,
				rx: 0
			},
			{
				tag: "rect",
				x: 52,
				y: 12,
				width: 40,
				height: 76,
				rx: 0
			},
			{
				tag: "ellipse",
				cx: 27,
				cy: 50,
				rx: 16,
				ry: 28
			},
			{
				tag: "ellipse",
				cx: 27,
				cy: 50,
				rx: 5,
				ry: 9
			},
			{
				tag: "path",
				d: "M27 22V41M11 50H22M32 50H43M27 59V78M59 20V80M67 20V80M75 20V80M83 20V80"
			}
		]
	},
	cableReelStand: {
		name: "Suporte de bobina industrial",
		w: 1.8,
		h: 1.2,
		category: "engineering",
		shapes: [
			{
				tag: "rect",
				x: 5,
				y: 12,
				width: 90,
				height: 76,
				rx: 0
			},
			{
				tag: "rect",
				x: 17,
				y: 8,
				width: 12,
				height: 84,
				rx: 0
			},
			{
				tag: "rect",
				x: 71,
				y: 8,
				width: 12,
				height: 84,
				rx: 0
			},
			{
				tag: "rect",
				x: 29,
				y: 18,
				width: 42,
				height: 64,
				rx: 0
			},
			{
				tag: "path",
				d: "M35 18V82M43 18V82M51 18V82M59 18V82M67 18V82M5 50H17M83 50H95"
			}
		]
	},
	inspectionHatch: {
		name: "Tampa de inspeção retangular",
		w: .8,
		h: .8,
		category: "floor-technical",
		shapes: [
			{
				tag: "rect",
				x: 3,
				y: 3,
				width: 94,
				height: 94,
				rx: 3
			},
			{
				tag: "rect",
				x: 9,
				y: 9,
				width: 82,
				height: 82,
				rx: 2
			},
			{
				tag: "ellipse",
				cx: 10,
				cy: 10,
				rx: 2,
				ry: 2
			},
			{
				tag: "ellipse",
				cx: 90,
				cy: 10,
				rx: 2,
				ry: 2
			},
			{
				tag: "ellipse",
				cx: 10,
				cy: 90,
				rx: 2,
				ry: 2
			},
			{
				tag: "ellipse",
				cx: 90,
				cy: 90,
				rx: 2,
				ry: 2
			},
			{
				tag: "path",
				d: "M35 47H65V53H35Z"
			}
		]
	},
	roundAccessCover: {
		name: "Tampa de acesso circular",
		w: .9,
		h: .9,
		category: "floor-technical",
		shapes: [
			{
				tag: "ellipse",
				cx: 50,
				cy: 50,
				rx: 47,
				ry: 47
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 50,
				rx: 40,
				ry: 40
			},
			{
				tag: "path",
				d: "M35 47H65V53H35Z"
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 8,
				rx: 2,
				ry: 2
			},
			{
				tag: "ellipse",
				cx: 92,
				cy: 50,
				rx: 2,
				ry: 2
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 92,
				rx: 2,
				ry: 2
			},
			{
				tag: "ellipse",
				cx: 8,
				cy: 50,
				rx: 2,
				ry: 2
			}
		]
	},
	floorDrainPanel: {
		name: "Grelha de drenagem de piso",
		w: .6,
		h: 1.2,
		category: "floor-technical",
		shapes: [
			{
				tag: "rect",
				x: 3,
				y: 3,
				width: 94,
				height: 94,
				rx: 2
			},
			{
				tag: "rect",
				x: 9,
				y: 9,
				width: 82,
				height: 82,
				rx: 0
			},
			{
				tag: "path",
				d: "M15 16H85"
			},
			{
				tag: "path",
				d: "M15 24H85"
			},
			{
				tag: "path",
				d: "M15 32H85"
			},
			{
				tag: "path",
				d: "M15 40H85"
			},
			{
				tag: "path",
				d: "M15 48H85"
			},
			{
				tag: "path",
				d: "M15 56H85"
			},
			{
				tag: "path",
				d: "M15 64H85"
			},
			{
				tag: "path",
				d: "M15 72H85"
			},
			{
				tag: "path",
				d: "M15 80H85"
			}
		]
	},
	serviceFloorPanel: {
		name: "Painel de manutenção com dobradiças",
		w: 1.2,
		h: .8,
		category: "floor-technical",
		shapes: [
			{
				tag: "rect",
				x: 3,
				y: 3,
				width: 94,
				height: 94,
				rx: 2
			},
			{
				tag: "rect",
				x: 10,
				y: 10,
				width: 80,
				height: 80,
				rx: 2
			},
			{
				tag: "rect",
				x: 5,
				y: 20,
				width: 10,
				height: 15,
				rx: 0
			},
			{
				tag: "rect",
				x: 5,
				y: 65,
				width: 10,
				height: 15,
				rx: 0
			},
			{
				tag: "path",
				d: "M77 40V60M70 40H77M70 60H77"
			},
			{
				tag: "ellipse",
				cx: 10,
				cy: 10,
				rx: 2,
				ry: 2
			},
			{
				tag: "ellipse",
				cx: 90,
				cy: 10,
				rx: 2,
				ry: 2
			},
			{
				tag: "ellipse",
				cx: 10,
				cy: 90,
				rx: 2,
				ry: 2
			},
			{
				tag: "ellipse",
				cx: 90,
				cy: 90,
				rx: 2,
				ry: 2
			}
		]
	},
	cableFloorBox: {
		name: "Caixa de conexões embutida no piso",
		w: .5,
		h: .5,
		category: "floor-technical",
		shapes: [
			{
				tag: "rect",
				x: 3,
				y: 3,
				width: 94,
				height: 94,
				rx: 2
			},
			{
				tag: "rect",
				x: 12,
				y: 12,
				width: 76,
				height: 76,
				rx: 2
			},
			{
				tag: "rect",
				x: 22,
				y: 24,
				width: 56,
				height: 26,
				rx: 2
			},
			{
				tag: "path",
				d: "M25 64H75M25 72H75"
			},
			{
				tag: "ellipse",
				cx: 10,
				cy: 10,
				rx: 2,
				ry: 2
			},
			{
				tag: "ellipse",
				cx: 90,
				cy: 10,
				rx: 2,
				ry: 2
			},
			{
				tag: "ellipse",
				cx: 10,
				cy: 90,
				rx: 2,
				ry: 2
			},
			{
				tag: "ellipse",
				cx: 90,
				cy: 90,
				rx: 2,
				ry: 2
			}
		]
	},
	reinforcedFloorHatch: {
		name: "Escotilha técnica reforçada",
		w: 1.2,
		h: 1.2,
		category: "floor-technical",
		shapes: [
			{
				tag: "rect",
				x: 3,
				y: 3,
				width: 94,
				height: 94,
				rx: 5
			},
			{
				tag: "rect",
				x: 12,
				y: 12,
				width: 76,
				height: 76,
				rx: 4
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 50,
				rx: 17,
				ry: 17
			},
			{
				tag: "ellipse",
				cx: 50,
				cy: 50,
				rx: 5,
				ry: 5
			},
			{
				tag: "path",
				d: "M50 33V45M50 55V67M33 50H45M55 50H67"
			},
			{
				tag: "ellipse",
				cx: 10,
				cy: 10,
				rx: 2,
				ry: 2
			},
			{
				tag: "ellipse",
				cx: 90,
				cy: 10,
				rx: 2,
				ry: 2
			},
			{
				tag: "ellipse",
				cx: 10,
				cy: 90,
				rx: 2,
				ry: 2
			},
			{
				tag: "ellipse",
				cx: 90,
				cy: 90,
				rx: 2,
				ry: 2
			}
		]
	},
	...revisedAssets,
	...expandedAssets
};
//#endregion
//#region src/blueprints/asset-categories.js
var assetCategories = [
	{
		id: "infestation",
		name: "Infestação alienígena",
		items: []
	},
	{
		id: "mining-production",
		name: "Mineração e produção industrial",
		items: []
	},
	{
		id: "fitness",
		name: "Academia e condicionamento",
		items: []
	},
	{
		id: "restaurant",
		name: "Restaurantes e serviço de mesa",
		items: []
	},
	{
		id: "detention",
		name: "Prisão e contenção",
		items: []
	},
	{
		id: "settlement",
		name: "Indústria e logística",
		items: []
	},
	{
		id: "settlement-living",
		name: "Habitação e administração",
		items: []
	},
	{
		id: "settlement-care",
		name: "Ciência, saúde e segurança",
		items: []
	},
	{
		id: "settlement-services",
		name: "Cultivo e serviços essenciais",
		items: []
	},
	{
		id: "floor-technical",
		name: "Piso · inspeção e drenagem",
		items: []
	},
	{
		id: "bar",
		name: "Bares e jogos de salão",
		items: []
	},
	{
		id: "casino",
		name: "Cassinos",
		items: []
	},
	{
		id: "entertainment",
		name: "Entretenimento, camarins e suítes",
		items: []
	},
	{
		id: "rail-vehicles",
		name: "Veículos · ferroviários",
		items: []
	},
	{
		id: "industrial-vehicles",
		name: "Veículos · industriais",
		items: []
	},
	{
		id: "road-vehicles",
		name: "Veículos · rodoviários",
		items: []
	},
	{
		id: "market",
		name: "Feira e comércio",
		items: []
	},
	{
		id: "workshop",
		name: "Oficina",
		items: []
	},
	{
		id: "transit",
		name: "Estação e transporte",
		items: []
	},
	{
		id: "levels",
		name: "Plataformas e desníveis",
		items: [
			"raisedPlatform",
			"gratedPlatform",
			"shortSteps",
			"stairFlight",
			"accessRamp",
			"levelEdge"
		]
	},
	{
		id: "floor-signage",
		name: "Sinalização de piso",
		items: [
			"hazardStripe",
			"floorArrow",
			"loadingZone",
			"walkwayMark"
		]
	},
	{
		id: "garden",
		name: "Jardim e vegetação",
		items: [
			"pottedPalm",
			"broadleafPot",
			"roundShrub",
			"gardenTree",
			"longPlanter",
			"roundPlanter",
			"hydroponicBed",
			"gardenRocks",
			"gardenPond"
		]
	},
	{
		id: "exterior",
		name: "Área externa",
		items: [
			"parkBench",
			"picnicTable",
			"sunParasol",
			"safetyBollard",
			"floodlightStand",
			"outdoorCabinet",
			"solarPanelArray",
			"dishAntenna",
			"concreteBarrier",
			"drainGrate"
		]
	},
	{
		id: "decor",
		name: "Decoração interna",
		items: [
			"wovenRug",
			"floorLamp",
			"displayPlinth",
			"displayCase",
			"aquariumTank"
		]
	},
	{
		id: "laboratory",
		name: "Laboratório",
		items: [
			"labIncubator",
			"sampleFreezer",
			"tubeRack",
			"labCentrifuge",
			"labMicroscope",
			"sampleAnalyzer",
			"dissectionTable",
			"labSinkBench",
			"sampleFridge",
			"analysisCabinet"
		]
	},
	{
		id: "security",
		name: "Segurança",
		items: [
			"surveillanceCamera",
			"securityMonitor",
			"securitySafe",
			"protectionShield",
			"weaponLocker",
			"gearStand",
			"inspectionBench",
			"securityLocker"
		]
	},
	{
		id: "sanitary",
		name: "Sanitários",
		items: [
			"sanitaryToilet",
			"washBasin",
			"showerTray"
		]
	},
	{
		id: "galley",
		name: "Cozinha",
		items: [
			"galleySink",
			"galleyHob",
			"kitchen"
		]
	},
	{
		id: "command",
		name: "Comando",
		items: [
			"crtStation",
			"communicationsRadio",
			"reportPrinter",
			"briefingTable",
			"commandBench",
			"deskTerminal",
			"operatorSeat",
			"console"
		]
	},
	{
		id: "quarters",
		name: "Habitação e convivência",
		items: [
			"loungeSofa",
			"loungeArmchair",
			"sideTable",
			"lowCabinet",
			"crewBed",
			"wallLocker",
			"crewBench",
			"diningTable",
			"bed",
			"table",
			"chair",
			"locker",
			"sofa"
		]
	},
	{
		id: "medical",
		name: "Medicina e criogenia",
		items: [
			"cryoPodPlan",
			"surgeryTable",
			"medicalTrolley",
			"examBed",
			"medicalCabinet",
			"medical",
			"cryo"
		]
	},
	{
		id: "engineering",
		name: "Engenharia",
		items: [
			"horizontalTank",
			"airCompressor",
			"dataTapeCabinet",
			"serverCabinet",
			"powerUnit",
			"pumpUnit",
			"verticalTank",
			"serviceBench",
			"reactor",
			"engine",
			"tank",
			"workbench"
		]
	},
	{
		id: "cargo",
		name: "Carga e armazenamento",
		items: [
			"cargoContainer",
			"reinforcedCrate",
			"cargoPallet",
			"storageShelf",
			"crate",
			"rack"
		]
	},
	{
		id: "access",
		name: "Acessos e circulação",
		items: [
			"stairs",
			"elevator",
			"hatch"
		]
	}
].map((category) => ({
	...category,
	items: [.../* @__PURE__ */ new Set([...category.items, ...Object.entries({
		...colonyAssets,
		...vehicleAssets
	}).filter(([, asset]) => asset.category === category.id).map(([id]) => id)])].filter((id) => !Object.hasOwn(legacyAssets, id))
}));
//#endregion
//#region src/blueprints/project-mode.js
var externalCategories = /* @__PURE__ */ new Set([
	"mining-production",
	"settlement",
	"settlement-living",
	"settlement-care",
	"settlement-services",
	"exterior",
	"garden",
	"market",
	"transit",
	"rail-vehicles",
	"industrial-vehicles",
	"road-vehicles",
	"floor-signage"
]);
new Set(assetCategories.filter((c) => externalCategories.has(c.id)).flatMap((c) => c.items));
//#endregion
//#region src/blueprints/level-assets.js
var levelAssets = {
	raisedPlatform: {
		name: "Plataforma elevada · visual",
		w: 3,
		h: 2
	},
	gratedPlatform: {
		name: "Plataforma gradeada · visual",
		w: 3,
		h: 2
	},
	shortSteps: {
		name: "Degraus de acesso · visual",
		w: 1.4,
		h: .9
	},
	stairFlight: {
		name: "Lance de escada · visual",
		w: 1.2,
		h: 3
	},
	accessRamp: {
		name: "Rampa de acesso · visual",
		w: 1.5,
		h: 3
	},
	levelEdge: {
		name: "Borda de desnível · visual",
		w: 3,
		h: .3
	}
};
//#endregion
//#region src/blueprints/floor-markings.js
var floorMarkings = {
	hazardStripe: {
		name: "Faixa de segurança · piso",
		w: 2,
		h: .3
	},
	floorArrow: {
		name: "Seta de circulação · piso",
		w: .65,
		h: 1.4
	},
	loadingZone: {
		name: "Delimitação de carga · piso",
		w: 3,
		h: 2
	},
	walkwayMark: {
		name: "Faixa de circulação · piso",
		w: 1.2,
		h: 3
	}
};
//#endregion
//#region src/blueprints/environment-assets.js
var environmentAssets = {
	pottedPalm: {
		name: "Palmeira em vaso · vista superior",
		w: 1.3,
		h: 1.3
	},
	broadleafPot: {
		name: "Vaso de folhagem larga · vista superior",
		w: .8,
		h: .8
	},
	roundShrub: {
		name: "Arbusto ornamental · vista superior",
		w: 1.1,
		h: 1.1
	},
	gardenTree: {
		name: "Árvore de jardim de inverno · vista superior",
		w: 3,
		h: 3
	},
	longPlanter: {
		name: "Jardineira modular · vista superior",
		w: 2,
		h: .65
	},
	roundPlanter: {
		name: "Canteiro circular · vista superior",
		w: 2,
		h: 2
	},
	hydroponicBed: {
		name: "Canteiro hidropônico · vista superior",
		w: 1.2,
		h: 2.4
	},
	gardenRocks: {
		name: "Conjunto de pedras · vista superior",
		w: 1.6,
		h: 1.1
	},
	gardenPond: {
		name: "Espelho d’água · vista superior",
		w: 2.4,
		h: 1.5
	},
	parkBench: {
		name: "Banco de jardim · vista superior",
		w: 1.8,
		h: .6
	},
	picnicTable: {
		name: "Mesa externa com bancos · vista superior",
		w: 2,
		h: 1.8
	},
	sunParasol: {
		name: "Ombrelone · vista superior",
		w: 2.6,
		h: 2.6
	},
	safetyBollard: {
		name: "Balizador de proteção · vista superior",
		w: .35,
		h: .35
	},
	floodlightStand: {
		name: "Refletor em pedestal · vista superior",
		w: .7,
		h: .9
	},
	outdoorCabinet: {
		name: "Gabinete técnico externo · vista superior",
		w: 1.2,
		h: .7
	},
	solarPanelArray: {
		name: "Painel solar modular · vista superior",
		w: 2,
		h: 3
	},
	dishAntenna: {
		name: "Antena parabólica · vista superior",
		w: 2.2,
		h: 2.2
	},
	concreteBarrier: {
		name: "Barreira modular · vista superior",
		w: 2,
		h: .6
	},
	drainGrate: {
		name: "Grelha de drenagem · vista superior",
		w: 1.2,
		h: .4
	},
	wovenRug: {
		name: "Tapete de convivência · vista superior",
		w: 2.4,
		h: 1.6
	},
	floorLamp: {
		name: "Luminária de piso · vista superior",
		w: .5,
		h: .5
	},
	displayPlinth: {
		name: "Pedestal de exposição · vista superior",
		w: .8,
		h: .8
	},
	displayCase: {
		name: "Vitrine de coleção · vista superior",
		w: 1.6,
		h: .65
	},
	aquariumTank: {
		name: "Aquário ornamental · vista superior",
		w: 1.5,
		h: .6
	}
};
({
	...vehicleAssets,
	...colonyAssets
}), {
	...levelAssets,
	...floorMarkings,
	...environmentAssets
};
[.../* @__PURE__ */ new Set([
	"surveillanceCamera",
	"crtStation",
	"communicationsRadio",
	"reportPrinter",
	"dataTapeCabinet",
	...Object.keys(colonyAssets),
	...Object.keys(vehicleAssets),
	"raisedPlatform",
	"gratedPlatform",
	"shortSteps",
	"stairFlight",
	"accessRamp",
	"levelEdge",
	"hazardStripe",
	"floorArrow",
	"loadingZone",
	"walkwayMark",
	"pottedPalm",
	"broadleafPot",
	"roundShrub",
	"gardenTree",
	"longPlanter",
	"roundPlanter",
	"hydroponicBed",
	"gardenRocks",
	"gardenPond",
	"parkBench",
	"picnicTable",
	"sunParasol",
	"safetyBollard",
	"floodlightStand",
	"outdoorCabinet",
	"solarPanelArray",
	"dishAntenna",
	"concreteBarrier",
	"drainGrate",
	"wovenRug",
	"floorLamp",
	"displayPlinth",
	"displayCase",
	"aquariumTank",
	"labIncubator",
	"sampleFreezer",
	"tubeRack",
	"securityMonitor",
	"securitySafe",
	"protectionShield",
	"weaponLocker",
	"gearStand",
	"inspectionBench",
	"labCentrifuge",
	"labMicroscope",
	"sampleAnalyzer",
	"dissectionTable",
	"loungeSofa",
	"loungeArmchair",
	"sideTable",
	"lowCabinet",
	"labSinkBench",
	"sampleFridge",
	"analysisCabinet",
	"securityLocker",
	"cargoContainer",
	"reinforcedCrate",
	"horizontalTank",
	"airCompressor",
	"cryoPodPlan",
	"surgeryTable",
	"medicalTrolley",
	"serverCabinet",
	"briefingTable",
	"sanitaryToilet",
	"washBasin",
	"showerTray",
	"galleySink",
	"galleyHob",
	"powerUnit",
	"pumpUnit",
	"verticalTank",
	"serviceBench",
	"cargoPallet",
	"storageShelf",
	"crewBed",
	"wallLocker",
	"crewBench",
	"diningTable",
	"examBed",
	"medicalCabinet",
	"commandBench",
	"deskTerminal",
	"operatorSeat",
	"stairs",
	"elevator",
	"console",
	"bed",
	"cryo",
	"table",
	"crate",
	"reactor",
	"chair",
	"medical",
	"locker",
	"hatch",
	"engine",
	"tank",
	"rack",
	"workbench",
	"kitchen",
	"sofa"
])];
function resolveAccessFlags(bundle, regionUUIDs) {
	if (bundle.format !== "alien-blueprint-foundry" || bundle.version !== 1) throw Error("Pacote incompatível.");
	const ids = new Set(bundle.accesses.map((a) => a.key));
	if (ids.size !== bundle.accesses.length) throw Error("Acessos duplicados.");
	const seen = /* @__PURE__ */ new Set();
	for (const access of bundle.accesses) {
		const uuid = regionUUIDs.get(access.key);
		if (typeof uuid !== "string" || !/^Scene\.[A-Za-z0-9]+\.Region\.[A-Za-z0-9]+$/.test(uuid) || seen.has(uuid)) throw Error("Região ausente ou duplicada: " + access.key);
		seen.add(uuid);
		if (access.targets.some((id) => !ids.has(id) || id === access.key)) throw Error("Destino inválido.");
	}
	return bundle.accesses.map((access) => ({
		uuid: regionUUIDs.get(access.key),
		flags: { "alien-suite-mae": { access: {
			enabled: true,
			auto: true,
			targets: [...new Set(access.targets.map((id) => regionUUIDs.get(id)))]
		} } }
	}));
}
//#endregion
//#region src/blueprints/foundry/importer.js
function prepareFoundryImport(bundle, imagePaths) {
	if (bundle?.format !== "alien-blueprint-foundry" || bundle.version !== 1) throw Error("Pacote incompatível.");
	if (!Array.isArray(bundle.scenes) || !bundle.scenes.length || !Array.isArray(bundle.accesses)) throw Error("Pacote sem cenas ou acessos válidos.");
	const keys = /* @__PURE__ */ new Set();
	const scenes = bundle.scenes.map((scene) => {
		if (!scene.key || keys.has(scene.key)) throw Error("Pavimento duplicado.");
		keys.add(scene.key);
		if (scene.geometry?.ready !== true || !Array.isArray(scene.geometry.barriers)) throw Error("Não é possível exportar " + scene.name + ": " + (scene.geometry?.warnings?.join(" ") || "geometria incompleta."));
		if (![
			scene.width,
			scene.height,
			scene.grid?.size,
			scene.grid?.distance
		].every((v) => Number.isFinite(v) && v > 0)) throw Error("Dimensões inválidas: " + scene.name);
		if (Math.round(scene.grid.size) < 20) throw Error("A grade do Foundry exige pelo menos 20 pixels.");
		const image = imagePaths.get(scene.key);
		if (typeof image !== "string" || !image.trim()) throw Error("Imagem ausente: " + scene.name);
		const walls = scene.geometry.barriers.map((barrier) => {
			if (!Array.isArray(barrier.coordinates) || barrier.coordinates.length !== 4 || !barrier.coordinates.every(Number.isFinite)) throw Error("Coordenadas de parede inválidas.");
			if (![
				"wall",
				"door",
				"window"
			].includes(barrier.kind) || !barrier.blocks || ![
				"movement",
				"sight",
				"light",
				"sound"
			].every((k) => typeof barrier.blocks[k] === "boolean")) throw Error("Barreira inválida.");
			const c = barrier.coordinates.map(Math.round);
			if (c[0] === c[2] && c[1] === c[3]) {
				if (barrier.kind === "wall") return null;
				throw Error("Abertura pequena demais para esta escala em " + scene.name + ". Aumente a resolução.");
			}
			return {
				c,
				move: barrier.blocks.movement ? 20 : 0,
				sight: barrier.blocks.sight ? 20 : 0,
				light: barrier.blocks.light ? 20 : 0,
				sound: barrier.blocks.sound ? 20 : 0,
				dir: 0,
				door: barrier.kind === "door" ? 1 : 0,
				ds: 0,
				...barrier.kind === "door" && typeof barrier.doorGroup === "string" ? { flags: { "alien-blueprint-importer": { doorGroup: barrier.doorGroup } } } : {}
			};
		}).filter(Boolean);
		return {
			key: scene.key,
			image,
			walls,
			data: {
				name: scene.name,
				width: Math.round(scene.width),
				height: Math.round(scene.height),
				padding: 0,
				active: false,
				navigation: false,
				grid: {
					type: 1,
					size: Math.round(scene.grid.size),
					distance: scene.grid.distance,
					units: "m"
				}
			}
		};
	});
	for (const access of bundle.accesses) {
		const scene = bundle.scenes.find((s) => s.key === access.sceneKey);
		if (!scene || !Array.isArray(access.polygon) || access.polygon.length < 3 || access.polygon.some((p) => !Number.isFinite(p.x) || !Number.isFinite(p.y) || p.x < 0 || p.y < 0 || p.x > scene.width || p.y > scene.height)) throw Error("Região inválida: " + access.key);
		if (access.kind === "vent" && scene.kind !== "ventilation") throw Error("O acesso de ventilação exige uma cena exclusiva de dutos.");
		if (!Array.isArray(access.targets) || !access.targets.length) throw Error("Acesso sem destino.");
	}
	resolveAccessFlags(bundle, new Map(bundle.accesses.map((a, i) => [a.key, `Scene.validation.Region.region${i}`])));
	return scenes;
}
async function importFoundryPackage(bundle, imagePaths, runtime) {
	if (!runtime.isGM || runtime.generation !== 14) throw Error("Importação exige um mestre no Foundry 14.");
	if (bundle.accesses?.length && !runtime.accessEnabled) throw Error("Ative os acessos da Suíte MÃE.");
	const plan = prepareFoundryImport(bundle, imagePaths);
	const created = [], regions = /* @__PURE__ */ new Map();
	try {
		for (const item of plan) {
			const scene = await runtime.createScene({
				...item.data,
				levels: [{
					name: item.data.name,
					background: { src: item.image }
				}]
			});
			created.push(scene);
			const levels = scene.levels?.contents;
			if (levels?.length !== 1 || !levels[0]?.id) throw Error("O Foundry não retornou um único nível para a cena.");
			const level = levels[0];
			await scene.update({ initialLevel: level.id });
			await scene.createEmbeddedDocuments("Wall", item.walls.map((w) => ({
				...w,
				levels: [level.id]
			})));
			for (const access of bundle.accesses.filter((a) => a.sceneKey === item.key)) {
				const [region] = await scene.createEmbeddedDocuments("Region", [{
					name: access.name,
					levels: [level.id],
					color: "#8ee69e",
					shapes: [{
						type: "polygon",
						points: access.polygon.flatMap((p) => [p.x, p.y]),
						hole: false
					}],
					ownership: { default: 2 },
					visibility: 3,
					flags: { "alien-suite-mae": { access: {
						enabled: false,
						auto: false,
						targets: []
					} } }
				}]);
				if (!region?.uuid) throw Error("O Foundry não retornou a região criada.");
				regions.set(access.key, region);
			}
		}
		const flags = resolveAccessFlags(bundle, new Map([...regions].map(([key, r]) => [key, r.uuid])));
		const byUUID = new Map([...regions.values()].map((r) => [r.uuid, r]));
		for (const entry of flags) await byUUID.get(entry.uuid).update({ flags: entry.flags });
		return created;
	} catch (cause) {
		const failures = [];
		for (const scene of [...created].reverse()) try {
			await scene.delete();
		} catch {
			failures.push(scene.id);
		}
		throw new Error(failures.length ? "Importação interrompida. Remova as cenas incompletas: " + failures.join(", ") : "Importação interrompida; cenas criadas foram removidas.", { cause });
	}
}
//#endregion
//#region src/blueprints/foundry/receive.js
var MAX_FILE = 134217728;
var PNG_PREFIX = "data:image/png;base64,";
function parseFoundryArchive(text) {
	if (typeof text !== "string" || text.length > MAX_FILE) throw Error("Arquivo excede o limite de 128 MB.");
	const bundle = JSON.parse(text);
	if (bundle?.stage !== "image-package" || !Array.isArray(bundle.images) || !Array.isArray(bundle.scenes) || bundle.scenes.length > 200 || bundle.images.length !== bundle.scenes.length) throw Error("Pacote de imagens inválido.");
	const images = /* @__PURE__ */ new Map();
	for (const image of bundle.images) {
		if (!image || images.has(image.sceneKey)) throw Error("Imagem duplicada ou inválida.");
		const scene = bundle.scenes.find((s) => s.key === image.sceneKey);
		if (!scene || !Number.isInteger(image.width) || !Number.isInteger(image.height) || image.width <= 0 || image.height <= 0 || image.width > 8192 || image.height > 8192 || image.width * image.height > 32e6 || image.width !== scene.width || image.height !== scene.height) throw Error("Dimensões da imagem não correspondem ao pavimento.");
		if (typeof image.data !== "string" || !image.data.startsWith(PNG_PREFIX)) throw Error("A imagem precisa ser um PNG incorporado.");
		const encoded = image.data.slice(22);
		if (encoded.length % 4 || !/^[A-Za-z0-9+/]+={0,2}$/.test(encoded)) throw Error("PNG inválido.");
		const bytes = Uint8Array.from(atob(encoded), (c) => c.charCodeAt(0));
		if (bytes.length < 33 || [
			137,
			80,
			78,
			71,
			13,
			10,
			26,
			10
		].some((v, i) => bytes[i] !== v) || String.fromCharCode(...bytes.slice(12, 16)) !== "IHDR") throw Error("Cabeçalho PNG inválido.");
		const header = new DataView(bytes.buffer);
		if (header.getUint32(8) !== 13 || header.getUint32(16) !== image.width || header.getUint32(20) !== image.height) throw Error("Resolução real do PNG não corresponde ao pavimento.");
		images.set(image.sceneKey, {
			blob: new Blob([bytes], { type: "image/png" }),
			width: image.width,
			height: image.height
		});
	}
	const plan = prepareFoundryImport(bundle, new Map([...images.keys()].map((key, i) => [key, `floor-${i + 1}.png`])));
	return {
		bundle,
		images,
		summary: {
			scenes: plan.length,
			walls: plan.reduce((n, s) => n + s.walls.length, 0),
			accesses: bundle.accesses.length
		}
	};
}
async function receiveFoundryArchive(text, runtime, onProgress = () => {}) {
	if (!runtime.isGM || runtime.generation !== 14) throw Error("Importação exige um mestre no Foundry 14.");
	const { bundle, images } = parseFoundryArchive(text);
	if (bundle.accesses.length && !runtime.accessEnabled) throw Error("Ative os acessos da Suíte MÃE.");
	for (const image of images.values()) {
		const size = await runtime.decodeImage(image.blob);
		if (size.width !== image.width || size.height !== image.height) throw Error("PNG com dimensões inesperadas.");
	}
	let directory;
	try {
		directory = await runtime.createImportDirectory();
		const paths = /* @__PURE__ */ new Map();
		for (const [key, image] of images) {
			const path = await runtime.uploadImage(directory, `floor-${paths.size + 1}.png`, image.blob);
			if (typeof path !== "string" || !path.trim()) throw Error("O Foundry não confirmou o envio da imagem.");
			paths.set(key, path);
			onProgress({
				phase: "upload",
				completed: paths.size,
				total: images.size
			});
		}
		return {
			scenes: await importFoundryPackage(bundle, paths, runtime),
			directory
		};
	} catch (cause) {
		throw new Error(directory ? `${cause.message} A pasta desta tentativa é ${directory}; ela pode conter imagens para limpeza manual.` : cause.message, { cause });
	}
}
//#endregion
//#region src/blueprints/foundry/runtime.js
function createFoundryRuntime({ game, CONFIG, foundry, Scene }, browser = globalThis) {
	const picker = CONFIG.ux.FilePicker;
	return {
		isGM: !!game.user?.isGM,
		generation: game.release.generation,
		accessEnabled: !!game.modules.get("alien-suite-mae")?.active && !!game.settings.get("alien-suite-mae", "feature.alien-acessos") && !game.modules.get("alien-acessos")?.active,
		createScene: (data) => Scene.create(data),
		async decodeImage(blob) {
			const bitmap = await browser.createImageBitmap(blob);
			try {
				return {
					width: bitmap.width,
					height: bitmap.height
				};
			} finally {
				bitmap.close();
			}
		},
		async createImportDirectory() {
			const directory = `worlds/${game.world.id}/blueprint-${foundry.utils.randomID()}`;
			await picker.createDirectory("data", directory);
			return directory;
		},
		async uploadImage(directory, name, blob) {
			const result = await picker.upload("data", directory, new browser.File([blob], name, { type: "image/png" }), {}, { notify: false });
			if (!result?.path) throw Error("Falha ao enviar " + name);
			return result.path;
		}
	};
}
//#endregion
//#region src/blueprints/foundry/door-sync.js
async function syncDoorGroup(wall, change, options, game) {
	if (options?.blueprintDoorSync || ![
		0,
		1,
		2
	].includes(change.ds)) return;
	const gm = [...game.users].filter((u) => u.active && u.isGM).sort((a, b) => a.id.localeCompare(b.id))[0];
	if (!gm || game.user.id !== gm.id) return;
	const group = wall.flags?.["alien-blueprint-importer"]?.doorGroup;
	if (!group || !wall.parent) return;
	const updates = [...wall.parent.walls].filter((w) => w.id !== wall.id && w.door === 1 && w.flags?.["alien-blueprint-importer"]?.doorGroup === group && w.ds !== change.ds).map((w) => ({
		_id: w.id,
		ds: change.ds
	}));
	if (updates.length) await wall.parent.updateEmbeddedDocuments("Wall", updates, { blueprintDoorSync: true });
}
//#endregion
//#region src/blueprints/foundry/module-entry.js
var ID = "alien-blueprint-importer";
var busy = false;
var escape = (value) => String(value).replace(/[&<>"']/g, (c) => ({
	"&": "&amp;",
	"<": "&lt;",
	">": "&gt;",
	"\"": "&quot;",
	"'": "&#39;"
})[c]);
async function openImporter() {
	if (busy) return ui.notifications.warn("Uma importação já está em andamento.");
	if (!game.user.isGM) return ui.notifications.warn("Somente o mestre pode importar mapas.");
	busy = true;
	try {
		const file = await foundry.applications.api.DialogV2.prompt({
			window: { title: "Importar mapa Blueprint" },
			content: "<label>Arquivo .alien-foundry<input type=\"file\" name=\"blueprint\" accept=\".alien-foundry,application/json\" required></label>",
			ok: {
				label: "Verificar arquivo",
				callback: (_event, button) => button.form.querySelector("input[type=file]").files[0]
			}
		});
		if (!file) return;
		if (file.size > 134217728) throw Error("Arquivo excede o limite de 128 MB.");
		const text = await file.text();
		const { bundle, summary } = parseFoundryArchive(text);
		if (!await foundry.applications.api.DialogV2.confirm({
			window: { title: "Conferir importação" },
			yes: { label: "Criar cenas" },
			no: { label: "Cancelar" },
			content: `<p><strong>${escape(bundle.name || "Mapa")}</strong></p>
        <p>${summary.scenes} cena(s), ${summary.walls} barreira(s), ${summary.accesses} acesso(s).</p>
        <p>Serão criadas cenas novas, fora da navegação. Revise a chegada dos tokens antes de liberar aos jogadores.</p>
        <p>Mantenha este módulo ativo para sincronizar portas curvas. Redes de ventilação são importadas em cenas exclusivas.</p>
        <p>Importador experimental: ainda requer validação em jogo.</p>`
		})) return;
		const result = await receiveFoundryArchive(text, createFoundryRuntime({
			game,
			CONFIG,
			foundry,
			Scene
		}));
		ui.notifications.info(`${result.scenes.length} cena(s) importada(s). Revise-as na lista de cenas.`);
		return result;
	} catch (error) {
		console.error("Blueprint import:", error);
		ui.notifications.error(error.message, { permanent: true });
	} finally {
		busy = false;
	}
}
Hooks.once("init", () => {
	Hooks.on("getSceneControlButtons", (controls) => {
		if (!game.user.isGM || !controls.tokens?.tools) return;
		controls.tokens.tools.blueprintImport = {
			name: "blueprintImport",
			title: "Importar mapa Blueprint",
			icon: "fa-solid fa-file-import",
			order: Object.keys(controls.tokens.tools).length,
			button: true,
			onChange: () => openImporter()
		};
	});
	Hooks.on("renderSceneDirectory", (_app, html) => {
		if (!game.user.isGM || html.querySelector("[data-blueprint-import]")) return;
		const header = html.querySelector(".header-actions");
		if (!header) return;
		const button = document.createElement("button");
		button.type = "button";
		button.dataset.blueprintImport = "";
		button.title = "Importar mapa Blueprint (.alien-foundry)";
		button.setAttribute("aria-label", button.title);
		button.innerHTML = "<i class=\"fa-solid fa-file-import\" aria-hidden=\"true\"></i> Blueprint";
		button.addEventListener("click", () => openImporter());
		header.append(button);
	});
	Hooks.on("updateWall", (wall, change, options) => {
		syncDoorGroup(wall, change, options, game).catch((error) => {
			console.error("Blueprint door synchronization:", error);
			ui.notifications.error("Não foi possível sincronizar os trechos desta porta.");
		});
	});
	class ImportMenu extends foundry.applications.api.ApplicationV2 {
		static DEFAULT_OPTIONS = {
			id: "blueprint-import-menu",
			window: { title: "Importar Blueprint" },
			position: { width: 420 }
		};
		async _renderHTML() {
			const content = document.createElement("div");
			const description = document.createElement("p");
			description.textContent = "Importe um arquivo .alien-foundry para criar cenas, paredes e conexões. Versão experimental.";
			const button = document.createElement("button");
			button.type = "button";
			button.textContent = "Escolher arquivo";
			button.addEventListener("click", () => openImporter());
			content.append(description, button);
			return content;
		}
		_replaceHTML(result, content) {
			content.replaceChildren(result);
		}
	}
	game.settings.registerMenu(ID, "import", {
		name: "Importar mapa Blueprint",
		label: "Importar arquivo",
		icon: "fas fa-file-import",
		hint: "Cria cenas novas a partir de um pacote .alien-foundry.",
		restricted: true,
		type: ImportMenu
	});
	game.modules.get(ID).api = { openImporter };
});
//#endregion
